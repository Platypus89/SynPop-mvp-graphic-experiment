/*
  # Initial Schema Setup for SynPop

  1. New Tables
    - `users`
      - `id` (uuid, primary key) - matches Supabase auth user id
      - `email` (text, unique)
      - `created_at` (timestamp)
    
    - `populations`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key to users)
      - `name` (text)
      - `size` (integer)
      - `source_dataset` (text)
      - `attributes` (jsonb)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
    
    - `stimuli`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key to users)
      - `type` (text) - 'text', 'image', or 'pdf'
      - `content` (text)
      - `metadata` (jsonb)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
    
    - `simulations`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key to users)
      - `population_id` (uuid, foreign key to populations)
      - `stimulus_id` (uuid, foreign key to stimuli)
      - `name` (text)
      - `description` (text)
      - `status` (text)
      - `temperature` (numeric)
      - `results` (jsonb)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users to manage their own data
*/

-- Create tables
CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY REFERENCES auth.users(id),
  email text UNIQUE NOT NULL,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS populations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id) NOT NULL,
  name text NOT NULL,
  size integer NOT NULL,
  source_dataset text,
  attributes jsonb NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS stimuli (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id) NOT NULL,
  type text NOT NULL CHECK (type IN ('text', 'image', 'pdf')),
  content text NOT NULL,
  metadata jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS simulations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id) NOT NULL,
  population_id uuid REFERENCES populations(id) NOT NULL,
  stimulus_id uuid REFERENCES stimuli(id) NOT NULL,
  name text NOT NULL,
  description text,
  status text NOT NULL CHECK (status IN ('draft', 'in-progress', 'completed')),
  temperature numeric NOT NULL DEFAULT 0.5,
  results jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE populations ENABLE ROW LEVEL SECURITY;
ALTER TABLE stimuli ENABLE ROW LEVEL SECURITY;
ALTER TABLE simulations ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can manage their own profile"
  ON users
  USING (auth.uid() = id);

CREATE POLICY "Users can manage their own populations"
  ON populations
  USING (auth.uid() = user_id);

CREATE POLICY "Users can manage their own stimuli"
  ON stimuli
  USING (auth.uid() = user_id);

CREATE POLICY "Users can manage their own simulations"
  ON simulations
  USING (auth.uid() = user_id);

-- Create functions for updating timestamps
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create triggers for updating timestamps
CREATE TRIGGER update_populations_updated_at
  BEFORE UPDATE ON populations
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER update_stimuli_updated_at
  BEFORE UPDATE ON stimuli
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER update_simulations_updated_at
  BEFORE UPDATE ON simulations
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at();