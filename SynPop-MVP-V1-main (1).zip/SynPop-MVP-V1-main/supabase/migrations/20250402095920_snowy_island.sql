/*
  # Add indexes and optimize query performance

  1. Changes
    - Add composite indexes for better query performance
    - Add indexes for metadata and sorting
    - Add indexes for size and created_at columns
  
  2. Security
    - Maintain existing RLS policies
*/

-- Add composite indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_populations_user_created ON populations(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_populations_size_created ON populations(size, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_populations_metadata ON populations USING gin(metadata jsonb_path_ops);

-- Add indexes for efficient sorting and filtering
CREATE INDEX IF NOT EXISTS idx_populations_created_at ON populations(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_populations_size ON populations(size);

-- Add indexes for related tables to improve join performance
CREATE INDEX IF NOT EXISTS idx_simulations_population_id ON simulations(population_id);
CREATE INDEX IF NOT EXISTS idx_simulations_created_at ON simulations(created_at DESC);