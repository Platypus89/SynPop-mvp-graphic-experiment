-- Drop existing objects
DROP TABLE IF EXISTS user_roles CASCADE;
DROP FUNCTION IF EXISTS handle_new_user CASCADE;

-- Create simplified user_roles table
CREATE TABLE user_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  role text NOT NULL DEFAULT 'user',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT valid_role CHECK (role IN ('admin', 'user')),
  CONSTRAINT unique_user_role UNIQUE (user_id)
);

-- Enable RLS
ALTER TABLE user_roles ENABLE ROW LEVEL SECURITY;

-- Create simple RLS policies
CREATE POLICY "Public read access"
  ON user_roles FOR SELECT
  TO PUBLIC
  USING (true);

-- Function to get user role
CREATE OR REPLACE FUNCTION get_user_role(user_id uuid)
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN (
    SELECT role
    FROM user_roles
    WHERE user_roles.user_id = $1
    LIMIT 1
  );
END;
$$;