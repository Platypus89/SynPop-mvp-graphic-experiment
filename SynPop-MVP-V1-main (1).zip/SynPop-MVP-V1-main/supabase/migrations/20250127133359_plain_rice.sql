-- Ensure role column exists in auth.users with proper constraints
DO $$ 
BEGIN
  -- Add role column if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_schema = 'auth' 
    AND table_name = 'users' 
    AND column_name = 'role'
  ) THEN
    ALTER TABLE auth.users ADD COLUMN role text;
  END IF;

  -- Update any NULL roles to 'user'
  UPDATE auth.users 
  SET role = 'user' 
  WHERE role IS NULL;

  -- Make role column NOT NULL with default
  ALTER TABLE auth.users 
    ALTER COLUMN role SET NOT NULL,
    ALTER COLUMN role SET DEFAULT 'user';
END $$;

-- Ensure admin user has correct role in auth.users
UPDATE auth.users 
SET role = 'admin'
WHERE email = 'matteo.gelpi@synpop.ai';

-- Sync auth.users roles with public.users
INSERT INTO users (id, email, role)
SELECT id, email, COALESCE(role, 'user')
FROM auth.users
ON CONFLICT (id) DO UPDATE
SET role = EXCLUDED.role;