-- Drop existing objects to start fresh
DROP TABLE IF EXISTS users CASCADE;
DROP FUNCTION IF EXISTS is_admin CASCADE;

-- Create a simple users table
CREATE TABLE users (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text UNIQUE NOT NULL,
  role text NOT NULL DEFAULT 'user',
  created_at timestamptz DEFAULT now(),
  CONSTRAINT valid_role CHECK (role IN ('admin', 'user'))
);

-- Enable RLS
ALTER TABLE users ENABLE ROW LEVEL SECURITY;

-- Create simple policies
CREATE POLICY "Enable read access for all users"
  ON users FOR SELECT
  USING (true);

CREATE POLICY "Enable self update"
  ON users FOR UPDATE
  USING (auth.uid() = id);

-- Create simple admin check function
CREATE OR REPLACE FUNCTION is_admin()
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM users
    WHERE id = auth.uid()
    AND role = 'admin'
  );
END;
$$;

-- Grant permissions
GRANT USAGE ON SCHEMA public TO anon, authenticated;
GRANT ALL ON users TO authenticated;
GRANT SELECT ON users TO anon;
GRANT EXECUTE ON FUNCTION is_admin TO authenticated;

-- Create simple policies for other tables
ALTER TABLE populations ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Enable access for authenticated users"
  ON populations FOR ALL
  TO authenticated
  USING (true);

ALTER TABLE stimuli ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Enable access for authenticated users"
  ON stimuli FOR ALL
  TO authenticated
  USING (true);

ALTER TABLE simulations ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Enable access for authenticated users"
  ON simulations FOR ALL
  TO authenticated
  USING (true);

-- Create admin user
INSERT INTO auth.users (
  email,
  encrypted_password,
  email_confirmed_at,
  raw_app_meta_data,
  raw_user_meta_data,
  created_at,
  updated_at
)
SELECT 
  'matteo.gelpi@synpop.ai',
  crypt('Synpop1234!', gen_salt('bf')),
  now(),
  '{"provider": "email", "providers": ["email"]}'::jsonb,
  '{}'::jsonb,
  now(),
  now()
WHERE NOT EXISTS (
  SELECT 1 FROM auth.users WHERE email = 'matteo.gelpi@synpop.ai'
);

-- Set admin role
INSERT INTO users (id, email, role)
SELECT id, email, 'admin'
FROM auth.users
WHERE email = 'matteo.gelpi@synpop.ai'
ON CONFLICT (id) DO UPDATE
SET role = 'admin';