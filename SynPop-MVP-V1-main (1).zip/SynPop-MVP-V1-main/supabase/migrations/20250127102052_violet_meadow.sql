/*
  # Create admin user and role
  
  1. Changes
    - Create admin user if not exists
    - Assign admin role to user
  2. Security
    - Uses secure password hashing
    - Handles existing user case safely
*/

-- Create admin user if not exists
DO $$ 
DECLARE
  new_user_id uuid;
BEGIN
  -- Check if user already exists
  SELECT id INTO new_user_id
  FROM auth.users 
  WHERE email = 'matteo.gelpi@synpop.ai';

  -- Create user if they don't exist
  IF new_user_id IS NULL THEN
    INSERT INTO auth.users (
      instance_id,
      id,
      aud,
      email,
      encrypted_password,
      email_confirmed_at,
      raw_app_meta_data,
      raw_user_meta_data,
      is_super_admin,
      created_at,
      updated_at
    )
    VALUES (
      '00000000-0000-0000-0000-000000000000',
      gen_random_uuid(),
      'authenticated',
      'matteo.gelpi@synpop.ai',
      crypt('Synpop1234!', gen_salt('bf')),
      now(),
      '{"provider":"email","providers":["email"]}',
      '{}',
      false,
      now(),
      now()
    )
    RETURNING id INTO new_user_id;
  END IF;

  -- Ensure admin role exists
  INSERT INTO user_roles (user_id, role)
  VALUES (new_user_id, 'admin')
  ON CONFLICT (user_id) 
  DO UPDATE SET role = 'admin';
END $$;