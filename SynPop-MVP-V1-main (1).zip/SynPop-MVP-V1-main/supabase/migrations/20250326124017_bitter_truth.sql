/*
  # Add indexes and optimize query performance

  1. Changes
    - Add indexes for frequently queried columns
    - Add composite indexes for common query patterns
    - Add indexes for sorting and filtering
  
  2. Security
    - Maintain existing RLS policies
*/

-- Add indexes for simulations table
CREATE INDEX IF NOT EXISTS idx_simulations_created_at ON simulations(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_simulations_population_id ON simulations(population_id);
CREATE INDEX IF NOT EXISTS idx_simulations_stimulus_id ON simulations(stimulus_id);
CREATE INDEX IF NOT EXISTS idx_simulations_status ON simulations(status);

-- Add composite indexes for common query patterns
CREATE INDEX IF NOT EXISTS idx_simulations_status_created ON simulations(status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_simulations_population_created ON simulations(population_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_simulations_stimulus_created ON simulations(stimulus_id, created_at DESC);

-- Add indexes for populations table
CREATE INDEX IF NOT EXISTS idx_populations_created_at ON populations(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_populations_size ON populations(size);
CREATE INDEX IF NOT EXISTS idx_populations_metadata ON populations USING gin(metadata jsonb_path_ops);

-- Add indexes for stimuli table
CREATE INDEX IF NOT EXISTS idx_stimuli_created_at ON stimuli(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_stimuli_type ON stimuli(type);
CREATE INDEX IF NOT EXISTS idx_stimuli_metadata ON stimuli USING gin(metadata jsonb_path_ops);