-- Drop dependent policies first
DROP POLICY IF EXISTS "Admins can view all API usage" ON api_usage;
DROP POLICY IF EXISTS "Only admins can manage sample projects" ON sample_projects;

-- Drop and recreate user_roles table
DROP TABLE IF EXISTS user_roles CASCADE;
CREATE TABLE user_roles (
  user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  role text NOT NULL CHECK (role IN ('admin', 'user')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE user_roles ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
CREATE POLICY "Users can read own role" ON user_roles
  FOR SELECT USING (auth.uid() = user_id);

-- Recreate dependent policies
CREATE POLICY "Admins can view all API usage" ON api_usage
  FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM user_roles ur
      WHERE ur.user_id = auth.uid()
      AND ur.role = 'admin'
    )
  );

CREATE POLICY "Only admins can manage sample projects" ON sample_projects
  FOR ALL
  USING (
    EXISTS (
      SELECT 1 FROM user_roles ur
      WHERE ur.user_id = auth.uid()
      AND ur.role = 'admin'
    )
  );

-- Create admin user
DO $$ 
DECLARE
  new_user_id uuid;
BEGIN
  -- Get existing user ID if exists
  SELECT id INTO new_user_id
  FROM auth.users
  WHERE email = 'matteo.gelpi@synpop.ai';

  -- Create user if doesn't exist
  IF new_user_id IS NULL THEN
    INSERT INTO auth.users (
      id,
      email,
      encrypted_password,
      email_confirmed_at,
      raw_app_meta_data,
      raw_user_meta_data,
      created_at,
      updated_at
    )
    SELECT
      gen_random_uuid(),
      'matteo.gelpi@synpop.ai',
      crypt('Synpop1234!', gen_salt('bf')),
      now(),
      '{"provider": "email", "providers": ["email"]}'::jsonb,
      '{}'::jsonb,
      now(),
      now()
    WHERE NOT EXISTS (
      SELECT 1 FROM auth.users WHERE email = 'matteo.gelpi@synpop.ai'
    )
    RETURNING id INTO new_user_id;
  END IF;

  -- Set admin role
  IF new_user_id IS NOT NULL THEN
    INSERT INTO user_roles (user_id, role)
    VALUES (new_user_id, 'admin')
    ON CONFLICT (user_id) DO UPDATE SET role = 'admin';
  END IF;
END $$;