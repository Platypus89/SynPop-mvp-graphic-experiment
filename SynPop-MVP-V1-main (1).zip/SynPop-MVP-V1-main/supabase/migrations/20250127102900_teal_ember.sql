-- Create admin user if not exists
DO $$ 
DECLARE
  new_user_id uuid;
BEGIN
  -- Check if user already exists
  SELECT id INTO new_user_id
  FROM auth.users 
  WHERE email = 'matteo.gelpi@synpop.ai';

  -- Create user if they don't exist
  IF new_user_id IS NULL THEN
    INSERT INTO auth.users (
      id,
      email,
      encrypted_password,
      email_confirmed_at,
      raw_app_meta_data,
      raw_user_meta_data,
      created_at,
      updated_at
    )
    VALUES (
      gen_random_uuid(),
      'matteo.gelpi@synpop.ai',
      crypt('Synpop1234!', gen_salt('bf')),
      now(),
      '{"provider": "email", "providers": ["email"]}'::jsonb,
      '{}'::jsonb,
      now(),
      now()
    )
    RETURNING id INTO new_user_id;
  END IF;

  -- Ensure admin role exists
  INSERT INTO user_roles (user_id, role)
  VALUES (new_user_id, 'admin')
  ON CONFLICT (user_id) 
  DO UPDATE SET role = 'admin';
END $$;