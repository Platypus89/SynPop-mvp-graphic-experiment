/*
  # Add metadata columns for better user context generation

  1. Changes
    - Add metadata columns to populations table
    - Add indexes for efficient querying
    - Update RLS policies
  
  2. Security
    - Maintain existing RLS policies
*/

-- Add metadata columns to populations table
ALTER TABLE populations
ADD COLUMN IF NOT EXISTS metadata jsonb DEFAULT '{}'::jsonb;

-- Add indexes for efficient querying
CREATE INDEX IF NOT EXISTS idx_populations_metadata ON populations USING gin(metadata jsonb_path_ops);
CREATE INDEX IF NOT EXISTS idx_populations_size ON populations(size);
CREATE INDEX IF NOT EXISTS idx_populations_created_at ON populations(created_at DESC);

-- Update RLS policies
DROP POLICY IF EXISTS "Enable access for authenticated users" ON populations;
CREATE POLICY "Enable access for authenticated users"
  ON populations FOR ALL
  TO authenticated
  USING (true);

-- Grant necessary permissions
GRANT ALL ON populations TO authenticated;