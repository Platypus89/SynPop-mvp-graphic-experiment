/*
  # Update RLS policies for public access

  1. Changes
    - Drop existing RLS policies
    - Create new policies that allow public access for all operations
    - Keep RLS enabled for security but allow all operations

  2. Security
    - Policies allow all operations without requiring authentication
    - This is a temporary solution for development
    - In production, proper authentication should be implemented
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Users can manage their own profile" ON users;
DROP POLICY IF EXISTS "Users can manage their own populations" ON populations;
DROP POLICY IF EXISTS "Users can manage their own stimuli" ON stimuli;
DROP POLICY IF EXISTS "Users can manage their own simulations" ON simulations;

-- Create new public access policies
CREATE POLICY "Allow all operations on users"
  ON users FOR ALL
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Allow all operations on populations"
  ON populations FOR ALL
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Allow all operations on stimuli"
  ON stimuli FOR ALL
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Allow all operations on simulations"
  ON simulations FOR ALL
  USING (true)
  WITH CHECK (true);