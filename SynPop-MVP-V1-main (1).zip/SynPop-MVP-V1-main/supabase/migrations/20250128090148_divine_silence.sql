-- Add metadata column to populations table
ALTER TABLE populations 
ADD COLUMN IF NOT EXISTS metadata jsonb DEFAULT '{}'::jsonb;

-- Update RLS policies to include metadata column
DROP POLICY IF EXISTS "Enable access for authenticated users" ON populations;
CREATE POLICY "Enable access for authenticated users"
  ON populations FOR ALL
  TO authenticated
  USING (true);

-- Grant necessary permissions
GRANT ALL ON populations TO authenticated;