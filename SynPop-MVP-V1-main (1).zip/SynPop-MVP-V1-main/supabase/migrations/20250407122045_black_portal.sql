/*
  # Update stimuli type constraints

  1. Changes
    - Remove image and pdf types from stimuli table
    - Update type check constraint to only allow text
    - Add scale metadata validation
  
  2. Security
    - Maintain existing RLS policies
*/

-- Drop existing type check constraint
ALTER TABLE stimuli 
DROP CONSTRAINT IF EXISTS stimuli_type_check;

-- Add new type check constraint for text only
ALTER TABLE stimuli
ADD CONSTRAINT stimuli_type_check 
CHECK (type = 'text');

-- Add metadata validation for scale
ALTER TABLE stimuli
ADD CONSTRAINT valid_scale_metadata
CHECK (
  metadata IS NULL OR (
    metadata ? 'scale' AND
    jsonb_typeof(metadata->'scale') = 'object' AND
    metadata->'scale' ? 'type' AND
    metadata->'scale'->>'type' IN ('likert', 'binary', 'custom')
  )
);