/*
  # User Roles and Authentication Setup

  1. Changes
    - Create user roles table
    - Set up admin function
    - Add RLS policies
    - Create initial admin user role

  2. Security
    - Enable RLS on user_roles table
    - Add proper access policies
    - Secure role management

  3. Notes
    - Works with existing Supabase auth schema
    - Preserves existing auth functionality
    - Adds role-based access control
*/

-- Drop existing objects if they exist
DROP TABLE IF EXISTS user_roles CASCADE;
DROP FUNCTION IF EXISTS is_admin CASCADE;

-- Create user roles table
CREATE TABLE user_roles (
  user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  role text NOT NULL CHECK (role IN ('admin', 'user')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE user_roles ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
CREATE POLICY "Users can read own role"
  ON user_roles
  FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Admins can manage roles"
  ON user_roles
  FOR ALL
  USING (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE user_id = auth.uid()
      AND role = 'admin'
    )
  );

-- Create admin check function
CREATE OR REPLACE FUNCTION is_admin()
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM user_roles
    WHERE user_id = auth.uid()
    AND role = 'admin'
  );
END;
$$;

-- Create trigger for updating timestamps
CREATE OR REPLACE FUNCTION update_user_roles_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_user_roles_timestamp
  BEFORE UPDATE ON user_roles
  FOR EACH ROW
  EXECUTE FUNCTION update_user_roles_updated_at();

-- Set up initial admin user
DO $$
DECLARE
  admin_user_id uuid;
BEGIN
  -- Get the user ID if exists
  SELECT id INTO admin_user_id
  FROM auth.users
  WHERE email = 'matteo.gelpi@synpop.ai'
  LIMIT 1;

  -- If user exists, ensure they have admin role
  IF admin_user_id IS NOT NULL THEN
    INSERT INTO user_roles (user_id, role)
    VALUES (admin_user_id, 'admin')
    ON CONFLICT (user_id) 
    DO UPDATE SET role = 'admin';
  END IF;
END $$;