/*
  # Add indexes for better query performance

  1. Changes
    - Add indexes on frequently queried columns
    - Add indexes for foreign keys
    - Add indexes for sorting columns
  
  2. Security
    - Maintain existing RLS policies
*/

-- Add indexes for simulations table
CREATE INDEX IF NOT EXISTS idx_simulations_created_at ON simulations(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_simulations_population_id ON simulations(population_id);
CREATE INDEX IF NOT EXISTS idx_simulations_stimulus_id ON simulations(stimulus_id);
CREATE INDEX IF NOT EXISTS idx_simulations_status ON simulations(status);

-- Add indexes for populations table
CREATE INDEX IF NOT EXISTS idx_populations_created_at ON populations(created_at DESC);

-- Add indexes for stimuli table
CREATE INDEX IF NOT EXISTS idx_stimuli_created_at ON stimuli(created_at DESC);