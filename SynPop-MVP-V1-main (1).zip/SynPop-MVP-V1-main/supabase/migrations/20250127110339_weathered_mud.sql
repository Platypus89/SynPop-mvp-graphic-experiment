-- Drop existing tables and functions
DROP TABLE IF EXISTS user_roles CASCADE;
DROP FUNCTION IF EXISTS get_user_role CASCADE;

-- Create a simplified user_roles table
CREATE TABLE user_roles (
  user_id uuid PRIMARY KEY,
  role text NOT NULL DEFAULT 'user',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT valid_role CHECK (role IN ('admin', 'user'))
);

-- Enable RLS
ALTER TABLE user_roles ENABLE ROW LEVEL SECURITY;

-- Create simple RLS policies
CREATE POLICY "Enable read access for all users"
  ON user_roles FOR SELECT
  USING (true);

-- Create policy for users to update their own role
CREATE POLICY "Users can update own role"
  ON user_roles FOR UPDATE
  USING (auth.uid() = user_id);

-- Create policy for inserting new roles
CREATE POLICY "Enable insert for authenticated users"
  ON user_roles FOR INSERT
  WITH CHECK (auth.uid() = user_id);

-- Create function to check if user is admin
CREATE OR REPLACE FUNCTION is_admin()
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM user_roles
    WHERE user_id = auth.uid()
    AND role = 'admin'
  );
END;
$$;