/*
  # Optimize database performance for populations table

  1. Changes
    - Add composite indexes for efficient querying
    - Add indexes for sorting and filtering
    - Add indexes for pagination
  
  2. Security
    - Maintain existing RLS policies
*/

-- Add composite indexes for efficient querying
CREATE INDEX IF NOT EXISTS idx_populations_user_created ON populations(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_populations_size_created ON populations(size, created_at DESC);

-- Add indexes for sorting and filtering
CREATE INDEX IF NOT EXISTS idx_populations_created_at ON populations(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_populations_size ON populations(size);

-- Add index for metadata to improve JSONB queries
CREATE INDEX IF NOT EXISTS idx_populations_metadata ON populations USING gin(metadata jsonb_path_ops);

-- Add index for attributes to improve JSONB queries
CREATE INDEX IF NOT EXISTS idx_populations_attributes ON populations USING gin(attributes jsonb_path_ops);

-- Analyze tables to update statistics
ANALYZE populations;