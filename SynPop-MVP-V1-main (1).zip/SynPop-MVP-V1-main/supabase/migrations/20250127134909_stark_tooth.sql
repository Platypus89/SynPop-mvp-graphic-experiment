-- Drop existing objects to start fresh
DROP TABLE IF EXISTS users CASCADE;
DROP FUNCTION IF EXISTS is_admin CASCADE;

-- Create users table with user_role column
CREATE TABLE users (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text UNIQUE NOT NULL,
  user_role text NOT NULL DEFAULT 'user' CHECK (user_role IN ('admin', 'user')),
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE users ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Enable read access for all users"
  ON users FOR SELECT
  USING (true);

CREATE POLICY "Enable self update"
  ON users FOR UPDATE
  USING (auth.uid() = id);

CREATE POLICY "Enable insert for auth users"
  ON users FOR INSERT
  WITH CHECK (auth.uid() = id);

-- Create admin check function using user_role
CREATE OR REPLACE FUNCTION is_admin()
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM users
    WHERE id = auth.uid()
    AND user_role = 'admin'
  );
END;
$$;

-- Grant necessary permissions
GRANT USAGE ON SCHEMA public TO anon, authenticated;
GRANT ALL ON users TO authenticated;
GRANT SELECT ON users TO anon;
GRANT EXECUTE ON FUNCTION is_admin TO authenticated;

-- Create policies for other tables
ALTER TABLE populations ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Enable all access for authenticated users" ON populations;
CREATE POLICY "Enable all access for authenticated users"
  ON populations FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

ALTER TABLE stimuli ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Enable all access for authenticated users" ON stimuli;
CREATE POLICY "Enable all access for authenticated users"
  ON stimuli FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

ALTER TABLE simulations ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Enable all access for authenticated users" ON simulations;
CREATE POLICY "Enable all access for authenticated users"
  ON simulations FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Ensure admin user exists and has correct role
DO $$ 
DECLARE
  admin_email text := 'matteo.gelpi@synpop.ai';
  admin_id uuid;
BEGIN
  -- Get or create admin user ID
  SELECT id INTO admin_id
  FROM auth.users
  WHERE email = admin_email;

  IF admin_id IS NOT NULL THEN
    -- Ensure admin exists in users table with correct role
    INSERT INTO users (id, email, user_role)
    VALUES (admin_id, admin_email, 'admin')
    ON CONFLICT (id) DO UPDATE
    SET user_role = 'admin';
  END IF;
END $$;

-- Sync existing users
INSERT INTO users (id, email, user_role)
SELECT 
  id,
  email,
  'user' as user_role
FROM auth.users
WHERE id NOT IN (SELECT id FROM users)
ON CONFLICT (id) DO NOTHING;