-- First ensure the users table has the correct structure
CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text UNIQUE NOT NULL,
  role text NOT NULL DEFAULT 'user' CHECK (role IN ('admin', 'user')),
  created_at timestamptz DEFAULT now()
);

-- Ensure RLS is enabled
ALTER TABLE users ENABLE ROW LEVEL SECURITY;

-- Drop any existing policies to avoid conflicts
DROP POLICY IF EXISTS "Enable read access for authenticated users" ON users;
DROP POLICY IF EXISTS "Enable update for users based on id" ON users;
DROP POLICY IF EXISTS "Users can read all users" ON users;
DROP POLICY IF EXISTS "Users can update their own record" ON users;

-- Create new policies
CREATE POLICY "Enable read access for all users"
  ON users FOR SELECT
  USING (true);

CREATE POLICY "Enable self update"
  ON users FOR UPDATE
  USING (auth.uid() = id);

CREATE POLICY "Enable insert for auth users"
  ON users FOR INSERT
  WITH CHECK (auth.uid() = id);

-- Ensure admin function exists and is correct
CREATE OR REPLACE FUNCTION is_admin()
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM users
    WHERE id = auth.uid()
    AND role = 'admin'
  );
END;
$$;

-- Ensure permissions are correct
GRANT USAGE ON SCHEMA public TO anon, authenticated;
GRANT ALL ON users TO authenticated;
GRANT SELECT ON users TO anon;

-- Sync all existing auth users to ensure no one is missing
INSERT INTO users (id, email, role)
SELECT 
  au.id,
  au.email,
  CASE 
    WHEN au.email = 'matteo.gelpi@synpop.ai' THEN 'admin'
    ELSE 'user'
  END as role
FROM auth.users au
LEFT JOIN users u ON au.id = u.id
WHERE u.id IS NULL;

-- Update any existing users to ensure admin has correct role
UPDATE users 
SET role = 'admin'
WHERE email = 'matteo.gelpi@synpop.ai';