/*
  # Make user_id nullable in tables

  1. Changes
    - Modify user_id columns to be nullable in all tables
    - This allows creating records without requiring user authentication
    - Temporary solution for development

  2. Security
    - Tables can now accept records without user association
    - RLS policies already allow all operations
*/

-- Modify populations table
ALTER TABLE populations
  ALTER COLUMN user_id DROP NOT NULL;

-- Modify stimuli table
ALTER TABLE stimuli
  ALTER COLUMN user_id DROP NOT NULL;

-- Modify simulations table
ALTER TABLE simulations
  ALTER COLUMN user_id DROP NOT NULL;