/*
  # Fix Expert Reflections Constraint

  1. Changes
    - Drop existing constraint
    - Add new constraint with proper validation
    - Initialize existing records
  
  2. Security
    - Maintain existing RLS policies
*/

-- Drop existing constraint
ALTER TABLE populations 
DROP CONSTRAINT IF EXISTS valid_expert_reflections;

-- Initialize expert_reflections for existing records
UPDATE populations
SET expert_reflections = jsonb_build_object(
  'financial', '',
  'career', '',
  'lifestyle', '',
  'mental_health', '',
  'relationship', ''
)
WHERE expert_reflections IS NULL 
   OR expert_reflections = '{}'::jsonb
   OR NOT (
     expert_reflections ? 'financial' AND
     expert_reflections ? 'career' AND
     expert_reflections ? 'lifestyle' AND
     expert_reflections ? 'mental_health' AND
     expert_reflections ? 'relationship'
   );

-- Add new constraint with proper structure and validation
ALTER TABLE populations
ADD CONSTRAINT valid_expert_reflections CHECK (
  expert_reflections IS NULL OR (
    expert_reflections ? 'financial' AND
    expert_reflections ? 'career' AND
    expert_reflections ? 'lifestyle' AND
    expert_reflections ? 'mental_health' AND
    expert_reflections ? 'relationship' AND
    jsonb_typeof(expert_reflections->'financial') = 'string' AND
    jsonb_typeof(expert_reflections->'career') = 'string' AND
    jsonb_typeof(expert_reflections->'lifestyle') = 'string' AND
    jsonb_typeof(expert_reflections->'mental_health') = 'string' AND
    jsonb_typeof(expert_reflections->'relationship') = 'string'
  )
);