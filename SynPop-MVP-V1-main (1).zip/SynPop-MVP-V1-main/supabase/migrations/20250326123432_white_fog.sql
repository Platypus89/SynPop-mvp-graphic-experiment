/*
  # Add indexes and optimize query performance

  1. Changes
    - Add indexes on frequently queried columns
    - Add indexes for foreign keys and sorting
    - Add indexes for status and metadata
  
  2. Security
    - Maintain existing RLS policies
*/

-- Add composite indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_simulations_user_status ON simulations(user_id, status);
CREATE INDEX IF NOT EXISTS idx_simulations_population_created ON simulations(population_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_simulations_stimulus_created ON simulations(stimulus_id, created_at DESC);

-- Add indexes for populations table
CREATE INDEX IF NOT EXISTS idx_populations_user_created ON populations(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_populations_size ON populations(size);

-- Add indexes for stimuli table
CREATE INDEX IF NOT EXISTS idx_stimuli_user_created ON stimuli(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_stimuli_type ON stimuli(type);

-- Add indexes for metadata and status
CREATE INDEX IF NOT EXISTS idx_simulations_status_created ON simulations(status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_populations_metadata ON populations USING gin(metadata jsonb_path_ops);
CREATE INDEX IF NOT EXISTS idx_stimuli_metadata ON stimuli USING gin(metadata jsonb_path_ops);