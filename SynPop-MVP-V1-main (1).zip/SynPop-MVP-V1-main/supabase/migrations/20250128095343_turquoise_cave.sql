-- Drop existing foreign key constraint
ALTER TABLE simulations
DROP CONSTRAINT IF EXISTS simulations_population_id_fkey;

-- Re-create foreign key with ON DELETE CASCADE
ALTER TABLE simulations
ADD CONSTRAINT simulations_population_id_fkey
FOREIGN KEY (population_id)
REFERENCES populations(id)
ON DELETE CASCADE;

-- Update RLS policies to ensure proper cascading
DROP POLICY IF EXISTS "Enable access for authenticated users" ON simulations;
CREATE POLICY "Enable access for authenticated users"
  ON simulations FOR ALL
  TO authenticated
  USING (true);

-- Grant necessary permissions
GRANT ALL ON simulations TO authenticated;