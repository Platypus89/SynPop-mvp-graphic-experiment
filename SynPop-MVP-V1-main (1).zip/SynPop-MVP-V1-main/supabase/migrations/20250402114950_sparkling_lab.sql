/*
  # Add expert reflections to populations table

  1. Changes
    - Drop existing constraint if exists
    - Add expert_reflections column
    - Add indexes for efficient querying
    - Add check constraint after data initialization
  
  2. Security
    - Maintain existing RLS policies
*/

-- Drop existing constraint if it exists
ALTER TABLE populations 
DROP CONSTRAINT IF EXISTS valid_expert_reflections;

-- Add expert_reflections column if it doesn't exist
ALTER TABLE populations 
ADD COLUMN IF NOT EXISTS expert_reflections jsonb DEFAULT '{}'::jsonb;

-- Add index for expert_reflections to improve JSONB queries
CREATE INDEX IF NOT EXISTS idx_populations_expert_reflections 
ON populations USING gin(expert_reflections jsonb_path_ops);

-- Add index for efficient querying of populations with expert reflections
CREATE INDEX IF NOT EXISTS idx_populations_has_expert_reflections
ON populations ((expert_reflections IS NOT NULL));

-- Initialize expert_reflections for existing populations
UPDATE populations
SET expert_reflections = jsonb_build_object(
  'financial', '',
  'career', '',
  'lifestyle', '',
  'mental_health', '',
  'relationship', ''
)
WHERE expert_reflections IS NULL OR expert_reflections = '{}'::jsonb;

-- Now that data is initialized, add the constraint
ALTER TABLE populations
ADD CONSTRAINT valid_expert_reflections CHECK (
  expert_reflections IS NULL OR (
    expert_reflections ? 'financial' AND
    expert_reflections ? 'career' AND
    expert_reflections ? 'lifestyle' AND
    expert_reflections ? 'mental_health' AND
    expert_reflections ? 'relationship'
  )
);

-- Update RLS policies to ensure proper access
DROP POLICY IF EXISTS "Enable access for authenticated users" ON populations;
CREATE POLICY "Enable access for authenticated users"
  ON populations FOR ALL
  TO authenticated
  USING (true);

-- Grant necessary permissions
GRANT ALL ON populations TO authenticated;

-- Analyze table to update statistics
ANALYZE populations;