/*
  # Set up initial admin user and role
  
  1. Changes
    - Creates admin user if not exists
    - Assigns admin role
  
  2. Security
    - Uses secure password handling
    - Sets up initial admin access
*/

-- First ensure the user exists in auth.users
DO $$ 
BEGIN
  -- Only proceed if the user doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM auth.users 
    WHERE email = 'matteo.gelpi@synpop.ai'
  ) THEN
    -- Insert the user into auth.users with correct columns
    INSERT INTO auth.users (
      instance_id,
      id,
      aud,
      email,
      encrypted_password,
      email_confirmed_at,
      invited_at,
      confirmation_token,
      confirmation_sent_at,
      recovery_token,
      recovery_sent_at,
      email_change_token_new,
      email_change,
      email_change_sent_at,
      last_sign_in_at,
      raw_app_meta_data,
      raw_user_meta_data,
      is_super_admin,
      created_at,
      updated_at,
      phone,
      phone_confirmed_at,
      phone_change,
      phone_change_token,
      phone_change_sent_at,
      email_change_token_current,
      email_change_confirm_status,
      banned_until,
      reauthentication_token,
      reauthentication_sent_at
    )
    VALUES (
      '00000000-0000-0000-0000-000000000000',
      gen_random_uuid(),
      'authenticated',
      'matteo.gelpi@synpop.ai',
      crypt('Synpop1234!', gen_salt('bf')),
      now(),
      null,
      '',
      null,
      '',
      null,
      '',
      '',
      null,
      null,
      '{"provider":"email","providers":["email"]}',
      '{}',
      false,
      now(),
      now(),
      null,
      null,
      '',
      '',
      null,
      '',
      0,
      null,
      '',
      null
    );
  END IF;
END $$;

-- Now we can safely add the admin role
DO $$ 
DECLARE
  admin_user_id uuid;
BEGIN
  -- Get the user ID (now we know it exists)
  SELECT id INTO admin_user_id 
  FROM auth.users 
  WHERE email = 'matteo.gelpi@synpop.ai';

  -- Add admin role if not already present
  INSERT INTO user_roles (user_id, role)
  VALUES (admin_user_id, 'admin')
  ON CONFLICT (user_id) 
  DO UPDATE SET role = 'admin';
END $$;