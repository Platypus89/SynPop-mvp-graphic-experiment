-- Drop and recreate users table with proper structure
DROP TABLE IF EXISTS users CASCADE;

CREATE TABLE users (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text UNIQUE NOT NULL,
  role text NOT NULL DEFAULT 'user' CHECK (role IN ('admin', 'user')),
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE users ENABLE ROW LEVEL SECURITY;

-- Drop any existing policies
DROP POLICY IF EXISTS "Enable read access for all users" ON users;
DROP POLICY IF EXISTS "Enable self update" ON users;
DROP POLICY IF EXISTS "Enable insert for auth users" ON users;

-- Create new policies
CREATE POLICY "Enable read access for all users"
  ON users FOR SELECT
  USING (true);

CREATE POLICY "Enable self update"
  ON users FOR UPDATE
  USING (auth.uid() = id);

CREATE POLICY "Enable insert for auth users"
  ON users FOR INSERT
  WITH CHECK (auth.uid() = id);

-- Create or replace admin check function
CREATE OR REPLACE FUNCTION is_admin()
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM users
    WHERE id = auth.uid()
    AND role = 'admin'
  );
END;
$$;

-- Ensure admin user exists and has correct role
DO $$ 
DECLARE
  admin_email text := 'matteo.gelpi@synpop.ai';
  admin_id uuid;
BEGIN
  -- Get the admin user ID if exists
  SELECT id INTO admin_id
  FROM auth.users
  WHERE email = admin_email;

  -- If admin exists, ensure they have the admin role
  IF admin_id IS NOT NULL THEN
    INSERT INTO users (id, email, role)
    VALUES (admin_id, admin_email, 'admin')
    ON CONFLICT (id) DO UPDATE
    SET role = 'admin';
  END IF;
END $$;