/*
  # Add metadata column to simulations table

  1. Changes
    - Add metadata column to simulations table to store simulation configuration
  
  2. Security
    - Maintain existing RLS policies
*/

-- Add metadata column if it doesn't exist
ALTER TABLE simulations 
ADD COLUMN IF NOT EXISTS metadata jsonb DEFAULT '{}'::jsonb;

-- Update RLS policies to include metadata column
DROP POLICY IF EXISTS "Enable access for authenticated users" ON simulations;
CREATE POLICY "Enable access for authenticated users"
  ON simulations FOR ALL
  TO authenticated
  USING (true);

-- Grant necessary permissions
GRANT ALL ON simulations TO authenticated;