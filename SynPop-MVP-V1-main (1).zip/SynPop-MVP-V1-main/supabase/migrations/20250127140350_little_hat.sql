-- Drop existing objects to start fresh
DROP TABLE IF EXISTS users CASCADE;
DROP FUNCTION IF EXISTS is_admin CASCADE;

-- Create users table with proper structure
CREATE TABLE users (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text UNIQUE NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE users ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Enable read access for all users"
  ON users FOR SELECT
  USING (true);

CREATE POLICY "Enable self update"
  ON users FOR UPDATE
  USING (auth.uid() = id);

CREATE POLICY "Enable insert for auth users"
  ON users FOR INSERT
  WITH CHECK (auth.uid() = id);

-- Create policies for other tables
ALTER TABLE populations ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Enable access for authenticated users" ON populations;
CREATE POLICY "Enable access for authenticated users"
  ON populations FOR ALL
  TO authenticated
  USING (true);

ALTER TABLE stimuli ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Enable access for authenticated users" ON stimuli;
CREATE POLICY "Enable access for authenticated users"
  ON stimuli FOR ALL
  TO authenticated
  USING (true);

ALTER TABLE simulations ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Enable access for authenticated users" ON simulations;
CREATE POLICY "Enable access for authenticated users"
  ON simulations FOR ALL
  TO authenticated
  USING (true);

-- Grant necessary permissions
GRANT USAGE ON SCHEMA public TO anon, authenticated;
GRANT ALL ON users TO authenticated;
GRANT SELECT ON users TO anon;