-- Drop the role column from users table since we have user_roles
ALTER TABLE users DROP COLUMN IF EXISTS role;

-- Ensure we have proper indexes
CREATE INDEX IF NOT EXISTS idx_user_roles_user_id ON user_roles(user_id);
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);

-- Sync existing auth users to public users
INSERT INTO users (id, email, created_at)
SELECT 
  id,
  email,
  COALESCE(created_at, now())
FROM auth.users
ON CONFLICT (id) DO NOTHING;

-- Ensure all users have a role
INSERT INTO user_roles (user_id, role)
SELECT 
  u.id,
  'user'
FROM users u
LEFT JOIN user_roles ur ON u.id = ur.user_id
WHERE ur.user_id IS NULL;

-- Grant necessary permissions
GRANT SELECT ON users TO authenticated;
GRANT SELECT ON user_roles TO authenticated;