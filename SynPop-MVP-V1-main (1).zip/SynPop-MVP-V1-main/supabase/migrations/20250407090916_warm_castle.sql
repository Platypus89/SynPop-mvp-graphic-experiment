/*
  # Fix RLS Policies for Populations Table

  1. Changes
    - Drop existing policies
    - Create new public read policy
    - Create new authenticated user policy
    - Enable RLS
    - Grant permissions

  2. Security
    - Allow public read access
    - Restrict write access to authenticated users
*/

-- Drop existing policies
DROP POLICY IF EXISTS "populations_public_read" ON populations;
DROP POLICY IF EXISTS "populations_auth_write" ON populations;
DROP POLICY IF EXISTS "Enable access for authenticated users" ON populations;
DROP POLICY IF EXISTS "Enable read access for all users" ON populations;
DROP POLICY IF EXISTS "Allow public read access to populations" ON populations;
DROP POLICY IF EXISTS "Authenticated users can manage their own populations" ON populations;

-- Create new policies
CREATE POLICY "populations_public_read"
  ON populations FOR SELECT
  USING (true);

CREATE POLICY "populations_auth_write"
  ON populations FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Ensure RLS is enabled
ALTER TABLE populations ENABLE ROW LEVEL SECURITY;

-- Grant necessary permissions
GRANT ALL ON populations TO authenticated;
GRANT SELECT ON populations TO public;