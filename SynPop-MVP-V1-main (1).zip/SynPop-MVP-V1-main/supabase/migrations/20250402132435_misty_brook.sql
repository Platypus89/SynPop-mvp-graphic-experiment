/*
  # Fix expert reflections constraint and structure

  1. Changes
    - Drop existing constraint
    - Add new constraint with proper structure
    - Add helper function for validation
  
  2. Security
    - Maintain existing RLS policies
*/

-- Drop existing constraint
ALTER TABLE populations 
DROP CONSTRAINT IF EXISTS valid_expert_reflections;

-- Add new constraint with proper structure
ALTER TABLE populations
ADD CONSTRAINT valid_expert_reflections CHECK (
  expert_reflections IS NULL OR (
    expert_reflections ? 'financial' AND
    expert_reflections ? 'career' AND
    expert_reflections ? 'lifestyle' AND
    expert_reflections ? 'mental_health' AND
    expert_reflections ? 'relationship' AND
    jsonb_typeof(expert_reflections->'financial') = 'string' AND
    jsonb_typeof(expert_reflections->'career') = 'string' AND
    jsonb_typeof(expert_reflections->'lifestyle') = 'string' AND
    jsonb_typeof(expert_reflections->'mental_health') = 'string' AND
    jsonb_typeof(expert_reflections->'relationship') = 'string'
  )
);