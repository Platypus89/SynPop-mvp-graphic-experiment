import React, { useState } from 'react';
import { ArrowLeft, ArrowRight, Check, Users, Settings as SettingsIcon, FileText, MessageSquare, Target, Zap } from 'lucide-react';
import type { Population, Stimulus, Simulation } from '../types';

interface GuidedSimulationProps {
  type: 'survey' | 'poll' | 'focus-group';
  populations: Population[];
  stimuli: Stimulus[];
  onSimulationCreate: (simulation: Simulation) => void;
  onBack: () => void;
}

interface FormData {
  name: string;
  description: string;
  populationId: string;
  stimulusId: string;
  customSettings: {
    responseScale?: 'likert' | 'binary' | 'custom';
    customScaleOptions?: string[];
    focusGroupSize?: number;
    discussionTopics?: string[];
    moderationStyle?: 'directive' | 'non-directive';
    interactionLevel?: 'high' | 'medium' | 'low';
    temperature?: number;
  };
}

export function GuidedSimulation({ 
  type, 
  populations, 
  stimuli, 
  onSimulationCreate, 
  onBack 
}: GuidedSimulationProps) {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState<FormData>({
    name: '',
    description: '',
    populationId: '',
    stimulusId: '',
    customSettings: {
      responseScale: 'likert',
      temperature: 0.7
    }
  });

  const typeConfig = {
    'survey': {
      title: 'Survey Simulation',
      description: 'Create a detailed survey simulation with multiple questions and response options.',
      steps: [
        'Basic Information',
        'Select Population',
        'Define Questions',
        'Configure Settings',
        'Review'
      ],
      icon: FileText
    },
    'poll': {
      title: 'Poll Simulation',
      description: 'Quick simulation for simple yes/no or multiple choice questions.',
      steps: [
        'Basic Information',
        'Select Population',
        'Define Poll Question',
        'Review'
      ],
      icon: Target
    },
    'focus-group': {
      title: 'Focus Group Simulation',
      description: 'Simulate in-depth group discussions with detailed interactions.',
      steps: [
        'Basic Information',
        'Define Group',
        'Set Discussion Topics',
        'Configure Dynamics',
        'Review'
      ],
      icon: MessageSquare
    }
  };

  const config = typeConfig[type];
  const Icon = config.icon;

  const validateStep = (currentStep: number): boolean => {
    switch (currentStep) {
      case 1:
        return formData.name.trim() !== '';
      case 2:
        return formData.populationId !== '';
      case 3:
        if (type === 'focus-group') {
          return (formData.customSettings.discussionTopics?.length || 0) > 0;
        }
        return true;
      default:
        return true;
    }
  };

  const handleNext = () => {
    if (step < config.steps.length) {
      setStep(step + 1);
    } else {
      handleSubmit();
    }
  };

  const handleBack = () => {
    if (step > 1) {
      setStep(step - 1);
    } else {
      onBack();
    }
  };

  const handleSubmit = () => {
    const simulation: Simulation = {
      id: crypto.randomUUID(),
      name: formData.name,
      description: formData.description,
      population_id: formData.populationId,
      stimulus_id: formData.stimulusId,
      status: 'in-progress',
      type: type,
      metadata: {
        ...formData.customSettings,
        guided: true
      },
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    onSimulationCreate(simulation);
  };

  const renderStepContent = () => {
    switch (type) {
      case 'survey':
        return renderSurveyStep();
      case 'poll':
        return renderPollStep();
      case 'focus-group':
        return renderFocusGroupStep();
      default:
        return null;
    }
  };

  const renderSurveyStep = () => {
    switch (step) {
      case 1: // Basic Information
        return (
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Survey Name
              </label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                placeholder="Enter a name for your survey"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Description
              </label>
              <textarea
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                rows={3}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                placeholder="Describe the purpose of this survey"
              />
            </div>
          </div>
        );

      case 2: // Select Population
        return (
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Target Population
              </label>
              <select
                value={formData.populationId}
                onChange={(e) => setFormData({ ...formData, populationId: e.target.value })}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              >
                <option value="">Select a population</option>
                {populations.map((pop) => (
                  <option key={pop.id} value={pop.id}>
                    {pop.name} ({pop.size.toLocaleString()} individuals)
                  </option>
                ))}
              </select>
            </div>
          </div>
        );

      case 3: // Define Questions
        return (
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Response Scale
              </label>
              <select
                value={formData.customSettings.responseScale}
                onChange={(e) => setFormData({
                  ...formData,
                  customSettings: {
                    ...formData.customSettings,
                    responseScale: e.target.value as 'likert' | 'binary' | 'custom'
                  }
                })}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              >
                <option value="likert">5-point Likert Scale</option>
                <option value="binary">Yes/No</option>
                <option value="custom">Custom Scale</option>
              </select>
            </div>

            {formData.customSettings.responseScale === 'custom' && (
              <div className="space-y-2">
                <label className="block text-sm font-medium text-gray-700">
                  Custom Scale Options
                </label>
                {(formData.customSettings.customScaleOptions || ['']).map((option, index) => (
                  <div key={index} className="flex gap-2">
                    <input
                      type="text"
                      value={option}
                      onChange={(e) => {
                        const newOptions = [...(formData.customSettings.customScaleOptions || [''])];
                        newOptions[index] = e.target.value;
                        setFormData({
                          ...formData,
                          customSettings: {
                            ...formData.customSettings,
                            customScaleOptions: newOptions
                          }
                        });
                      }}
                      className="flex-1 rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                      placeholder={`Option ${index + 1}`}
                    />
                    <button
                      onClick={() => {
                        const newOptions = [...(formData.customSettings.customScaleOptions || [''])];
                        newOptions.splice(index, 1);
                        setFormData({
                          ...formData,
                          customSettings: {
                            ...formData.customSettings,
                            customScaleOptions: newOptions
                          }
                        });
                      }}
                      className="text-red-500 hover:text-red-700"
                    >
                      Remove
                    </button>
                  </div>
                ))}
                <button
                  onClick={() => {
                    setFormData({
                      ...formData,
                      customSettings: {
                        ...formData.customSettings,
                        customScaleOptions: [...(formData.customSettings.customScaleOptions || ['']), '']
                      }
                    });
                  }}
                  className="text-blue-600 hover:text-blue-700 text-sm"
                >
                  + Add Option
                </button>
              </div>
            )}
          </div>
        );

      case 4: // Configure Settings
        return (
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Response Temperature
              </label>
              <div className="mt-1">
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.1"
                  value={formData.customSettings.temperature}
                  onChange={(e) => setFormData({
                    ...formData,
                    customSettings: {
                      ...formData.customSettings,
                      temperature: parseFloat(e.target.value)
                    }
                  })}
                  className="w-full"
                />
                <div className="flex justify-between text-sm text-gray-500">
                  <span>More Consistent</span>
                  <span>More Variable</span>
                </div>
              </div>
            </div>
          </div>
        );

      case 5: // Review
        return (
          <div className="space-y-4">
            <div className="bg-gray-50 p-4 rounded-lg">
              <h3 className="text-lg font-medium text-gray-900 mb-4">Survey Configuration</h3>
              <dl className="grid grid-cols-1 gap-4">
                <div>
                  <dt className="text-sm font-medium text-gray-500">Name</dt>
                  <dd className="text-sm text-gray-900">{formData.name}</dd>
                </div>
                <div>
                  <dt className="text-sm font-medium text-gray-500">Description</dt>
                  <dd className="text-sm text-gray-900">{formData.description}</dd>
                </div>
                <div>
                  <dt className="text-sm font-medium text-gray-500">Population</dt>
                  <dd className="text-sm text-gray-900">
                    {populations.find(p => p.id === formData.populationId)?.name}
                  </dd>
                </div>
                <div>
                  <dt className="text-sm font-medium text-gray-500">Response Scale</dt>
                  <dd className="text-sm text-gray-900">{formData.customSettings.responseScale}</dd>
                </div>
                <div>
                  <dt className="text-sm font-medium text-gray-500">Temperature</dt>
                  <dd className="text-sm text-gray-900">{formData.customSettings.temperature}</dd>
                </div>
              </dl>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  const renderPollStep = () => {
    switch (step) {
      case 1: // Basic Information
        return (
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Poll Name
              </label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                placeholder="Enter a name for your poll"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Description
              </label>
              <textarea
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                rows={3}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                placeholder="Describe the purpose of this poll"
              />
            </div>
          </div>
        );

      case 2: // Select Population
        return (
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Target Population
              </label>
              <select
                value={formData.populationId}
                onChange={(e) => setFormData({ ...formData, populationId: e.target.value })}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              >
                <option value="">Select a population</option>
                {populations.map((pop) => (
                  <option key={pop.id} value={pop.id}>
                    {pop.name} ({pop.size.toLocaleString()} individuals)
                  </option>
                ))}
              </select>
            </div>
          </div>
        );

      case 3: // Define Poll Question
        return (
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Question Type
              </label>
              <select
                value={formData.customSettings.responseScale}
                onChange={(e) => setFormData({
                  ...formData,
                  customSettings: {
                    ...formData.customSettings,
                    responseScale: e.target.value as 'binary' | 'custom'
                  }
                })}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              >
                <option value="binary">Yes/No</option>
                <option value="custom">Multiple Choice</option>
              </select>
            </div>

            {formData.customSettings.responseScale === 'custom' && (
              <div className="space-y-2">
                <label className="block text-sm font-medium text-gray-700">
                  Answer Options
                </label>
                {(formData.customSettings.customScaleOptions || ['']).map((option, index) => (
                  <div key={index} className="flex gap-2">
                    <input
                      type="text"
                      value={option}
                      onChange={(e) => {
                        const newOptions = [...(formData.customSettings.customScaleOptions || [''])];
                        newOptions[index] = e.target.value;
                        setFormData({
                          ...formData,
                          customSettings: {
                            ...formData.customSettings,
                            customScaleOptions: newOptions
                          }
                        });
                      }}
                      className="flex-1 rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                      placeholder={`Option ${index + 1}`}
                    />
                    <button
                      onClick={() => {
                        const newOptions = [...(formData.customSettings.customScaleOptions || [''])];
                        newOptions.splice(index, 1);
                        setFormData({
                          ...formData,
                          customSettings: {
                            ...formData.customSettings,
                            customScaleOptions: newOptions
                          }
                        });
                      }}
                      className="text-red-500 hover:text-red-700"
                    >
                      Remove
                    </button>
                  </div>
                ))}
                <button
                  onClick={() => {
                    setFormData({
                      ...formData,
                      customSettings: {
                        ...formData.customSettings,
                        customScaleOptions: [...(formData.customSettings.customScaleOptions || ['']), '']
                      }
                    });
                  }}
                  className="text-blue-600 hover:text-blue-700 text-sm"
                >
                  + Add Option
                </button>
              </div>
            )}
          </div>
        );

      case 4: // Review
        return (
          <div className="space-y-4">
            <div className="bg-gray-50 p-4 rounded-lg">
              <h3 className="text-lg font-medium text-gray-900 mb-4">Poll Configuration</h3>
              <dl className="grid grid-cols-1 gap-4">
                <div>
                  <dt className="text-sm font-medium text-gray-500">Name</dt>
                  <dd className="text-sm text-gray-900">{formData.name}</dd>
                </div>
                <div>
                  <dt className="text-sm font-medium text-gray-500">Description</dt>
                  <dd className="text-sm text-gray-900">{formData.description}</dd>
                </div>
                <div>
                  <dt className="text-sm font-medium text-gray-500">Population</dt>
                  <dd className="text-sm text-gray-900">
                    {populations.find(p => p.id === formData.populationId)?.name}
                  </dd>
                </div>
                <div>
                  <dt className="text-sm font-medium text-gray-500">Question Type</dt>
                  <dd className="text-sm text-gray-900">{formData.customSettings.responseScale}</dd>
                </div>
                {formData.customSettings.responseScale === 'custom' && (
                  <div>
                    <dt className="text-sm font-medium text-gray-500">Options</dt>
                    <dd className="text-sm text-gray-900">
                      <ul className="list-disc list-inside">
                        {formData.customSettings.customScaleOptions?.map((option, index) => (
                          <li key={index}>{option}</li>
                        ))}
                      </ul>
                    </dd>
                  </div>
                )}
              </dl>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  const renderFocusGroupStep = () => {
    switch (step) {
      case 1: // Basic Information
        return (
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Focus Group Name
              </label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                placeholder="Enter a name for your focus group"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Description
              </label>
              <textarea
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                rows={3}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                placeholder="Describe the purpose of this focus group"
              />
            </div>
          </div>
        );

      case 2: // Define Group
        return (
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Group Size
              </label>
              <select
                value={formData.customSettings.focusGroupSize}
                onChange={(e) => setFormData({
                  ...formData,
                  customSettings: {
                    ...formData.customSettings,
                    focusGroupSize: parseInt(e.target.value)
                  }
                })}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              >
                <option value={6}>Small (6 participants)</option>
                <option value={8}>Medium (8 participants)</option>
                <option value={10}>Large (10 participants)</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Target Population
              </label>
              <select
                value={formData.populationId}
                onChange={(e) => setFormData({ ...formData, populationId: e.target.value })}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              >
                <option value="">Select a population</option>
                {populations.map((pop) => (
                  <option key={pop.id} value={pop.id}>
                    {pop.name} ({pop.size.toLocaleString()} individuals)
                  </option>
                ))}
              </select>
            </div>
          </div>
        );

      case 3: // Set Discussion Topics
        return (
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Discussion Topics
              </label>
              {(formData.customSettings.discussionTopics || ['']).map((topic, index) => (
                <div key={index} className="flex gap-2 mt-2">
                  <input
                    type="text"
                    value={topic}
                    onChange={(e) => {
                      const newTopics = [...(formData.customSettings.discussionTopics || [''])];
                      newTopics[index] = e.target.value;
                      setFormData({
                        ...formData,
                        customSettings: {
                          ...formData.customSettings,
                          discussionTopics: newTopics
                        }
                      });
                    }}
                    className="flex-1 rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    placeholder={`Topic ${index + 1}`}
                  />
                  <button
                    onClick={() => {
                      const newTopics = [...(formData.customSettings.discussionTopics || [''])];
                      newTopics.splice(index, 1);
                      setFormData({
                        ...formData,
                        customSettings: {
                          ...formData.customSettings,
                          discussionTopics: newTopics
                        }
                      });
                    }}
                    className="text-red-500 hover:text-red-700"
                  >
                    Remove
                  </button>
                </div>
              ))}
              <button
                onClick={() => {
                  setFormData({
                    ...formData,
                    customSettings: {
                      ...formData.customSettings,
                      discussionTopics: [...(formData.customSettings.discussionTopics || ['']), '']
                    }
                  });
                }}
                className="mt-2 text-blue-600 hover:text-blue-700 text-sm"
              >
                + Add Topic
              </button>
            </div>
          </div>
        );

      case 4: // Configure Dynamics
        return (
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Moderation Style
              </label>
              <select
                value={formData.customSettings.moderationStyle}
                onChange={(e) => setFormData({
                  ...formData,
                  customSettings: {
                    ...formData.customSettings,
                    moderationStyle: e.target.value as 'directive' | 'non-directive'
                  }
                })}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              >
                <option value="directive">Directive (More structured)</option>
                <option value="non-directive">Non-directive (More open-ended)</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Interaction Level
              </label>
              <select
                value={formData.customSettings.interactionLevel}
                onChange={(e) => setFormData({
                  ...formData,
                  customSettings: {
                    ...formData.customSettings,
                    interactionLevel: e.target.value as 'high' | 'medium' | 'low'
                  }
                })}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              >
                <option value="high">High (Frequent participant interaction)</option>
                <option value="medium">Medium (Balanced interaction)</option>
                <option value="low">Low (More individual responses)</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Response Temperature
              </label>
              <div className="mt-1">
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.1"
                  value={formData.customSettings.temperature}
                  onChange={(e) => setFormData({
                    ...formData,
                    customSettings: {
                      ...formData.customSettings,
                      temperature: parseFloat(e.target.value)
                    }
                  })}
                  className="w-full"
                />
                <div className="flex justify-between text-sm text-gray-500">
                  <span>More Consistent</span>
                  <span>More Variable</span>
                </div>
              </div>
            </div>
          </div>
        );

      case 5: // Review
        return (
          <div className="space-y-4">
            <div className="bg-gray-50 p-4 rounded-lg">
              <h3 className="text-lg font-medium text-gray-900 mb-4">Focus Group Configuration</h3>
              <dl className="grid grid-cols-1 gap-4">
                <div>
                  <dt className="text-sm font-medium text-gray-500">Name</dt>
                  <dd className="text-sm text-gray-900">{formData.name}</dd>
                </div>
                <div>
                  <dt className="text-sm font-medium text-gray-500">Description</dt>
                  <dd className="text-sm text-gray-900">{formData.description}</dd>
                </div>
                <div>
                  <dt className="text-sm font-medium text-gray-500">Group Size</dt>
                  <dd className="text-sm text-gray-900">{formData.customSettings.focusGroupSize} participants</dd>
                </div>
                <div>
                  <dt className="text-sm font-medium text-gray-500">Population</dt>
                  <dd className="text-sm text-gray-900">
                    {populations.find(p => p.id === formData.populationId)?.name}
                  </dd>
                </div>
                <div>
                  <dt className="text-sm font-medium text-gray-500">Topics</dt>
                  <dd className="text-sm text-gray-900">
                    <ul className="list-disc list-inside">
                      {formData.customSettings.discussionTopics?.map((topic, index) => (
                        <li key={index}>{topic}</li>
                      ))}
                    </ul>
                  </dd>
                </div>
                <div>
                  <dt className="text-sm font-medium text-gray-500">Moderation Style</dt>
                  <dd className="text-sm text-gray-900">{formData.customSettings.moderationStyle}</dd>
                </div>
                <div>
                  <dt className="text-sm font-medium text-gray-500">Interaction Level</dt>
                  <dd className="text-sm text-gray-900">{formData.customSettings.interactionLevel}</dd>
                </div>
                <div>
                  <dt className="text-sm font-medium text-gray-500">Temperature</dt>
                  <dd className="text-sm text-gray-900">{formData.customSettings.temperature}</dd>
                </div>
              </dl>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center">
          <button
            onClick={handleBack}
            className="mr-4 text-gray-600 hover:text-gray-900 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-2xl font-semibold text-gray-900">{config.title}</h1>
            <p className="text-gray-500">{config.description}</p>
          </div>
        </div>
      </div>

      {/* Progress Steps */}
      <div className="relative">
        <div className="absolute inset-0 flex items-center" aria-hidden="true">
          <div className="w-full border-t border-gray-200"></div>
        </div>
        <div className="relative flex justify-between">
          {config.steps.map((stepName, index) => (
            <div
              key={stepName}
              className={`flex items-center ${
                index + 1 === step
                  ? 'text-blue-600'
                  : index + 1 < step
                  ? 'text-green-600'
                  : 'text-gray-500'
              }`}
            >
              <div className={`
                 relative w-8 h-8 flex items-center justify-center rounded-full
                ${
                  index + 1 === step
                    ? 'bg-blue-100 border-2 border-blue-600'
                    : index + 1 < step
                    ? 'bg-green-100 border-2 border-green-600'
                    : 'bg-gray-100 border-2 border-gray-300'
                }
              `}>
                {index + 1 < step ? (
                  <Check className="w-5 h-5 text-green-600" />
                ) : (
                  <span className="text-sm font-medium">{index + 1}</span>
                )}
              </div>
              <span className="ml-2 text-sm font-medium">{stepName}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Step Content */}
      <div className="bg-white shadow rounded-lg p-6">
        <div className="space-y-4">
          <h2 className="text-lg font-medium text-gray-900">
            {config.steps[step - 1]}
          </h2>
          
          {renderStepContent()}
        </div>
      </div>

      {/* Navigation Buttons */}
      <div className="flex justify-between">
        <button
          onClick={handleBack}
          className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50 transition-colors"
        >
          Back
        </button>
        <button
          onClick={handleNext}
          disabled={!validateStep(step)}
          className={`
            px-4 py-2 rounded-md text-white transition-colors
            ${validateStep(step)
              ? 'bg-blue-600 hover:bg-blue-700'
              : 'bg-gray-400 cursor-not-allowed'}
          `}
        >
          {step === config.steps.length ? 'Create Simulation' : 'Next'}
        </button>
      </div>
    </div>
  );
}