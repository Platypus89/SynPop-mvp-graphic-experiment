import React from 'react';
import { Map } from 'lucide-react';
import type { ColumnMapping } from '../types';

interface ColumnMappingProps {
  sourceColumns: string[];
  mappings: ColumnMapping[];
  onMappingChange: (mappings: ColumnMapping[]) => void;
}

export function ColumnMapping({ sourceColumns, mappings, onMappingChange }: ColumnMappingProps) {
  const handleMappingChange = (sourceColumn: string, targetColumn: string, type: string) => {
    const newMappings = [...mappings];
    const index = newMappings.findIndex(m => m.sourceColumn === sourceColumn);
    
    if (index >= 0) {
      newMappings[index] = {
        ...newMappings[index],
        targetColumn,
        type,
        required: false // No required fields
      };
    } else {
      newMappings.push({
        sourceColumn,
        targetColumn,
        type,
        required: false
      });
    }
    
    onMappingChange(newMappings);
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex items-center mb-6">
        <Map className="w-6 h-6 text-blue-500 mr-2" />
        <h2 className="text-xl font-semibold">Column Mapping</h2>
      </div>

      <div className="mb-6">
        <p className="text-sm text-gray-600">
          Map your HRIS columns to any desired attributes. All fields are optional - map only the columns you want to use.
        </p>
      </div>

      <div className="space-y-4">
        {sourceColumns.map(column => (
          <div key={column} className="flex items-center space-x-4">
            <div className="w-1/3">
              <label className="block text-sm font-medium text-gray-700">{column}</label>
            </div>
            <div className="w-1/3">
              <input
                type="text"
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                placeholder="Target field name..."
                value={mappings.find(m => m.sourceColumn === column)?.targetColumn || ''}
                onChange={(e) => handleMappingChange(column, e.target.value, 
                  mappings.find(m => m.sourceColumn === column)?.type || 'string')}
              />
            </div>
            <div className="w-1/3">
              <select
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                value={mappings.find(m => m.sourceColumn === column)?.type || 'string'}
                onChange={(e) => handleMappingChange(
                  column,
                  mappings.find(m => m.sourceColumn === column)?.targetColumn || '',
                  e.target.value
                )}
              >
                <option value="string">Text</option>
                <option value="number">Number</option>
                <option value="date">Date</option>
                <option value="categorical">Category</option>
                <option value="boolean">Yes/No</option>
                <option value="array">List</option>
              </select>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-6">
        <h3 className="text-sm font-medium text-gray-500 mb-2">Current Mappings</h3>
        <div className="bg-gray-50 p-4 rounded-md">
          {mappings.length === 0 ? (
            <p className="text-sm text-gray-500">No mappings defined yet</p>
          ) : (
            <ul className="space-y-1">
              {mappings.map(mapping => (
                <li key={mapping.sourceColumn} className="text-sm">
                  <span className="text-gray-600">{mapping.sourceColumn}</span>
                  <span className="text-gray-400 mx-2">→</span>
                  <span className="text-blue-600">{mapping.targetColumn}</span>
                  <span className="text-gray-400 ml-2">({mapping.type})</span>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
}