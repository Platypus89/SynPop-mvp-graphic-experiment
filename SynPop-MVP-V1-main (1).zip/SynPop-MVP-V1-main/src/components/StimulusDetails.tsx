import React from 'react';
import { ArrowLeft, Zap, Calendar, FileText } from 'lucide-react';
import type { Stimulus } from '../types';

interface StimulusDetailsProps {
  stimulus: Stimulus;
  onBack: () => void;
}

export function StimulusDetails({ stimulus, onBack }: StimulusDetailsProps) {
  return (
    <div className="space-y-6">
      <div className="flex items-center">
        <button
          onClick={onBack}
          className="mr-4 text-gray-600 hover:text-gray-900"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h1 className="text-2xl font-semibold text-gray-900">Stimulus Details</h1>
      </div>

      {/* Stimulus Stats */}
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-3">
        <div className="bg-white overflow-hidden shadow rounded-lg">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <Zap className="h-6 w-6 text-gray-400" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">
                    Type
                  </dt>
                  <dd className="text-lg font-semibold text-gray-900">
                    {stimulus.type}
                  </dd>
                </dl>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white overflow-hidden shadow rounded-lg">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <FileText className="h-6 w-6 text-gray-400" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">
                    Content Length
                  </dt>
                  <dd className="text-lg font-semibold text-gray-900">
                    {stimulus.content.length} characters
                  </dd>
                </dl>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white overflow-hidden shadow rounded-lg">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <Calendar className="h-6 w-6 text-gray-400" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">
                    Created On
                  </dt>
                  <dd className="text-lg font-semibold text-gray-900">
                    {new Date(stimulus.created_at).toLocaleDateString()}
                  </dd>
                </dl>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Stimulus Content */}
      <div className="bg-white shadow sm:rounded-lg">
        <div className="px-4 py-5 sm:p-6">
          <h3 className="text-lg leading-6 font-medium text-gray-900 mb-4">
            Content
          </h3>
          <div className="prose max-w-none">
            {stimulus.type === 'text' ? (
              <div className="bg-gray-50 rounded-md p-4">
                <p className="text-gray-900">{stimulus.content}</p>
              </div>
            ) : (
              <div className="bg-gray-50 rounded-md p-4">
                <a 
                  href={stimulus.content}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-blue-600 hover:text-blue-700"
                >
                  View {stimulus.type}
                </a>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Metadata */}
      {Object.keys(stimulus.metadata).length > 0 && (
        <div className="bg-white shadow sm:rounded-lg">
          <div className="px-4 py-5 sm:p-6">
            <h3 className="text-lg leading-6 font-medium text-gray-900 mb-4">
              Metadata
            </h3>
            <div className="bg-gray-50 rounded-md p-4">
              <pre className="text-sm text-gray-900">
                {JSON.stringify(stimulus.metadata, null, 2)}
              </pre>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}