import React, { useState } from 'react';
import { Map } from 'lucide-react';
import type { Simulation, Population, Stimulus } from '../types';
import { simulateResponses, getOpenAIClient } from '../lib/openai';
import { ContextDocuments } from './ContextDocuments';

interface ContextDocument {
  id: string;
  content: string;
  summary: string;
  type: 'text' | 'url';
}

interface SimulationCreatorProps {
  onSimulationCreate: (simulation: Simulation) => void;
  populations: Population[];
  stimuli: Stimulus[];
}

export function SimulationCreator({ onSimulationCreate, populations, stimuli }: SimulationCreatorProps) {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [populationId, setPopulationId] = useState('');
  const [stimulusId, setStimulusId] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [progress, setProgress] = useState({ completed: 0, total: 0, message: '' });
  const [contextDocuments, setContextDocuments] = useState<ContextDocument[]>([]);

  const handleCreate = async () => {
    if (!name || !populationId || !stimulusId) return;
    setIsProcessing(true);
    setError(null);

    try {
      const population = populations.find(p => p.id === populationId);
      const stimulus = stimuli.find(s => s.id === stimulusId);

      if (!population || !stimulus) {
        throw new Error('Selected population or stimulus not found');
      }

      // Generate title and summary first
      const openai = getOpenAIClient();
      
      // Generate title
      const titleResponse = await openai.chat.completions.create({
        model: "gpt-3.5-turbo",
        messages: [
          {
            role: "system",
            content: "You are a helpful assistant that generates clear, concise titles."
          },
          {
            role: "user",
            content: `Generate a clear, concise title (5-8 words) for this survey question: "${stimulus.content}"`
          }
        ],
        temperature: 0.7,
        max_tokens: 50
      });
      
      const title = titleResponse.choices[0].message.content?.replace(/['"]/g, '').trim() || 'Survey Results';

      // Create initial simulation record
      const simulation: Simulation = {
        id: crypto.randomUUID(),
        name,
        description,
        population_id: populationId,
        stimulus_id: stimulusId,
        status: 'in-progress',
        temperature: 0,
        results: { 
          responses: [], 
          aggregates: { 
            distribution: {}, 
            demographics: {} 
          },
          title: title, // Store title
          summary: '' // Will be updated after responses
        },
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };

      // Start the simulation with context documents
      const responses = await simulateResponses(
        population.attributes,
        {
          type: stimulus.type,
          content: stimulus.content,
          metadata: {
            ...stimulus.metadata,
            scale: {
              type: stimulus.metadata?.scale?.type || 'likert',
              options: stimulus.metadata?.scale?.options || [
                "Strongly Disagree",
                "Disagree",
                "Neutral",
                "Agree",
                "Strongly Agree"
              ]
            }
          }
        },
        contextDocuments,
        (completed, total, message) => {
          setProgress({
            completed,
            total,
            message
          });
        }
      );

      // Calculate aggregates
      const distribution: Record<string, number> = {};
      const demographics: Record<string, Record<string, number>> = {};

      responses.forEach(response => {
        distribution[response.response] = (distribution[response.response] || 0) + 1;

        const individual = population.attributes[0];
        if (individual.age) {
          const ageGroup = Math.floor(individual.age / 10) * 10;
          if (!demographics[`age_${ageGroup}`]) {
            demographics[`age_${ageGroup}`] = {};
          }
          demographics[`age_${ageGroup}`][response.response] = 
            (demographics[`age_${ageGroup}`][response.response] || 0) + 1;
        }
      });

      // Generate summary based on results
      const total = responses.length;
      const summaryPrompt = `
        Analyze these survey results and provide a clear, concise summary in 2-3 sentences:
        
        Question: ${stimulus.content}
        Total Responses: ${total}
        Distribution: ${Object.entries(distribution)
          .map(([response, count]) => 
            `${response}: ${count} (${((count/total)*100).toFixed(1)}%)`
          ).join(', ')}
      `;
      
      const summaryResponse = await openai.chat.completions.create({
        model: "gpt-3.5-turbo",
        messages: [
          {
            role: "system",
            content: "You are a data analyst providing clear, concise summaries of survey results."
          },
          {
            role: "user",
            content: summaryPrompt
          }
        ],
        temperature: 0.7,
        max_tokens: 150
      });
      
      const summary = summaryResponse.choices[0].message.content?.trim() || 'Summary not available.';

      // Update simulation with results and analysis
      simulation.status = 'completed';
      simulation.results = {
        responses: responses.map((r, index) => ({
          individualId: population.attributes[index],
          response: r.response.trim(), // Ensure clean response values
          confidence: r.confidence,
          temperature: r.temperature
        })),
        aggregates: {
          distribution,
          demographics,
          scale: stimulus.metadata?.scale || {
            type: 'likert',
            options: ["Strongly Disagree", "Disagree", "Neutral", "Agree", "Strongly Agree"]
          }
        },
        title, // Store generated title
        summary // Store generated summary
      };
      
      // Store metadata about the simulation configuration
      simulation.metadata = {
        model: localStorage.getItem('selected_model') || 'gpt-4o',
        temperatureRange: {
          min: parseFloat(localStorage.getItem('temperature_min') || '0.3'),
          max: parseFloat(localStorage.getItem('temperature_max') || '0.8')
        },
        temperatureDistribution: localStorage.getItem('temperature_distribution') || 'normal',
        scale: stimulus.metadata?.scale
      };

      onSimulationCreate(simulation);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to create simulation');
    } finally {
      setIsProcessing(false);
      setProgress({ completed: 0, total: 0, message: '' });
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="flex items-center mb-6">
          <Map className="w-6 h-6 text-blue-500 mr-2" />
          <h2 className="text-xl font-semibold">Create Simulation</h2>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Simulation Name
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 bg-white dark:bg-gray-800 dark:border-gray-700 dark:text-gray-100"
              placeholder="Enter a name for this simulation"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Description (Optional)
            </label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={3}
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 bg-white dark:bg-gray-800 dark:border-gray-700 dark:text-gray-100"
              placeholder="Describe the purpose of this simulation"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Select Population
            </label>
            <select
              value={populationId}
              onChange={(e) => setPopulationId(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 bg-white dark:bg-gray-800 dark:border-gray-700 dark:text-gray-100"
            >
              <option value="">Choose a population</option>
              {populations.map(population => (
                <option key={population.id} value={population.id}>
                  {population.name} ({population.size} individuals)
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Select Stimulus
            </label>
            <select
              value={stimulusId}
              onChange={(e) => setStimulusId(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 bg-white dark:bg-gray-800 dark:border-gray-700 dark:text-gray-100"
            >
              <option value="">Choose a stimulus</option>
              {stimuli.map(stimulus => (
                <option key={stimulus.id} value={stimulus.id}>
                  {stimulus.content.substring(0, 50)}...
                </option>
              ))}
            </select>
          </div>

          {error && (
            <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-md">
              {error}
            </div>
          )}

          <button
            onClick={handleCreate}
            disabled={!name || !populationId || !stimulusId || isProcessing}
            className={`
              w-full py-2 px-4 rounded-md text-white font-medium
              ${!name || !populationId || !stimulusId || isProcessing
                ? 'bg-gray-400 cursor-not-allowed'
                : 'bg-blue-600 hover:bg-blue-700'}
            `}
          >
            {isProcessing ? 'Processing...' : 'Create Simulation'}
          </button>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-md p-6">
        <ContextDocuments
          documents={contextDocuments}
          onDocumentsChange={setContextDocuments}
        />
      </div>

      {isProcessing && progress.total > 0 && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-8 max-w-md w-full mx-4 transform animate-scale-in">
            <div className="flex flex-col items-center">
              <div className="w-16 h-16 mb-4 relative">
                <div className="absolute inset-0 border-4 border-blue-200 rounded-full"></div>
                <div className="absolute inset-0 border-4 border-blue-500 rounded-full animate-spin" 
                     style={{ borderTopColor: 'transparent', animationDuration: '1s' }}></div>
              </div>
              <h3 className="text-xl font-semibold mb-2 text-gray-900">Processing</h3>
              <p className="text-gray-600 text-center mb-4">{progress.message}</p>
              <div className="w-full bg-gray-200 rounded-full h-2 mb-2">
                <div 
                  className="bg-blue-500 h-2 rounded-full transition-all duration-300"
                  style={{ 
                    width: `${(progress.completed / progress.total) * 100}%` 
                  }}
                ></div>
              </div>
              <p className="text-sm text-gray-500">
                {progress.completed} of {progress.total} batches completed ({Math.round((progress.completed / progress.total) * 100)}%)
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}