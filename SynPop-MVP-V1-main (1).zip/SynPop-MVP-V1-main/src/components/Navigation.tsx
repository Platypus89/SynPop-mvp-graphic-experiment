import React, { useState } from 'react';
import { Map, Users, Zap, Settings, HelpCircle, Home, Moon, Sun } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';
import { Logo } from './Logo';

const TRANSITION_DURATION = 150; // Reduced from default 300ms

interface NavItem {
  id: string;
  label: string;
  icon: React.ElementType;
  description: string;
}

export function Navigation() {
  const location = useLocation();
  const currentView = location.pathname.slice(1) || 'dashboard';
  const [theme, setTheme] = useState<'light' | 'dark'>('light');

  const navItems = [
    { 
      id: '', 
      label: 'Dashboard', 
      icon: Home,
      description: 'Main dashboard overview'
    },
    { 
      id: 'simulations', 
      label: 'Simulations', 
      icon: Map,
      description: 'Run and manage simulations'
    },
    { 
      id: 'populations', 
      label: 'Populations', 
      icon: Users,
      description: 'Manage synthetic populations'
    },
    { 
      id: 'stimuli', 
      label: 'Stimuli', 
      icon: Zap,
      description: 'Create and manage stimuli'
    },
    { 
      id: 'settings', 
      label: 'Settings', 
      icon: Settings,
      description: 'Configure application settings'
    },
    { 
      id: 'help', 
      label: 'Help', 
      icon: HelpCircle,
      description: 'Documentation and guides'
    },
  ];

  const toggleTheme = () => {
    const newTheme = theme === 'light' ? 'dark' : 'light';
    setTheme(newTheme);
    document.documentElement.classList.toggle('dark');
  };

  return (
    <nav className="glass sticky top-0 z-50 border-b">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <div className="flex-shrink-0 transition-transform hover:scale-105">
              <Link to="/" className="block">
                <Logo size="lg" className="transition-all duration-200 hover:scale-105" />
              </Link>
            </div>
            <div className="hidden md:block ml-8">
              <div className="flex items-baseline space-x-4">
                {navItems.map(({ id, label, icon: Icon, description }) => (
                  <Link
                    key={id}
                    to={`/${id}`}
                    className={`
                      px-3 py-2 rounded-lg text-sm font-medium flex items-center 
                      transition-all duration-${TRANSITION_DURATION}
                      ${currentView === id 
                        ? 'glass bg-blue-100/80 text-blue-700 shadow-sm dark:bg-blue-900/20 dark:text-blue-400' 
                        : 'text-surface-600 dark:text-surface-300'}
                    `}>
                    <Icon className={`w-4 h-4 mr-2 transition-colors duration-300 ${
                      currentView === id
                        ? 'text-blue-600 dark:text-blue-400'
                        : 'text-surface-400 dark:text-surface-500'
                    }`} />
                    <span className="relative">
                      {label}
                    </span>
                  </Link>
                ))}
              </div>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <button
              onClick={toggleTheme}
              className="p-2 rounded-lg bg-white dark:bg-gray-800 shadow-sm hover:shadow-md 
                border border-gray-200 dark:border-gray-700
                hover:scale-105 transition-all duration-200"
            >
              {theme === 'light' ? (
                <Moon className="w-5 h-5 text-gray-600 dark:text-gray-300" />
              ) : (
                <Sun className="w-5 h-5 text-gray-600 dark:text-gray-300" />
              )}
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
}