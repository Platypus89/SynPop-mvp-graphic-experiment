import React from 'react';
import { DatasetStats } from '../types';
import { FileText, AlertCircle } from 'lucide-react';

interface DataPreviewProps {
  stats: DatasetStats;
}

export function DataPreview({ stats }: DataPreviewProps) {
  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex items-center mb-4">
        <FileText className="w-6 h-6 text-blue-500 mr-2" />
        <h2 className="text-xl font-semibold">Dataset Overview</h2>
      </div>
      
      <div className="grid grid-cols-2 gap-4">
        <div className="col-span-2">
          <h3 className="text-sm font-medium text-gray-500">Total Records</h3>
          <p className="text-2xl font-bold text-gray-900">{stats.totalRows.toLocaleString()}</p>
        </div>

        <div>
          <h3 className="text-sm font-medium text-gray-500">Detected Columns</h3>
          <p className="text-lg font-medium text-gray-900">{stats.columns.length}</p>
        </div>

        <div>
          <h3 className="text-sm font-medium text-gray-500">Mapped Columns</h3>
          <p className="text-lg font-medium text-gray-900">
            {Object.keys(stats.mappedColumns).length}
          </p>
        </div>

        {stats.dataQuality.missingValues > 0 && (
          <div className="col-span-2 bg-yellow-50 p-4 rounded-md">
            <div className="flex items-center">
              <AlertCircle className="w-5 h-5 text-yellow-400 mr-2" />
              <div>
                <h4 className="text-sm font-medium text-yellow-800">Data Quality Issues</h4>
                <p className="text-sm text-yellow-700">
                  Found {stats.dataQuality.missingValues} missing values and{' '}
                  {stats.dataQuality.invalidEntries} invalid entries
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}