import React, { useState } from 'react';
import { MessageSquare, AlertCircle, CheckCircle, Sliders, Users } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { getOpenAIClient } from '../lib/openai';
import { analyzeDemographics } from '../lib/demographicAnalysis';
import type { Population } from '../types';

interface PromptPopulationCreatorProps {
  onPopulationCreated: (population: Population) => void;
}

export function PromptPopulationCreator({ onPopulationCreated }: PromptPopulationCreatorProps) {
  const [prompt, setPrompt] = useState('');
  const [name, setName] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [analysis, setAnalysis] = useState<{
    size: number;
    demographics: Record<string, any[]>;
    summary: string;
  } | null>(null);
  const [progress, setProgress] = useState<{
    step: string;
    current: number;
    total: number;
    message: string;
  }>({ step: '', current: 0, total: 0, message: '' });
  const [temperature, setTemperature] = useState(0.7);
  const [examplePrompts] = useState([
    "Create a tech startup with 50 employees across engineering, design, and business roles. Include age distribution, experience levels, and department breakdown.",
    "Generate a university faculty of 200 professors and staff with diverse academic backgrounds, research interests, and teaching experience.",
    "Model a retail company with 100 employees including store managers, sales associates, and support staff with varying experience and locations."
  ]);

  const handleAnalyze = async () => {
    if (!prompt.trim()) return;
    
    setLoading(true);
    setError(null);
    setAnalysis(null);
    setProgress({
      step: 'analysis',
      current: 0,
      total: 100,
      message: 'Analyzing population description...'
    });

    try {
      const openai = getOpenAIClient();
      
      const response = await openai.chat.completions.create({
        model: "gpt-3.5-turbo",
        messages: [
          {
            role: "system",
            content: `You are a workforce analytics expert. Analyze the population description and generate a detailed demographic breakdown.
            Include:
            - Recommended total size
            - Department/role distributions
            - Age ranges
            - Experience levels
            - Skills/qualifications
            - Geographic distribution (if applicable)
            
            Return a valid JSON object with:
            {
              "size": number,
              "demographics": {
                "department": [{"value": string, "percentage": number}],
                "age_group": [{"value": string, "percentage": number}],
                "experience": [{"value": string, "percentage": number}],
                // other relevant categories
              },
              "summary": string (brief overview)
            }`
          },
          {
            role: "user",
            content: prompt
          }
        ],
        temperature: 0.3
      });

      const analysisResult = JSON.parse(response.choices[0].message.content || '{}');
      
      // Validate the analysis
      if (!analysisResult.size || !analysisResult.demographics || !analysisResult.summary) {
        throw new Error('Invalid analysis format');
      }

      // Ensure percentages sum to 100 for each category
      Object.entries(analysisResult.demographics).forEach(([category, distribution]) => {
        const sum = (distribution as any[]).reduce((acc, item) => acc + item.percentage, 0);
        if (Math.abs(sum - 100) > 0.1) {
          throw new Error(`Invalid percentage distribution for ${category}`);
        }
      });

      setAnalysis(analysisResult);
      setName(name || `Synthetic Population ${new Date().toLocaleDateString()}`);
    } catch (err) {
      console.error('Analysis error:', err);
      setError(err instanceof Error ? err.message : 'Failed to analyze prompt');
    } finally {
      setLoading(false);
      setProgress({ step: '', current: 0, total: 0, message: '' });
    }
  };

  const generateProfiles = async (demographics: Record<string, any[]>, count: number) => {
    const profiles: Record<string, any>[] = [];
    const batchSize = 50;
    const batches = Math.ceil(count / batchSize);

    for (let i = 0; i < batches; i++) {
      const currentBatchSize = Math.min(batchSize, count - (i * batchSize));
      setProgress({
        step: 'generation',
        current: i + 1,
        total: batches,
        message: `Generating profiles (batch ${i + 1}/${batches})...`
      });

      const openai = getOpenAIClient();
      const response = await openai.chat.completions.create({
        model: "gpt-3.5-turbo",
        messages: [
          {
            role: "system",
            content: `Generate ${currentBatchSize} realistic employee profiles based on these demographics:
            ${JSON.stringify(demographics, null, 2)}
            
            Return a JSON array of profiles with all demographic attributes.
            Each profile should be consistent with the demographic distributions.`
          }
        ],
        temperature
      });

      const batchProfiles = JSON.parse(response.choices[0].message.content || '[]');
      profiles.push(...batchProfiles);

      // Add delay between batches
      if (i < batches - 1) {
        await new Promise(resolve => setTimeout(resolve, 1000));
      }
    }

    return profiles;
  };

  const handleCreate = async () => {
    if (!analysis) return;

    try {
      setLoading(true);
      
      const profiles = await generateProfiles(analysis.demographics, analysis.size);

      setProgress({
        step: 'saving',
        current: 100,
        total: 100,
        message: 'Saving population...'
      });

      const population: Population = {
        id: crypto.randomUUID(),
        name: name || 'Synthetic Population',
        size: analysis.size,
        source_dataset: 'prompt-generated',
        attributes: profiles,
        metadata: {
          creationMethod: 'prompt',
          prompt,
          analysis,
          temperature,
          expertAnalysis: analyzeDemographics({ attributes: profiles } as any).map(p => p.expert_reflections)
        },
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };

      const { error: saveError } = await supabase
        .from('populations')
        .insert([population])
        .select()
        .single();

      if (saveError) throw saveError;

      onPopulationCreated(population);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to create population');
    } finally {
      setLoading(false);
      setProgress({ step: '', current: 0, total: 0, message: '' });
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="flex items-center mb-6">
          <MessageSquare className="w-6 h-6 text-blue-500 mr-2" />
          <h2 className="text-xl font-semibold">Describe Your Population</h2>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Population Description
            </label>
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              rows={6}
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
              placeholder="Describe the population you want to create. Include details about size, roles, demographics, and any specific characteristics..."
            />
          </div>

          <div className="bg-gray-50 p-4 rounded-lg">
            <h3 className="text-sm font-medium text-gray-700 mb-2">Example Prompts</h3>
            <div className="space-y-2">
              {examplePrompts.map((example, index) => (
                <button
                  key={index}
                  onClick={() => setPrompt(example)}
                  className="w-full text-left text-sm text-gray-600 hover:text-blue-600 p-2 rounded hover:bg-blue-50 transition-colors"
                >
                  {example}
                </button>
              ))}
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="block text-sm font-medium text-gray-700">
                Generation Temperature: {temperature}
              </label>
              <Sliders className="w-4 h-4 text-gray-400" />
            </div>
            <input
              type="range"
              min="0.1"
              max="1"
              step="0.1"
              value={temperature}
              onChange={(e) => setTemperature(parseFloat(e.target.value))}
              className="w-full"
            />
            <p className="mt-1 text-xs text-gray-500">
              Lower values generate more consistent profiles, higher values increase variety
            </p>
          </div>

          <button
            onClick={handleAnalyze}
            disabled={!prompt.trim() || loading}
            className="w-full py-2 px-4 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50"
          >
            {loading ? 'Analyzing...' : 'Analyze Description'}
          </button>
        </div>
      </div>

      {error && (
        <div className="bg-red-50 p-4 rounded-lg flex items-center">
          <AlertCircle className="w-5 h-5 text-red-500 mr-3" />
          <p className="text-red-600">{error}</p>
        </div>
      )}

      {loading && progress.step && (
        <div className="bg-blue-50 p-4 rounded-lg">
          <div className="flex items-center mb-2">
            <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-blue-500 mr-3"></div>
            <p className="text-blue-600 font-medium">{progress.message}</p>
          </div>
          <div className="w-full bg-blue-100 rounded-full h-2">
            <div 
              className="bg-blue-500 h-2 rounded-full transition-all duration-300"
              style={{ width: `${(progress.current / progress.total) * 100}%` }}
            ></div>
          </div>
        </div>
      )}

      {analysis && (
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center mb-4">
            <CheckCircle className="w-6 h-6 text-green-500 mr-2" />
            <h2 className="text-xl font-semibold">Analysis Complete</h2>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Population Name
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md"
                placeholder="Enter a name for this population"
              />
            </div>

            <div>
              <h3 className="text-sm font-medium text-gray-700 mb-2">Summary</h3>
              <p className="text-gray-600">{analysis.summary}</p>
            </div>

            <div className="bg-gray-50 p-4 rounded-lg">
              <div className="flex items-center mb-4">
                <Users className="w-5 h-5 text-gray-500 mr-2" />
                <h3 className="text-sm font-medium text-gray-700">Population Size</h3>
                <p className="ml-2 text-lg font-semibold">{analysis.size.toLocaleString()} individuals</p>
              </div>
            </div>

            <div>
              <h3 className="text-sm font-medium text-gray-700 mb-2">Demographics</h3>
              <div className="space-y-3">
                {Object.entries(analysis.demographics).map(([category, distribution]) => (
                  <div key={category} className="bg-gray-50 p-3 rounded-md">
                    <h4 className="font-medium capitalize mb-2">{category.replace(/_/g, ' ')}</h4>
                    <div className="grid grid-cols-2 gap-2">
                      {distribution.map((item: any, index: number) => (
                        <div key={index} className="text-sm">
                          <span className="text-gray-600">{item.value}:</span>
                          <span className="ml-1 font-medium">{item.percentage}%</span>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <button
              onClick={handleCreate}
              disabled={loading}
              className="w-full py-2 px-4 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50"
            >
              {loading ? 'Creating Population...' : 'Create Population'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}