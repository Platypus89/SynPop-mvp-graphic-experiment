import React, { useState } from 'react';
import { Users, Sliders } from 'lucide-react';
import type { SyntheticPopulation } from '../types';
import { generateSyntheticPopulation } from '../lib/openai';

interface PopulationGeneratorProps {
  onGenerate: (population: SyntheticPopulation) => void;
  sourceDataset: string;
  mappings: Array<{ targetColumn: string; type: string }>;
}

export function PopulationGenerator({ onGenerate, sourceDataset, mappings }: PopulationGeneratorProps) {
  const [temperature, setTemperature] = useState(0.5);
  const [name, setName] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleGenerate = async () => {
    setIsGenerating(true);
    setError(null);

    try {
      // Get the total rows from the DatasetStats stored in App state
      const totalRows = parseInt(localStorage.getItem('dataset_total_rows') || '0', 10);
      if (!totalRows) {
        throw new Error('Could not determine the number of rows from the source dataset');
      }

      const attributes = await generateSyntheticPopulation(totalRows, temperature, mappings);
      
      const population: SyntheticPopulation = {
        id: crypto.randomUUID(),
        name: name || `Population ${new Date().toLocaleDateString()}`,
        size: totalRows,
        attributes,
        generatedAt: new Date().toISOString(),
        sourceDataset
      };
      
      onGenerate(population);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to generate population');
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex items-center mb-6">
        <Users className="w-6 h-6 text-blue-500 mr-2" />
        <h2 className="text-xl font-semibold">Generate Synthetic Population</h2>
      </div>

      <div className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Population Name
          </label>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Enter a name for this population"
            className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
          />
        </div>

        <div>
          <div className="flex items-center mb-2">
            <Sliders className="w-4 h-4 text-gray-500 mr-2" />
            <label className="text-sm font-medium text-gray-700">
              Variability Temperature: {temperature}
            </label>
          </div>
          <input
            type="range"
            min="0"
            max="1"
            step="0.1"
            value={temperature}
            onChange={(e) => setTemperature(Number(e.target.value))}
            className="w-full"
          />
          <p className="mt-1 text-sm text-gray-500">
            Higher values increase population diversity
          </p>
        </div>

        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-md">
            {error}
          </div>
        )}

        <button
          onClick={handleGenerate}
          disabled={isGenerating}
          className={`
            w-full py-2 px-4 rounded-md text-white font-medium
            ${isGenerating
              ? 'bg-blue-400 cursor-not-allowed'
              : 'bg-blue-600 hover:bg-blue-700'}
          `}
        >
          {isGenerating ? 'Generating...' : 'Generate Population'}
        </button>
      </div>
    </div>
  );
}