import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { Zap, Plus, Trash2, Eye, AlertCircle } from 'lucide-react';
import { StimulusDesigner } from './StimulusDesigner';
import { StimulusDetails } from './StimulusDetails';
import type { Stimulus } from '../types';

export function Stimuli() {
  const [stimuli, setStimuli] = useState<Stimulus[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedStimulus, setSelectedStimulus] = useState<Stimulus | null>(null);
  const [showDesigner, setShowDesigner] = useState(false);

  useEffect(() => {
    fetchStimuli();
  }, []);

  async function fetchStimuli() {
    try {
      const { data, error } = await supabase
        .from('stimuli')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      if (data) setStimuli(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch stimuli');
    } finally {
      setLoading(false);
    }
  }

  async function handleDelete(id: string) {
    try {
      const { error } = await supabase
        .from('stimuli')
        .delete()
        .eq('id', id);

      if (error) throw error;
      setStimuli(stimuli.filter(s => s.id !== id));
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to delete stimulus');
    }
  }

  const handleStimulusCreate = async (stimulus: Stimulus) => {
    try {
      const { data, error } = await supabase
        .from('stimuli')
        .insert([stimulus])
        .select()
        .single();

      if (error) throw error;
      if (data) {
        setStimuli([data, ...stimuli]);
        setShowDesigner(false);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to create stimulus');
    }
  };

  if (loading) {
    return (
      <div className="animate-pulse space-y-8">
        <div className="h-12 bg-gray-200 rounded-lg w-1/4"></div>
        <div className="space-y-4">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="h-24 bg-gray-200 rounded-lg"></div>
          ))}
        </div>
      </div>
    );
  }

  if (selectedStimulus) {
    return (
      <StimulusDetails 
        stimulus={selectedStimulus} 
        onBack={() => setSelectedStimulus(null)} 
      />
    );
  }

  if (showDesigner) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-semibold text-gray-900">Create New Stimulus</h1>
          <button
            onClick={() => setShowDesigner(false)}
            className="text-gray-600 hover:text-gray-900"
          >
            Back to Stimuli
          </button>
        </div>
        <StimulusDesigner onStimulusCreate={handleStimulusCreate} />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {error && (
        <div className="rounded-md bg-red-50 p-4">
          <div className="flex">
            <AlertCircle className="h-5 w-5 text-red-400 mr-2" />
            <div className="text-sm text-red-700">{error}</div>
          </div>
        </div>
      )}

      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-gray-900">Stimuli</h1>
        <button
          onClick={() => setShowDesigner(true)}
          className="flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700"
        >
          <Plus className="w-4 h-4 mr-2" />
          Create Stimulus
        </button>
      </div>

      {stimuli.length === 0 ? (
        <div className="text-center py-12">
          <Zap className="mx-auto h-12 w-12 text-gray-400" />
          <h3 className="mt-2 text-sm font-medium text-gray-900">No stimuli</h3>
          <p className="mt-1 text-sm text-gray-500">
            Get started by creating a new stimulus
          </p>
          <div className="mt-6">
            <button
              onClick={() => setShowDesigner(true)}
              className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700"
            >
              <Plus className="w-4 h-4 mr-2" />
              Create Stimulus
            </button>
          </div>
        </div>
      ) : (
        <div className="bg-white shadow overflow-hidden sm:rounded-md">
          <ul className="divide-y divide-gray-200">
            {stimuli.map((stimulus) => (
              <li key={stimulus.id}>
                <div className="px-4 py-4 flex items-center sm:px-6">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between">
                      <p className="text-sm font-medium text-blue-600 truncate">
                        {stimulus.content.substring(0, 100)}...
                      </p>
                      <div className="ml-2 flex-shrink-0 flex">
                        <p className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 text-blue-800">
                          {stimulus.type}
                        </p>
                      </div>
                    </div>
                    <div className="mt-2 flex">
                      <div className="flex items-center text-sm text-gray-500">
                        <Zap className="flex-shrink-0 mr-1.5 h-4 w-4 text-gray-400" />
                        <p>
                          Created on{' '}
                          {new Date(stimulus.created_at).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                  </div>
                  <div className="ml-5 flex-shrink-0 flex items-center space-x-2">
                    <button
                      onClick={() => setSelectedStimulus(stimulus)}
                      className="text-gray-400 hover:text-gray-500"
                    >
                      <Eye className="h-5 w-5" />
                    </button>
                    <button
                      onClick={() => handleDelete(stimulus.id)}
                      className="text-red-400 hover:text-red-500"
                    >
                      <Trash2 className="h-5 w-5" />
                    </button>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}