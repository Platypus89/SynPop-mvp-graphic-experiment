import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { Map, Plus, Trash2, BarChart3, Calendar, Users, AlertCircle, Target, FileText, Users2, RefreshCw, Thermometer, Brain } from 'lucide-react';
import { SimulationCreator } from './SimulationCreator';
import { SimulationDetails } from './SimulationDetails';
import { GuidedSimulation } from './GuidedSimulation';
import type { Simulation, Population, Stimulus } from '../types';
import { AVAILABLE_MODELS } from '../lib/openai';

interface DeleteConfirmationProps {
  simulation: Simulation;
  onConfirm: () => void;
  onCancel: () => void;
}

function DeleteConfirmation({ simulation, onConfirm, onCancel }: DeleteConfirmationProps) {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 max-w-md w-full mx-4 transform animate-scale-in">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Delete Simulation</h3>
        <p className="text-gray-600 mb-6">
          Are you sure you want to delete "{simulation.name}"? This action cannot be undone.
        </p>
        <div className="flex justify-end space-x-4">
          <button
            onClick={onCancel}
            className="px-4 py-2 text-gray-700 hover:text-gray-900 transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={onConfirm}
            className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 transition-colors"
          >
            Delete
          </button>
        </div>
      </div>
    </div>
  );
}

export function Simulations() {
  const [simulations, setSimulations] = useState<Simulation[]>([]);
  const [populations, setPopulations] = useState<Population[]>([]);
  const [stimuli, setStimuli] = useState<Stimulus[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedSimulation, setSelectedSimulation] = useState<Simulation | null>(null);
  const [view, setView] = useState<'list' | 'create' | 'guided'>('list');
  const [simulationType, setSimulationType] = useState<'survey' | 'poll' | 'focus-group' | null>(null);
  const [simulationToDelete, setSimulationToDelete] = useState<Simulation | null>(null);
  const [rerunningSimulation, setRerunningSimulation] = useState<string | null>(null);

  useEffect(() => {
    fetchData();
  }, []);

  async function fetchData() {
    try {
      // Load data progressively to avoid timeouts
      const loadData = async (table: string, batchSize: number = 5) => {
        const { data, error } = await supabase
          .from(table)
          .select('*')
          .order('created_at', { ascending: false })
          .limit(batchSize);

        if (error) throw error;
        return data || [];
      };

      // Load each table separately with delay between requests
      const simulations = await loadData('simulations');
      await new Promise(resolve => setTimeout(resolve, 100));

      const populations = await loadData('populations');
      await new Promise(resolve => setTimeout(resolve, 100));

      const stimuli = await loadData('stimuli');

      setSimulations(simulations);
      setPopulations(populations);
      setStimuli(stimuli);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch data');
    } finally {
      setLoading(false);
    }
  }

  const handleSimulationCreate = async (simulation: Simulation) => {
    try {
      const { data, error } = await supabase
        .from('simulations')
        .insert([simulation])
        .select()
        .single();

      if (error) throw error;
      if (data) {
        setSimulations([data, ...simulations]);
        setView('list');
        setSimulationType(null);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to create simulation');
    }
  };

  const handleDeleteSimulation = async (simulation: Simulation) => {
    setSimulationToDelete(simulation);
  };

  const handleRerunSimulation = async (simulation: Simulation) => {
    try {
      setRerunningSimulation(simulation.id);
      
      // Get required data
      const population = populations.find(p => p.id === simulation.population_id);
      const stimulus = stimuli.find(s => s.id === simulation.stimulus_id);
      
      if (!population || !stimulus) {
        throw new Error('Population or stimulus not found');
      }
      
      // Create new simulation with same parameters
      const newSimulation: Simulation = {
        ...simulation,
        id: crypto.randomUUID(),
        status: 'in-progress',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };
      
      const { data, error } = await supabase
        .from('simulations')
        .insert([newSimulation])
        .select()
        .single();

      if (error) throw error;
      if (data) {
        setSimulations([data, ...simulations]);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to rerun simulation');
    } finally {
      setRerunningSimulation(null);
    }
  };

  const confirmDelete = async () => {
    if (!simulationToDelete) return;

    try {
      const { error } = await supabase
        .from('simulations')
        .delete()
        .eq('id', simulationToDelete.id);

      if (error) throw error;
      setSimulations(simulations.filter(s => s.id !== simulationToDelete.id));
      setSimulationToDelete(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to delete simulation');
    }
  };

  if (loading) {
    return (
      <div className="animate-pulse space-y-8">
        <div className="h-12 bg-gray-200 rounded-lg w-1/4"></div>
        <div className="space-y-4">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="h-24 bg-gray-200 rounded-lg"></div>
          ))}
        </div>
      </div>
    );
  }

  if (selectedSimulation) {
    return (
      <SimulationDetails 
        simulation={selectedSimulation}
        population={populations.find(p => p.id === selectedSimulation.population_id)}
        stimulus={stimuli.find(s => s.id === selectedSimulation.stimulus_id)}
        onBack={() => setSelectedSimulation(null)} 
      />
    );
  }

  if (view === 'guided' && simulationType) {
    return (
      <GuidedSimulation
        type={simulationType}
        populations={populations}
        stimuli={stimuli}
        onSimulationCreate={handleSimulationCreate}
        onBack={() => {
          setView('list');
          setSimulationType(null);
        }}
      />
    );
  }

  if (view === 'create') {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-semibold text-gray-900">Create New Simulation</h1>
          <button
            onClick={() => setView('list')}
            className="text-gray-600 hover:text-gray-900"
          >
            Back to Simulations
          </button>
        </div>
        <SimulationCreator 
          onSimulationCreate={handleSimulationCreate}
          populations={populations}
          stimuli={stimuli}
        />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {error && (
        <div className="rounded-md bg-red-50 p-4">
          <div className="flex">
            <AlertCircle className="h-5 w-5 text-red-400 mr-2" />
            <div className="text-sm text-red-700">{error}</div>
          </div>
        </div>
      )}

      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-gray-900">Simulations</h1>
        <div className="flex space-x-4">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setView('create')}
              disabled={populations.length === 0 || stimuli.length === 0}
              className="btn btn-primary glass-card flex items-center gap-2 px-4 py-2 text-sm font-medium
                disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100"
            >
              <Plus className="w-4 h-4" />
              <span>Manual Creation</span>
            </button>
            
            <button
              onClick={() => setView('guided')}
              className="btn btn-primary glass-card flex items-center gap-2 px-4 py-2 text-sm font-medium
                relative group hover:scale-[1.02] transition-transform duration-200"
            >
              <Target className="w-4 h-4" />
              <span>Guided Creation</span>
              <span className="absolute -top-2 -right-2 px-1.5 py-0.5 text-xs bg-gradient-to-r 
                from-blue-400/90 to-blue-500/90 text-white rounded-full 
                shadow-lg shadow-amber-500/20 backdrop-blur-sm">
                Beta
              </span>
            </button>
          </div>
        </div>
      </div>

      {view === 'guided' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <button
            onClick={() => setSimulationType('survey')}
            className="p-6 bg-white rounded-lg shadow-sm hover:shadow-md transition-all duration-200 transform hover:scale-105 relative group"
          >
            <FileText className="w-12 h-12 mx-auto mb-4 text-blue-500" />
            <h3 className="text-lg font-semibold mb-2">Survey Simulation</h3>
            <p className="text-gray-600 text-sm">
              Simulate responses to detailed survey questions with multiple answer options
            </p>
          </button>

          <button
            onClick={() => setSimulationType('poll')}
            className="p-6 bg-white rounded-lg shadow-sm hover:shadow-md transition-all duration-200 transform hover:scale-105 relative group"
          >
            <BarChart3 className="w-12 h-12 mx-auto mb-4 text-green-500" />
            <h3 className="text-lg font-semibold mb-2">Poll Simulation</h3>
            <p className="text-gray-600 text-sm">
              Quick simulations for simple yes/no or multiple choice questions
            </p>
          </button>

          <button
            onClick={() => setSimulationType('focus-group')}
            className="p-6 bg-white rounded-lg shadow-sm hover:shadow-md transition-all duration-200 transform hover:scale-105 relative group"
          >
            <Users2 className="w-12 h-12 mx-auto mb-4 text-purple-500" />
            <h3 className="text-lg font-semibold mb-2">Focus Group Simulation</h3>
            <p className="text-gray-600 text-sm">
              Simulate in-depth group discussions and interactions
            </p>
          </button>
        </div>
      )}

      {simulations.length === 0 ? (
        <div className="text-center py-12">
          <Map className="mx-auto h-12 w-12 text-gray-400" />
          <h3 className="mt-2 text-sm font-medium text-gray-900">No simulations</h3>
          <p className="mt-1 text-sm text-gray-500">
            Get started by creating a new simulation
          </p>
          <div className="mt-6 space-x-4">
            <button
              onClick={() => setView('create')}
              disabled={populations.length === 0 || stimuli.length === 0}
              className="btn btn-primary glass-card flex items-center gap-2 px-4 py-2 text-sm font-medium"
            >
              <Plus className="w-4 h-4" />
              Manual Creation
            </button>
            <button
              onClick={() => setView('guided')}
              className="btn btn-primary glass-card flex items-center gap-2 px-4 py-2 text-sm font-medium"
            >
              <Target className="w-4 h-4" />
              Guided Creation
            </button>
          </div>
          {(populations.length === 0 || stimuli.length === 0) && (
            <p className="mt-4 text-sm text-gray-500">
              {populations.length === 0 && stimuli.length === 0 
                ? 'You need to create at least one population and one stimulus first'
                : populations.length === 0 
                ? 'You need to create at least one population first'
                : 'You need to create at least one stimulus first'}
            </p>
          )}
        </div>
      ) : (
        <div className="grid gap-6">
          {simulations.map((simulation) => {
            const population = populations.find(p => p.id === simulation.population_id);
            const stimulus = stimuli.find(s => s.id === simulation.stimulus_id);
            
            return (
              <div 
                key={simulation.id}
                className="bg-white shadow rounded-lg overflow-hidden hover:shadow-lg transition-all duration-200 transform hover:scale-[1.01]"
              >
                <div className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="space-y-1">
                      <h2 className="text-xl font-semibold text-gray-900">
                        {simulation.name}
                      </h2>
                      {population && (
                        <p className="text-sm text-gray-500 flex items-center">
                          <Users className="w-4 h-4 mr-1" />
                          {population.name} ({population.size.toLocaleString()} individuals)
                        </p>
                      )}
                    </div>
                    <div className="flex items-center space-x-2">
                      <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                        simulation.status === 'completed' 
                          ? 'bg-green-100 text-green-800'
                          : simulation.status === 'in-progress'
                          ? 'bg-blue-100 text-blue-800'
                          : 'bg-gray-100 text-gray-800'
                      }`}>
                        {simulation.status}
                      </span>
                    </div>
                  </div>

                  {stimulus && (
                    <div className="mt-4 bg-gray-50 rounded-md p-4">
                      <p className="text-sm text-gray-600 line-clamp-2">
                        {stimulus.content}
                      </p>
                    </div>
                  )}

                  <div className="mt-6 flex items-center justify-between">
                    <div className="flex items-center text-sm text-gray-500">
                      <Calendar className="w-4 h-4 mr-1" />
                      {new Date(simulation.created_at).toLocaleString()}
                      <div className="ml-4 flex items-center gap-4">
                        <div className="flex items-center">
                          <Brain className="w-4 h-4 mr-1" />
                          Model: {AVAILABLE_MODELS[simulation.metadata?.model || 'gpt-4o']?.name || 'GPT-4o'}
                        </div>
                        <div className="flex items-center">
                          <Thermometer className="w-4 h-4 mr-1" />
                          Temp: {simulation.metadata?.temperatureRange?.min || 0.3}-{simulation.metadata?.temperatureRange?.max || 0.8} 
                          ({simulation.metadata?.temperatureDistribution || 'normal'})
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center space-x-4">
                      <button
                        onClick={() => handleRerunSimulation(simulation)}
                        disabled={rerunningSimulation === simulation.id}
                        className="flex items-center px-4 py-2 bg-green-50 text-green-600 rounded-md hover:bg-green-100 transition-colors duration-200 disabled:opacity-50"
                      >
                        <RefreshCw className={`w-4 h-4 mr-2 ${rerunningSimulation === simulation.id ? 'animate-spin' : ''}`} />
                        {rerunningSimulation === simulation.id ? 'Rerunning...' : 'Rerun'}
                      </button>
                      <button
                        onClick={() => setSelectedSimulation(simulation)}
                        className="flex items-center px-4 py-2 bg-blue-50 text-blue-600 rounded-md hover:bg-blue-100 transition-colors duration-200"
                      >
                        <BarChart3 className="w-4 h-4 mr-2" />
                        View Analysis
                      </button>
                      <button
                        onClick={() => handleDeleteSimulation(simulation)}
                        className="flex items-center px-3 py-2 text-red-600 hover:text-red-700 hover:bg-red-50 rounded-md transition-colors duration-200"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {simulationToDelete && (
        <DeleteConfirmation
          simulation={simulationToDelete}
          onConfirm={confirmDelete}
          onCancel={() => setSimulationToDelete(null)}
        />
      )}
    </div>
  );
}