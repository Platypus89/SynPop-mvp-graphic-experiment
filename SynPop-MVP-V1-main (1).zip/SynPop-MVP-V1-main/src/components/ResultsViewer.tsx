import React, { useEffect, useRef, useState } from 'react';
import { ArrowLeft, BarChart3, Brain, Users, Filter, FileText, Download, ChevronDown, ChevronRight, Activity, Calendar, AlertCircle, DollarSign, MessageSquare, Send } from 'lucide-react';
import * as d3 from 'd3';
import type { Simulation, Stimulus } from '../types';
import { utils as xlsxUtils, writeFile as xlsxWriteFile } from 'xlsx';
import { jsPDF } from 'jspdf';
import html2canvas from 'html2canvas';
import { getOpenAIClient } from '../lib/openai';

interface ResultsViewerProps {
  results: Array<{
    id: string;
    name: string;
    responses: Array<{
      individualId: any;
      response: string;
      confidence: number;
      temperature: number;
      expertReflections?: {
        financial: string;
        career: string;
        lifestyle: string;
        mental_health: string;
        relationship: string;
      };
    }>;
    aggregates: {
      distribution: Record<string, number>;
      demographics: Record<string, Record<string, number>>;
    };
    results: {
      title: string;
      summary: string;
    };
  }>;
  stimulus?: Stimulus;
  onBack: () => void;
}

export function ResultsViewer({ results, stimulus, onBack }: ResultsViewerProps) {
  const chartRef = useRef<SVGSVGElement>(null);
  const reportRef = useRef<HTMLDivElement>(null);
  const [view, setView] = useState<'distribution' | 'demographics' | 'cross-analysis'>('distribution');
  const [primaryDemographic, setPrimaryDemographic] = useState<string>('');
  const [secondaryDemographic, setSecondaryDemographic] = useState<string>('');
  const [error, setError] = useState<string | null>(null);
  const [exportingPdf, setExportingPdf] = useState(false);
  const [showInsights, setShowInsights] = useState(true);
  const [selectedResponse, setSelectedResponse] = useState<string | null>(null);
  const [hoveredBar, setHoveredBar] = useState<string | null>(null);
  const [selectedDemographics, setSelectedDemographics] = useState<string[]>([]);
  const title = results[0]?.results?.title || 'Survey Results';
  const summary = results[0]?.results?.summary || 'No summary available.';
  const [chatInput, setChatInput] = useState('');
  const [chatHistory, setChatHistory] = useState<Array<{role: 'user' | 'assistant', content: string}>>([]);
  const [isChatLoading, setIsChatLoading] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);
  const totalResponses = results[0]?.responses?.length || 0;
  const demographics = React.useMemo(() => {
    const demo: Record<string, Set<string>> = {};
    results[0]?.responses?.forEach(response => {
      Object.keys(response.individualId || {}).forEach(key => {
        if (!demo[key]) demo[key] = new Set();
        demo[key].add(String(response.individualId[key]));
      });
    });
    return Object.entries(demo)
      .filter(([_, values]) => values.size > 1 && values.size < totalResponses / 2)
      .map(([key]) => key);
  }, [results, totalResponses]);

  const getResponseOptions = (): string[] => {
    if (stimulus?.metadata?.scale?.type === 'custom' && Array.isArray(stimulus.metadata.scale.options)) {
      return stimulus.metadata.scale.options;
    } else if (stimulus?.metadata?.scale?.type === 'binary') {
      return ['Yes', 'No'];
    } else if (stimulus?.metadata?.scale?.type === 'likert') {
      return ['Strongly Disagree', 'Disagree', 'Neutral', 'Agree', 'Strongly Agree'];
    } else {
      // Try to infer from results if no explicit scale is defined
      const uniqueResponses = [...new Set(results[0]?.responses?.map(r => r.response))];
      if (uniqueResponses.length > 0) {
        return uniqueResponses.sort();
      }
      return ['Strongly Disagree', 'Disagree', 'Neutral', 'Agree', 'Strongly Agree'];
    }
  };

  const getResponseColor = (response: string, totalOptions: number): string => {
    // Get scale type from stimulus metadata
    const scaleType = stimulus?.metadata?.scale?.type || 'likert';
    
    // Choose color scheme based on scale type
    let colors;
    if (scaleType === 'binary') {
      colors = ['#ef4444', '#22c55e']; // Red for No, Green for Yes
    } else if (scaleType === 'custom') {
      // Use a different color scheme for custom scales
      colors = d3.schemeSet2;
    } else {
      // Use sequential blues for Likert scales
      colors = d3.schemeBlues[Math.max(3, totalOptions)];
    }
    
    const index = getResponseOptions().indexOf(response);
    return colors[index % colors.length] || '#ccc';
  };

  useEffect(() => {
    let cleanup: (() => void) | undefined;

    switch (view) {
      case 'distribution':
        cleanup = renderDistributionChart();
        break;
      case 'demographics':
        cleanup = renderDemographicChart();
        break;
      case 'cross-analysis':
        cleanup = renderCrossAnalysisChart();
        break;
    }

    return () => {
      if (cleanup) cleanup();
      if (chartRef.current) {
        const svg = d3.select(chartRef.current);
        svg.selectAll('*').remove();
      }
    };
  }, [view, primaryDemographic, secondaryDemographic]);

  const renderDistributionChart = () => {
    if (!chartRef.current || !results[0]?.responses?.length) return;

    const svg = d3.select(chartRef.current);
    svg.selectAll('*').remove();

    const responses = results[0].responses;
    const distribution = responses.reduce((acc, r) => {
      acc[r.response] = (acc[r.response] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    const responseOptions = getResponseOptions();
    const data = responseOptions.map(response => ({
      response,
      count: distribution[response] || 0,
      percentage: ((distribution[response] || 0) / responses.length) * 100
    }));

    const margin = { top: 40, right: 120, bottom: 60, left: 60 };
    const width = chartRef.current.clientWidth - margin.left - margin.right;
    const height = 400 - margin.top - margin.bottom;

    const g = svg
      .attr('width', width + margin.left + margin.right)
      .attr('height', height + margin.top + margin.bottom)
      .append('g')
      .attr('transform', `translate(${margin.left},${margin.top})`);

    const x = d3.scaleBand()
      .domain(data.map(d => d.response))
      .range([0, width])
      .padding(0.3);

    const y = d3.scaleLinear()
      .domain([0, d3.max(data, d => d.percentage) || 100])
      .range([height, 0]);

    // Add grid lines
    g.append('g')
      .attr('class', 'grid')
      .call(d3.axisLeft(y)
        .tickSize(-width)
        .tickFormat(() => '')
      )
      .style('stroke-dasharray', '3,3')
      .style('stroke-opacity', 0.2);

    // Add bars
    g.selectAll('.bar')
      .data(data)
      .join('rect')
      .attr('class', 'bar')
      .attr('x', d => x(d.response)!)
      .attr('y', d => y(d.percentage))
      .attr('width', x.bandwidth())
      .attr('height', d => height - y(d.percentage))
      .attr('fill', d => getResponseColor(d.response, data.length))
      .attr('rx', 4)
      .on('mouseover', function(event, d) {
        d3.select(this).attr('opacity', 0.8);
        setHoveredBar(d.response);
      })
      .on('mouseout', function() {
        d3.select(this).attr('opacity', 1);
        setHoveredBar(null);
      })
      .on('click', (_, d) => setSelectedResponse(d.response));

    // Add value labels
    g.selectAll('.label')
      .data(data)
      .join('text')
      .attr('class', 'label')
      .attr('x', d => x(d.response)! + x.bandwidth() / 2)
      .attr('y', d => y(d.percentage) - 10)
      .attr('text-anchor', 'middle')
      .attr('font-size', '12px')
      .attr('font-weight', 'bold')
      .text(d => `${d.percentage.toFixed(1)}%`);

    // Add axes
    g.append('g')
      .attr('transform', `translate(0,${height})`)
      .call(d3.axisBottom(x))
      .selectAll('text')
      .attr('transform', 'rotate(-45)')
      .attr('text-anchor', 'end')
      .attr('dx', '-0.8em')
      .attr('dy', '0.15em')
      .attr('font-size', '12px');

    g.append('g')
      .call(d3.axisLeft(y).ticks(5).tickFormat(d => `${d}%`))
      .selectAll('text')
      .attr('font-size', '12px');
  };

  const renderDemographicChart = () => {
    if (!chartRef.current || !primaryDemographic) return;

    // Clear existing chart
    const svg = d3.select(chartRef.current);
    svg.selectAll('*').remove();

    const responseOptions = getResponseOptions();
    const responses = results[0].responses;
    
    // Process demographic data
    const demographicData = d3.rollup(
      responses,
      v => responseOptions.map(response => ({
        response,
        count: v.filter(r => r.response === response).length,
        percentage: (v.filter(r => r.response === response).length / v.length) * 100
      })),
      d => d.individualId[primaryDemographic]
    );
    
    const data = Array.from(demographicData, ([demographic, responses]) => ({
      demographic,
      responses
    })).sort((a, b) => {
      // Sort demographic values naturally
      const aValue = String(a.demographic);
      const bValue = String(b.demographic);
      return aValue.localeCompare(bValue, undefined, { numeric: true });
    });

    const margin = { top: 40, right: 120, bottom: 60, left: 100 };
    const width = chartRef.current.clientWidth - margin.left - margin.right;
    const height = Math.max(400, data.length * 50) - margin.top - margin.bottom;

    const y0 = d3.scaleBand()
      .domain(data.map(d => String(d.demographic)))
      .range([0, height])
      .padding(0.3);

    const y1 = d3.scaleBand()
      .domain(responseOptions)
      .range([0, y0.bandwidth()])
      .padding(0.1);

    const x = d3.scaleLinear()
      .domain([0, 100])
      .range([0, width]);

    // Create chart container
    const g = svg
      .attr('width', width + margin.left + margin.right)
      .attr('height', height + margin.top + margin.bottom)
      .append('g')
      .attr('transform', `translate(${margin.left},${margin.top})`);

    // Add vertical grid lines
    g.append('g')
      .attr('class', 'grid')
      .call(d3.axisBottom(x)
        .tickSize(height)
        .tickFormat(() => '')
      )
      .style('stroke-dasharray', '2,2')
      .style('stroke-opacity', 0.1)
      .style('shape-rendering', 'crispEdges');

    // Add bars for each demographic value
    data.forEach(d => {
      const barGroup = g.append('g')
        .attr('transform', `translate(0,${y0(String(d.demographic))})`);

      barGroup.selectAll('.bar')
        .data(d.responses)
        .join('rect')
        .attr('class', 'bar')
        .attr('y', response => y1(response.response)!)
        .attr('x', 0)
        .attr('height', y1.bandwidth())
        .attr('width', response => x(response.percentage))
        .attr('fill', response => getResponseColor(response.response, responseOptions.length))
        .attr('rx', 2)
        .attr('opacity', 0.9)
        .on('mouseover', function(event, d) {
          d3.select(this)
            .attr('opacity', 1)
            .attr('stroke', '#000')
            .attr('stroke-width', 1);
        })
        .on('mouseout', function() {
          d3.select(this)
            .attr('opacity', 0.9)
            .attr('stroke', 'none');
        });

      // Add percentage labels
      barGroup.selectAll('.label')
        .data(d.responses)
        .join('text')
        .attr('class', 'label')
        .attr('y', response => y1(response.response)! + y1.bandwidth() / 2)
        .attr('x', response => x(response.percentage) + 5)
        .attr('dy', '0.35em')
        .attr('font-size', '11px')
        .attr('fill', '#666')
        .text(response => `${response.percentage.toFixed(1)}%`);
    });

    // Add x-axis
    g.append('g')
      .attr('transform', `translate(0,${height})`)
      .call(d3.axisBottom(x).ticks(5).tickFormat(d => `${d}%`))
      .selectAll('text')
      .attr('font-size', '12px')
      .attr('fill', '#666');

    // Add y-axis with demographic labels
    g.append('g')
      .call(d3.axisLeft(y0)
        .tickFormat(d => {
          const label = String(d);
          return label.length > 20 ? label.substring(0, 17) + '...' : label;
        }))
      .selectAll('text')
      .attr('font-size', '12px')
      .attr('fill', '#666')
      .style('text-anchor', 'end');

    // Add legend
    const legend = g.append('g')
      .attr('transform', `translate(${width + 20}, 0)`);

    responseOptions.forEach((response, i) => {
      const legendItem = legend.append('g')
        .attr('transform', `translate(0, ${i * 30})`);

      legendItem.append('rect')
        .attr('width', 16)
        .attr('height', 16)
        .attr('fill', getResponseColor(response, responseOptions.length))
        .attr('rx', 2)
        .attr('opacity', 0.9);

      legendItem.append('text')
        .attr('x', 28)
        .attr('y', 13)
        .attr('font-size', '12px')
        .attr('fill', '#666')
        .text(response);
    });
  };

  const renderCrossAnalysisChart = () => {
    if (!chartRef.current || !primaryDemographic || !secondaryDemographic || !results[0]?.responses) return;

    const svg = d3.select(chartRef.current);
    svg.selectAll('*').remove();

    const responses = results[0].responses;
    const responseOptions = getResponseOptions();

    // Process data for cross analysis
    const crossData = d3.group(responses, 
      d => d.individualId[primaryDemographic],
      d => d.individualId[secondaryDemographic],
      d => d.response
    );

    // Convert nested Map to array structure
    const data = Array.from(crossData, ([primary, secondaryMap]) => ({
      primary,
      secondary: Array.from(secondaryMap, ([secondary, responseMap]) => ({
        secondary,
        responses: Object.fromEntries(responseMap),
        total: Array.from(responseMap.values()).reduce((a, b) => a + b, 0)
      }))
    }));

    const margin = { top: 40, right: 160, bottom: 100, left: 100 };
    const width = chartRef.current.clientWidth - margin.left - margin.right;
    const height = Math.max(400, data.length * 50) - margin.top - margin.bottom;

    // Create scales
    const x = d3.scaleBand()
      .domain(data.map(d => String(d.primary)))
      .range([0, width])
      .padding(0.1);

    const uniqueSecondary = Array.from(new Set(data.flatMap(d => d.secondary.map(s => s.secondary))));
    const y = d3.scaleBand()
      .domain(uniqueSecondary.map(String))
      .range([0, height])
      .padding(0.1);

    const color = d3.scaleSequential()
      .domain([0, 100])
      .interpolator(d3.interpolateBlues);

    // Create chart container
    const g = svg
      .attr('width', width + margin.left + margin.right)
      .attr('height', height + margin.top + margin.bottom)
      .append('g')
      .attr('transform', `translate(${margin.left},${margin.top})`);

    // Add cells
    data.forEach(d => {
      d.secondary.forEach(s => {
        const cellWidth = x.bandwidth();
        const cellHeight = y.bandwidth();

        // Calculate dominant response
        const dominantResponse = Object.entries(s.responses)
          .reduce((a, b) => (a[1] > b[1] ? a : b))[0];
        const dominantPercentage = (s.responses[dominantResponse] / s.total) * 100;

        const cell = g.append('g')
          .attr('transform', `translate(${x(String(d.primary))},${y(String(s.secondary))})`);

        // Add background rect
        cell.append('rect')
          .attr('width', cellWidth)
          .attr('height', cellHeight)
          .attr('fill', color(dominantPercentage))
          .attr('rx', 4)
          .attr('opacity', 0.8)
          .on('mouseover', function() {
            d3.select(this)
              .attr('opacity', 1)
              .attr('stroke', '#000')
              .attr('stroke-width', 1);
          })
          .on('mouseout', function() {
            d3.select(this)
              .attr('opacity', 0.8)
              .attr('stroke', 'none');
          });

        // Add response text
        cell.append('text')
          .attr('x', cellWidth / 2)
          .attr('y', cellHeight / 2)
          .attr('text-anchor', 'middle')
          .attr('dominant-baseline', 'middle')
          .attr('font-size', '12px')
          .attr('fill', dominantPercentage > 50 ? '#fff' : '#000')
          .text(`${dominantResponse} (${dominantPercentage.toFixed(0)}%)`);
      });
    });

    // Add axes
    g.append('g')
      .attr('transform', `translate(0,${height})`)
      .call(d3.axisBottom(x))
      .selectAll('text')
      .attr('transform', 'rotate(-45)')
      .attr('text-anchor', 'end')
      .attr('dx', '-0.8em')
      .attr('dy', '0.15em')
      .attr('font-size', '12px');

    g.append('g')
      .call(d3.axisLeft(y))
      .selectAll('text')
      .attr('font-size', '12px');

    // Add color legend
    const legendWidth = 20;
    const legendHeight = height;
    const legend = svg
      .append('g')
      .attr('transform', `translate(${width + margin.left + 60},${margin.top})`);

    const legendScale = d3.scaleLinear()
      .domain([0, 100])
      .range([legendHeight, 0]);

    const legendAxis = d3.axisRight(legendScale)
      .tickSize(legendWidth)
      .ticks(5);

    legend.append('g')
      .call(legendAxis)
      .select('.domain')
      .remove();

    const gradientData = Array.from({ length: 100 }, (_, i) => ({
      offset: i + '%',
      color: color(i)
    }));

    const gradient = legend.append('defs')
      .append('linearGradient')
      .attr('id', 'legend-gradient')
      .attr('gradientUnits', 'userSpaceOnUse')
      .attr('x1', 0)
      .attr('y1', legendHeight)
      .attr('x2', 0)
      .attr('y2', 0);

    gradient.selectAll('stop')
      .data(gradientData)
      .enter()
      .append('stop')
      .attr('offset', d => d.offset)
      .attr('stop-color', d => d.color);

    legend.append('rect')
      .attr('width', legendWidth)
      .attr('height', legendHeight)
      .style('fill', 'url(#legend-gradient)');

    // Add axis labels
    g.append('text')
      .attr('transform', `translate(${-margin.left + 20},${height/2}) rotate(-90)`)
      .attr('text-anchor', 'middle')
      .attr('font-size', '14px')
      .attr('fill', '#666')
      .text(secondaryDemographic);

    g.append('text')
      .attr('transform', `translate(${width/2},${height + margin.bottom - 10})`)
      .attr('text-anchor', 'middle')
      .attr('font-size', '14px')
      .attr('fill', '#666')
      .text(primaryDemographic);
  };

  const handleExcelExport = () => {
    if (!results[0]?.responses?.length) return;

    try {
      const wb = xlsxUtils.book_new();

      // Raw Data Sheet with context
      const rawData = results[0].responses.map(r => {
        if (!r.individualId) {
          console.warn('Missing individualId for response:', r);
          return null;
        }

        // Basic response data
        const baseData = {
          Response: r.response,
          Temperature: r.temperature.toFixed(2),
          'User Context': r.individualId.user_context || '',
          'Context Documents': stimulus?.metadata?.contextDocuments?.map(d => d.summary).join(' | ') || '',
          // Add expert reflections from the response
          'Financial Analysis': r.expertReflections?.financial || r.expertAnalysis?.financial || '',
          'Career Analysis': r.expertReflections?.career || r.expertAnalysis?.career || '',
          'Lifestyle Analysis': r.expertReflections?.lifestyle || r.expertAnalysis?.lifestyle || '',
          'Mental Health Analysis': r.expertReflections?.mental_health || r.expertAnalysis?.mental_health || '',
          'Relationship Analysis': r.expertReflections?.relationship || r.expertAnalysis?.relationship || ''
        };

        // Add all individual demographic data
        const demographicData = { ...r.individualId };
        delete demographicData.user_context; // Remove from demographic data since we added it separately

        // Combine all data
        return {
          ...baseData,
          ...demographicData
        };
      }).filter(Boolean); // Remove null entries

      const rawWs = xlsxUtils.json_to_sheet(rawData);
      xlsxUtils.book_append_sheet(wb, rawWs, 'Raw Data');

      // Demographics Sheet
      const summaryData = [
        ['Title', title],
        ['Summary', summary],
        ['Total Responses', totalResponses.toString()],
        [''],
        ['Expert Analysis Available', results[0].responses.some(r => r.expertReflections || r.expertAnalysis) ? 'Yes' : 'No'],
        [''],
        ['Context Information'],
        ['User Context Available', results[0].responses.some(r => r.individualId?.user_context) ? 'Yes' : 'No'],
        ['Context Documents', stimulus?.metadata?.contextDocuments?.length || 0],
        [''],
        ['Demographics Breakdown']
      ];

      const distribution = results[0].responses.reduce((acc, r) => {
        acc[r.response] = {
          count: (acc[r.response]?.count || 0) + 1
        };
        return acc;
      }, {} as Record<string, { count: number; confidence: number }>);

      Object.entries(distribution).forEach(([response, { count }]) => {
        summaryData.push([
          response,
          count.toString(),
          `${((count / totalResponses) * 100).toFixed(1)}%`
        ]);
      });

      const summaryWs = xlsxUtils.aoa_to_sheet(summaryData);
      xlsxUtils.book_append_sheet(wb, summaryWs, 'Summary');

      // Context Documents Sheet
      if (stimulus?.metadata?.contextDocuments?.length) {
        const contextData = [
          ['Context Documents'],
          [''],
          ['Document', 'Summary']
        ];

        stimulus.metadata.contextDocuments.forEach((doc, index) => {
          contextData.push([
            `Document ${index + 1}`,
            doc.summary
          ]);
        });

        const contextWs = xlsxUtils.aoa_to_sheet(contextData);
        xlsxUtils.book_append_sheet(wb, contextWs, 'Context');
      }

      // Save as CSV
      const fileName = `${title.replace(/[^a-z0-9]/gi, '_').toLowerCase()}_results.csv`;
      xlsxWriteFile(wb, fileName, { bookType: 'csv' });
    } catch (err) {
      console.error('Error exporting to Excel:', err);
      setError('Failed to export results');
    }
  };

  const handlePdfExport = async () => {
    if (!reportRef.current) return;
    setExportingPdf(true);

    try {
      const canvas = await html2canvas(reportRef.current, {
        scale: 2,
        logging: false,
        useCORS: true,
        backgroundColor: '#ffffff'
      });

      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4'
      });

      const imgWidth = 190;
      const imgHeight = (canvas.height * imgWidth) / canvas.width;

      pdf.addImage(imgData, 'PNG', 10, 10, imgWidth, imgHeight);
      pdf.save(`${title.replace(/[^a-z0-9]/gi, '_').toLowerCase()}_results.pdf`);
    } catch (err) {
      console.error('Error exporting to PDF:', err);
      setError('Failed to export results');
    } finally {
      setExportingPdf(false);
    }
  };
  
  const handleChatSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim()) return;
    
    const userMessage = chatInput.trim();
    setChatInput('');
    setChatHistory(prev => [...prev, { role: 'user', content: userMessage }]);
    setIsChatLoading(true);
    
    try {
      const openai = getOpenAIClient();
      const response = await openai.chat.completions.create({
        model: "gpt-4",
        messages: [
          {
            role: "system",
            content: `You are a data analysis assistant helping analyze survey results. Here is the context:

Title: ${title}
Summary: ${summary}
Total Responses: ${totalResponses}
Distribution: ${JSON.stringify(results[0].aggregates.distribution)}
Demographics: ${JSON.stringify(results[0].aggregates.demographics)}

Provide clear, concise answers focused on the data. Use specific numbers and percentages when relevant.`
          },
          ...chatHistory.map(msg => ({ role: msg.role, content: msg.content })),
          { role: "user", content: userMessage }
        ],
        temperature: 0.7
      });

      const assistantMessage = response.choices[0].message.content || "I couldn't analyze that aspect of the data.";
      setChatHistory(prev => [...prev, { role: 'assistant', content: assistantMessage }]);
      
    } catch (error) {
      console.error('Chat error:', error);
      setChatHistory(prev => [...prev, { 
        role: 'assistant', 
        content: "I apologize, but I encountered an error analyzing the data. Please try rephrasing your question." 
      }]);
    } finally {
      setIsChatLoading(false);
    }
  };

  useEffect(() => {
    if (chatEndRef.current) {
      chatEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [chatHistory]);

  return (
    <div className="space-y-6" ref={reportRef}>
      {onBack && (
        <button
          onClick={onBack}
          className="flex items-center text-gray-600 hover:text-gray-900"
        >
          <ArrowLeft className="w-5 h-5 mr-2" />
          Back to Simulations
        </button>
      )}

      <div className="glass-card p-8">
        <h1 className="text-2xl font-bold text-gray-900 mb-4">{title}</h1>
        
        {/* Scale Type Indicator */}
        {stimulus?.metadata?.scale && (
          <div className="mb-4 flex items-center gap-3">
            <span className="px-3 py-1.5 bg-primary/10 text-primary rounded-full text-sm font-medium">
              {stimulus.metadata.scale.type.charAt(0).toUpperCase() + stimulus.metadata.scale.type.slice(1)} Scale
            </span>
            {stimulus.metadata.scale.description && (
              <span className="text-sm text-gray-500">{stimulus.metadata.scale.description}</span>
            )}
          </div>
        )}
        
        <div className="glass bg-primary/5 p-6 rounded-xl mb-8">
          <p className="text-gray-800 dark:text-gray-200 font-medium leading-relaxed">{summary}</p>
        </div>

        {/* Detailed Statistics */}
        <div className="mt-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="glass p-6 rounded-xl hover:scale-[1.02] transition-transform duration-200">
            <div className="flex items-center gap-3 mb-3">
              <Users className="w-5 h-5 text-primary" />
              <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300">Total Responses</h3>
            </div>
            <p className="text-3xl font-bold text-gray-900 dark:text-white">{totalResponses}</p>
          </div>
          
          <div className="glass p-6 rounded-xl hover:scale-[1.02] transition-transform duration-200">
            <div className="flex items-center gap-3 mb-3">
              <BarChart3 className="w-5 h-5 text-primary" />
              <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300">Most Common</h3>
            </div>
            <div>
              <p className="text-3xl font-bold text-gray-900 dark:text-white">
                {Object.entries(results[0]?.aggregates?.distribution || {})
                  .sort(([,a], [,b]) => b - a)[0]?.[0] || 'N/A'}
              </p>
              <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                {((Object.entries(results[0]?.aggregates?.distribution || {})
                  .sort(([,a], [,b]) => b - a)[0]?.[1] || 0) / totalResponses * 100).toFixed(1)}% of responses
              </p>
            </div>
          </div>
          
          <div className="glass p-6 rounded-xl hover:scale-[1.02] transition-transform duration-200">
            <div className="flex items-center gap-3 mb-3">
              <Users className="w-5 h-5 text-primary" />
              <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300">Demographics</h3>
            </div>
            <p className="text-3xl font-bold text-gray-900 dark:text-white">{demographics.length}</p>
          </div>
        </div>

        <div className="mt-8">
          <div className="flex space-x-4 mb-6">
            <button
              onClick={() => setView('distribution')}
              className={`px-4 py-2 rounded-md ${
                view === 'distribution'
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              Overall Distribution
            </button>
            <button
              onClick={() => setView('demographics')}
              className={`px-4 py-2 rounded-md ${
                view === 'demographics'
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              Demographic Breakdown
            </button>
            <button
              onClick={() => setView('cross-analysis')}
              className={`px-4 py-2 rounded-md ${
                view === 'cross-analysis'
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              Cross Analysis
            </button>
            <button
              onClick={() => setView('chat')}
              className={`px-4 py-2 rounded-md ${
                view === 'chat'
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              <div className="flex items-center gap-2">
                <MessageSquare className="w-4 h-4" />
                Chat with Data
              </div>
            </button>
          </div>

          {/* Chart Container */}
          <div>
            {view === 'demographics' && (
              <div className="mb-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Primary Demographic
                      </label>
                      <select
                        value={primaryDemographic}
                        onChange={(e) => setPrimaryDemographic(e.target.value)}
                        className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md"
                      >
                        <option value="">Choose a demographic...</option>
                        {demographics.map(demo => (
                          <option key={demo} value={demo}>{demo.replace(/_/g, ' ').split(' ').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')}</option>
                        ))}
                      </select>
                    </div>
                    
                    {/* Selected Demographics */}
                    <div className="flex flex-wrap gap-2">
                      {selectedDemographics.map(demo => (
                        <span 
                          key={demo}
                          className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm font-medium flex items-center"
                        >
                          {demo.replace(/_/g, ' ').split(' ').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')}
                          <button
                            onClick={() => setSelectedDemographics(prev => prev.filter(d => d !== demo))}
                            className="ml-2 text-blue-600 hover:text-blue-800"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </span>
                      ))}
                    </div>
                  </div>
                  
                  {/* Quick Stats */}
                  {primaryDemographic && (
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <h4 className="text-sm font-medium text-gray-700 mb-3">Quick Stats</h4>
                      <div className="space-y-2">
                        <div>
                          <p className="text-sm text-gray-600">Most Common</p>
                          <p className="text-lg font-semibold text-gray-900">
                            {Object.entries(results[0]?.aggregates?.demographics[primaryDemographic] || {})
                              .sort(([,a], [,b]) => b - a)[0]?.[0] || 'N/A'}
                          </p>
                        </div>
                        <div>
                          <p className="text-sm text-gray-600">Distribution</p>
                          <div className="flex gap-2 mt-1">
                            {Object.entries(results[0]?.aggregates?.demographics[primaryDemographic] || {})
                              .sort(([,a], [,b]) => b - a)
                              .slice(0, 3)
                              .map(([value, count]) => (
                                <div key={value} className="text-xs px-2 py-1 bg-blue-50 text-blue-700 rounded">
                                  {value}: {((count / totalResponses) * 100).toFixed(1)}%
                                </div>
                              ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}

            {view === 'cross-analysis' && primaryDemographic && (
              <div className="mb-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Secondary Demographic
                    </label>
                    <select
                      value={secondaryDemographic}
                      onChange={(e) => setSecondaryDemographic(e.target.value)}
                      className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md"
                    >
                      <option value="">Choose a demographic...</option>
                      {demographics
                        .filter(demo => demo !== primaryDemographic)
                        .map(demo => (
                          <option key={demo} value={demo}>
                            {demo.replace(/_/g, ' ').split(' ').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')}
                          </option>
                        ))}
                    </select>
                  </div>
                  
                  {/* Cross Analysis Insights */}
                  {secondaryDemographic && (
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <h4 className="text-sm font-medium text-gray-700 mb-3">Key Insights</h4>
                      <div className="space-y-2">
                        <div>
                          <p className="text-sm text-gray-600">Strongest Correlation</p>
                          <p className="text-lg font-semibold text-gray-900">
                            {`${primaryDemographic.replace(/_/g, ' ')} × ${secondaryDemographic.replace(/_/g, ' ')}`}
                          </p>
                        </div>
                        <div>
                          <p className="text-sm text-gray-600">Pattern</p>
                          <div className="text-xs px-2 py-1 bg-blue-50 text-blue-700 rounded mt-1">
                            Click cells to explore specific combinations
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}

            {view !== 'chat' && (
              <div className="bg-gray-50 p-6 rounded-lg relative overflow-visible">
                <svg ref={chartRef} className="w-full h-[400px]" />
                {((view === 'demographics' && !primaryDemographic) ||
                  (view === 'cross-analysis' && (!primaryDemographic || !secondaryDemographic))) && (
                  <div className="absolute inset-0 flex items-center justify-center bg-gray-50 bg-opacity-90">
                    <p className="text-gray-500">
                      {view === 'demographics' 
                        ? 'Select a demographic to view the breakdown'
                        : 'Select both demographics for cross analysis'}
                    </p>
                  </div>
                )}
              </div>
            )}
          </div>
          
          {view === 'chat' && (
            <div className="bg-white rounded-lg shadow-sm p-6">
              <div className="flex items-center gap-2 mb-4">
                <Brain className="w-5 h-5 text-blue-500" />
                <h3 className="text-lg font-medium">Chat with Your Data</h3>
              </div>
              
              <div className="h-[400px] overflow-y-auto mb-4 space-y-4">
                {chatHistory.map((message, index) => (
                  <div
                    key={index}
                    className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
                  >
                    <div
                      className={`max-w-[80%] rounded-lg p-3 ${
                        message.role === 'user'
                          ? 'bg-blue-500 text-white'
                          : 'bg-gray-100 text-gray-900'
                      }`}
                    >
                      {message.content}
                    </div>
                  </div>
                ))}
                {isChatLoading && (
                  <div className="flex justify-start">
                    <div className="bg-gray-100 rounded-lg p-3 animate-pulse">
                      Analyzing data...
                    </div>
                  </div>
                )}
                <div ref={chatEndRef} />
              </div>
              
              <form onSubmit={handleChatSubmit} className="flex gap-2">
                <input
                  type="text"
                  value={chatInput}
                  onChange={(e) => setChatInput(e.target.value)}
                  placeholder="Ask about your data..."
                  className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  disabled={isChatLoading}
                />
                <button
                  type="submit"
                  disabled={isChatLoading || !chatInput.trim()}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <Send className="w-5 h-5" />
                </button>
              </form>
            </div>
          )}
        </div>
        
        {/* Export Button */}
        <div className="mt-6 flex justify-end">
          <div className="flex-1">
            <div className="text-sm text-gray-600 dark:text-gray-400">
              <span className="font-medium text-gray-900 dark:text-white">Analysis Note:</span> Based on {totalResponses} responses
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <button
              onClick={handleExcelExport}
              className="btn btn-primary"
            >
              <FileText className="w-4 h-4 mr-2" />
              Export Raw Data
            </button>
            <button
              onClick={handlePdfExport}
              disabled={exportingPdf}
              className="btn btn-primary"
            >
              <Download className="w-4 h-4 mr-2" />
              {exportingPdf ? 'Exporting...' : 'Export PDF'}
            </button>
          </div>
        </div>
      </div>

      {/* Response Details */}
      {selectedResponse && (
        <div className="mt-6 bg-gray-50 p-4 rounded-lg">
          <h3 className="text-lg font-medium text-gray-900 mb-4">
            Details for "{selectedResponse}"
          </h3>
          <dl className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <dt className="text-sm font-medium text-gray-500">Count</dt>
              <dd className="mt-1 text-3xl font-semibold text-gray-900">
                {results[0]?.aggregates?.distribution[selectedResponse] || 0}
              </dd>
            </div>
            <div>
              <dt className="text-sm font-medium text-gray-500">Percentage</dt>
              <dd className="mt-1 text-3xl font-semibold text-gray-900">
                {((results[0]?.aggregates?.distribution[selectedResponse] || 0) / totalResponses * 100).toFixed(1)}%
              </dd>
            </div>
            <div>
              <dt className="text-sm font-medium text-gray-500">Avg Confidence</dt>
              <dd className="mt-1 text-3xl font-semibold text-gray-900">
                {(results[0]?.responses
                  ?.filter(r => r.response === selectedResponse)
                  .reduce((acc, r) => acc + r.confidence, 0) / 
                  (results[0]?.responses?.filter(r => r.response === selectedResponse).length || 1) * 100)
                  .toFixed(1)}%
              </dd>
            </div>
          </dl>
        </div>
      )}
    </div>
  );
}