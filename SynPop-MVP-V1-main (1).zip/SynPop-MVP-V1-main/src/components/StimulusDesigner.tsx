import React, { useState } from 'react';
import { Zap, Plus, X, Scale } from 'lucide-react';
import type { Stimulus } from '../types';

type StimulusType = 'single' | 'questionnaire';

interface StimulusDesignerProps {
  onStimulusCreate: (stimulus: Stimulus) => void;
}

export function StimulusDesigner({ onStimulusCreate }: StimulusDesignerProps) {
  const [selectedType, setSelectedType] = useState<StimulusType | null>(null);
  const [content, setContent] = useState('');
  const [items, setItems] = useState<string[]>(['']);
  const [scaleType, setScaleType] = useState<'likert' | 'binary' | 'custom'>('likert');
  const [customScale, setCustomScale] = useState<string[]>(['']);
  const [error, setError] = useState<string | null>(null);

  if (!selectedType) {
    return (
      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="flex items-center mb-6">
          <Zap className="w-6 h-6 text-blue-500 mr-2" />
          <h2 className="text-xl font-semibold">Choose Stimulus Type</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <button
            onClick={() => setSelectedType('single')}
            className="p-6 border-2 border-gray-200 rounded-lg hover:border-blue-500 hover:bg-blue-50 transition-all duration-200"
          >
            <h3 className="text-lg font-medium mb-2">Single Item</h3>
            <p className="text-sm text-gray-600">
              Create a single question or statement for participants to respond to.
            </p>
          </button>

          <button
            onClick={() => setSelectedType('questionnaire')}
            className="p-6 border-2 border-gray-200 rounded-lg hover:border-blue-500 hover:bg-blue-50 transition-all duration-200"
          >
            <h3 className="text-lg font-medium mb-2">Questionnaire</h3>
            <p className="text-sm text-gray-600">
              Create a group of related questions with consistent response options.
            </p>
          </button>
        </div>
      </div>
    );
  }

  const handleAddItem = () => {
    setItems([...items, '']);
  };

  const handleRemoveItem = (index: number) => {
    setItems(items.filter((_, i) => i !== index));
  };

  const handleItemChange = (index: number, value: string) => {
    const newItems = [...items];
    newItems[index] = value;
    setItems(newItems);
  };

  const handleAddScaleOption = () => {
    setCustomScale([...customScale, '']);
  };

  const handleRemoveScaleOption = (index: number) => {
    setCustomScale(customScale.filter((_, i) => i !== index));
  };

  const handleScaleOptionChange = (index: number, value: string) => {
    const newScale = [...customScale];
    newScale[index] = value;
    setCustomScale(newScale);
  };

  const getScaleOptions = () => {
    switch (scaleType) {
      case 'likert':
        return [
          'Strongly Disagree',
          'Disagree',
          'Neutral',
          'Agree',
          'Strongly Agree'
        ];
      case 'binary':
        return ['Yes', 'No'];
      case 'custom':
        return customScale.filter(option => option.trim() !== '');
      default:
        return [];
    }
  };

  const handleCreate = () => {
    try {
      // Validate based on type
      if (selectedType === 'single') {
        if (!content.trim()) {
          throw new Error('Question or statement is required');
        }
      } else {
        const validItems = items.filter(item => item.trim() !== '');
        if (validItems.length === 0) {
          throw new Error('At least one question is required');
        }
      }

      const scaleOptions = getScaleOptions();
      if (scaleOptions.length === 0) {
        throw new Error('Scale options are required');
      }

      // Create stimulus based on type
      const stimulus: Stimulus = {
        id: crypto.randomUUID(),
        type: 'text',
        content: selectedType === 'single' ? content : items[0],
        metadata: {
          createdAt: new Date().toISOString(),
          items: selectedType === 'questionnaire' ? items.filter(item => item.trim()) : [],
          scale: {
            type: scaleType,
            options: scaleOptions
          }
        }
      };

      onStimulusCreate(stimulus);
      setContent('');
      setItems(['']);
      setCustomScale(['']);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to create stimulus');
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex items-center mb-6">
        <Zap className="w-6 h-6 text-blue-500 mr-2" />
        <div className="flex-1">
          <h2 className="text-xl font-semibold">
            {selectedType === 'single' ? 'Single Item' : 'Questionnaire'}
          </h2>
          <button
            onClick={() => setSelectedType(null)}
            className="text-sm text-blue-600 hover:text-blue-700"
          >
            Change Type
          </button>
        </div>
      </div>

      <div className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            {selectedType === 'single' ? 'Question or Statement' : 'Introduction Text (Optional)'}
          </label>
          <textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            rows={4}
            className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
            placeholder={selectedType === 'single' 
              ? "Enter your question or statement..."
              : "Enter introduction text for the questionnaire..."}
          />
        </div>

        {selectedType === 'questionnaire' && (
          <div>
          <div className="flex items-center justify-between mb-2">
            <label className="block text-sm font-medium text-gray-700">
              Questions
            </label>
            <button
              onClick={handleAddItem}
              className="flex items-center text-sm text-blue-600 hover:text-blue-700"
            >
              <Plus className="w-4 h-4 mr-1" />
              Add Question
            </button>
          </div>
          <div className="space-y-2">
            {items.map((item, index) => (
              <div key={index} className="flex items-center space-x-2">
                <input
                  type="text"
                  value={item}
                  onChange={(e) => handleItemChange(index, e.target.value)}
                  className="flex-1 px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                  placeholder="Enter question text..."
                />
                {items.length > 1 && (
                  <button
                    onClick={() => handleRemoveItem(index)}
                    className="text-red-500 hover:text-red-700"
                  >
                    <X className="w-5 h-5" />
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>)}

        <div>
          <div className="flex items-center mb-2">
            <Scale className="w-4 h-4 text-gray-500 mr-2" />
            <label className="block text-sm font-medium text-gray-700">
              Response Scale
            </label>
          </div>
          <select
            value={scaleType}
            onChange={(e) => setScaleType(e.target.value as any)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
          >
            <option value="likert">5-point Likert Scale</option>
            <option value="binary">Yes/No</option>
            <option value="custom">Custom Scale</option>
          </select>

          {scaleType === 'custom' && (
            <div className="mt-4 space-y-2">
              <div className="flex items-center justify-between mb-2">
                <label className="block text-sm font-medium text-gray-700">
                  Custom Scale Options
                </label>
                <button
                  onClick={handleAddScaleOption}
                  className="flex items-center text-sm text-blue-600 hover:text-blue-700"
                >
                  <Plus className="w-4 h-4 mr-1" />
                  Add Option
                </button>
              </div>
              {customScale.map((option, index) => (
                <div key={index} className="flex items-center space-x-2">
                  <input
                    type="text"
                    value={option}
                    onChange={(e) => handleScaleOptionChange(index, e.target.value)}
                    className="flex-1 px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                    placeholder="Enter scale option..."
                  />
                  {customScale.length > 1 && (
                    <button
                      onClick={() => handleRemoveScaleOption(index)}
                      className="text-red-500 hover:text-red-700"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-md">
            {error}
          </div>
        )}

        <button
          onClick={handleCreate}
          disabled={
            (selectedType === 'single' && !content.trim()) ||
            (selectedType === 'questionnaire' && items.every(item => !item.trim()))
          }
          className={`
            w-full py-2 px-4 rounded-md text-white font-medium
            ${(selectedType === 'single' && !content.trim()) ||
              (selectedType === 'questionnaire' && items.every(item => !item.trim()))
              ? 'bg-gray-400 cursor-not-allowed'
              : 'bg-blue-600 hover:bg-blue-700'}
          `}
        >
          {selectedType === 'single' ? 'Create Single Item' : 'Create Questionnaire'}
        </button>
      </div>
    </div>
  );
}