import React, { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { Users, Zap, BarChart3, Plus, Loader2, Clock, Activity, Database, CheckCircle, ChevronDown, ChevronRight } from 'lucide-react';
import type { Population, Simulation } from '../types';
import { useNavigate } from 'react-router-dom';

export function Dashboard() {
  const navigate = useNavigate();
  const [recentSimulations, setRecentSimulations] = useState<Simulation[]>([]);
  const [activeSimulations, setActiveSimulations] = useState<Simulation[]>([]);
  const [recentPopulations, setRecentPopulations] = useState<Population[]>([]);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({
    profilesLoaded: 0,
    stimuliCreated: 0,
    simulationsRun: 0
  });
  const [isSystemStatusExpanded, setIsSystemStatusExpanded] = useState(false);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  async function fetchDashboardData() {
    try {
      // Fetch recent simulations - limit to 3
      const { data: simulations } = await supabase
        .from('simulations')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(3);

      // Fetch active simulations
      const { data: active } = await supabase
        .from('simulations')
        .select('*')
        .eq('status', 'in-progress')
        .order('created_at', { ascending: false });

      // Fetch recent populations - limit to 3
      const { data: populations } = await supabase
        .from('populations')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(3);

      // Fetch statistics
      const { data: allPopulations } = await supabase
        .from('populations')
        .select('size');

      const { count: stimuliCount } = await supabase
        .from('stimuli')
        .select('*', { count: 'exact', head: true });

      const { count: simulationsCount } = await supabase
        .from('simulations')
        .select('*', { count: 'exact', head: true });

      if (simulations) setRecentSimulations(simulations);
      if (active) setActiveSimulations(active);
      if (populations) setRecentPopulations(populations);

      setStats({
        profilesLoaded: allPopulations?.reduce((sum, pop) => sum + pop.size, 0) || 0,
        stimuliCreated: stimuliCount || 0,
        simulationsRun: simulationsCount || 0
      });
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
    } finally {
      setLoading(false);
    }
  }

  const handleCreatePopulation = () => {
    navigate('/populations?action=create');
  };

  const handleNewStimulus = () => {
    navigate('/stimuli?action=create');
  };

  const handleRunSimulation = () => {
    navigate('/simulations?action=create');
  };

  if (loading) {
    return (
      <div className="animate-pulse space-y-8">
        <div className="h-48 bg-gray-200 rounded-lg"></div>
        <div className="h-48 bg-gray-200 rounded-lg"></div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <button
          onClick={handleCreatePopulation}
          className="flex items-center justify-center p-6 bg-white rounded-lg shadow-sm hover:shadow-md transition-all duration-200 group"
        >
          <Users className="w-6 h-6 text-blue-500 mr-3 group-hover:scale-110 transition-transform" />
          <span className="text-gray-900">Create Population</span>
        </button>
        
        <button
          onClick={handleNewStimulus}
          className="flex items-center justify-center p-6 bg-white rounded-lg shadow-sm hover:shadow-md transition-all duration-200 group"
        >
          <Zap className="w-6 h-6 text-blue-500 mr-3 group-hover:scale-110 transition-transform" />
          <span className="text-gray-900">New Stimulus</span>
        </button>
        
        <button
          onClick={handleRunSimulation}
          className="flex items-center justify-center p-6 bg-white rounded-lg shadow-sm hover:shadow-md transition-all duration-200 group"
        >
          <BarChart3 className="w-6 h-6 text-blue-500 mr-3 group-hover:scale-110 transition-transform" />
          <span className="text-gray-900">Run Simulation</span>
        </button>
      </div>

      {/* Recent Activity */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Recent Simulations */}
        <div className="bg-white rounded-lg shadow-sm p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-gray-900">Recent Simulations</h2>
            <button
              onClick={handleRunSimulation}
              className="text-gray-400 hover:text-blue-500 transition-colors"
              title="Create New Simulation"
            >
              <Plus className="w-5 h-5" />
            </button>
          </div>
          
          {recentSimulations.length === 0 ? (
            <p className="text-gray-500">No simulations yet</p>
          ) : (
            <ul className="space-y-4">
              {recentSimulations.map((simulation) => (
                <li key={simulation.id} className="flex items-center justify-between">
                  <div>
                    <p className="font-medium text-gray-900">{simulation.name}</p>
                    <p className="text-sm text-gray-500">
                      {new Date(simulation.created_at).toLocaleDateString()}
                    </p>
                  </div>
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                    simulation.status === 'completed' 
                      ? 'bg-green-100 text-green-800'
                      : simulation.status === 'in-progress'
                      ? 'bg-blue-100 text-blue-800'
                      : 'bg-gray-100 text-gray-800'
                  }`}>
                    {simulation.status}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </div>

        {/* Recent Populations */}
        <div className="bg-white rounded-lg shadow-sm p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-gray-900">Recent Populations</h2>
            <button
              onClick={handleCreatePopulation}
              className="text-gray-400 hover:text-blue-500 transition-colors"
              title="Create New Population"
            >
              <Plus className="w-5 h-5" />
            </button>
          </div>
          
          {recentPopulations.length === 0 ? (
            <p className="text-gray-500">No populations yet</p>
          ) : (
            <ul className="space-y-4">
              {recentPopulations.map((population) => (
                <li key={population.id} className="flex items-center justify-between">
                  <div>
                    <p className="font-medium text-gray-900">{population.name}</p>
                    <p className="text-sm text-gray-500">
                      {population.size.toLocaleString()} individuals
                    </p>
                  </div>
                  <button 
                    onClick={() => navigate(`/populations?id=${population.id}`)}
                    className="text-blue-600 hover:text-blue-700 text-sm font-medium transition-colors"
                  >
                    View Details
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>

      {/* System Status */}
      <div className="bg-white rounded-lg shadow-sm p-6">
        <button 
          onClick={() => setIsSystemStatusExpanded(!isSystemStatusExpanded)}
          className="w-full flex items-center justify-between text-lg font-semibold text-gray-900 mb-4"
        >
          <span>System Status</span>
          {isSystemStatusExpanded ? (
            <ChevronDown className="w-5 h-5 text-gray-500" />
          ) : (
            <ChevronRight className="w-5 h-5 text-gray-500" />
          )}
        </button>
        
        {isSystemStatusExpanded && (
          <>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="flex items-center space-x-3">
                <Activity className="w-6 h-6 text-green-500" />
                <div>
                  <p className="text-sm text-gray-500">API Status</p>
                  <p className="font-medium text-green-600">Operational</p>
                </div>
              </div>

              <div className="flex items-center space-x-3">
                <Database className="w-6 h-6 text-blue-500" />
                <div>
                  <p className="text-sm text-gray-500">Profiles Loaded</p>
                  <p className="font-medium">{stats.profilesLoaded.toLocaleString()}</p>
                </div>
              </div>

              <div className="flex items-center space-x-3">
                <Zap className="w-6 h-6 text-yellow-500" />
                <div>
                  <p className="text-sm text-gray-500">Stimuli Created</p>
                  <p className="font-medium">{stats.stimuliCreated.toLocaleString()}</p>
                </div>
              </div>

              <div className="flex items-center space-x-3">
                <CheckCircle className="w-6 h-6 text-indigo-500" />
                <div>
                  <p className="text-sm text-gray-500">Simulations Run</p>
                  <p className="font-medium">{stats.simulationsRun.toLocaleString()}</p>
                </div>
              </div>
            </div>

            {/* Active Simulations */}
            {activeSimulations.length > 0 && (
              <div className="mt-6 pt-6 border-t border-gray-200">
                <h3 className="text-sm font-medium text-gray-500 mb-3">Active Simulations</h3>
                <ul className="space-y-3">
                  {activeSimulations.length === 0 ? (
                    <li className="text-sm text-gray-500">No active simulations</li>
                  ) : activeSimulations.map(simulation => (
                    <li key={simulation.id} className="flex items-center space-x-3">
                      <Clock className="w-5 h-5 text-blue-500" />
                      <span className="text-sm">{simulation.name}</span>
                      <div className="flex-grow" />
                      {simulation.status === 'in-progress' && (
                        <Loader2 className="w-4 h-4 animate-spin text-blue-500" />
                      )}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}