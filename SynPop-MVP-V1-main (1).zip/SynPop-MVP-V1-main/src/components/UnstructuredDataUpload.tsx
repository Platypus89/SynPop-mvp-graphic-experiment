import React, { useCallback, useState, useEffect } from 'react';
import { useDropzone } from 'react-dropzone';
import { FileText, AlertCircle, CheckCircle, Upload, Loader2 } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { getOpenAIClient } from '../lib/openai';
import { extractTextFromPDF } from '../lib/pdfWorker';
import type { Population } from '../types';

interface UnstructuredDataUploadProps {
  onPopulationCreated: (population: Population) => void;
}

export function UnstructuredDataUpload({ onPopulationCreated }: UnstructuredDataUploadProps) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [analysis, setAnalysis] = useState<{
    size: number;
    summary: string;
    demographics: Record<string, any[]>;
  } | null>(null);
  const [name, setName] = useState('');
  const [progress, setProgress] = useState<{
    step: string;
    current: number;
    total: number;
    message: string;
  }>({ step: '', current: 0, total: 0, message: '' });

  const onDrop = useCallback(async (acceptedFiles: File[]) => {
    if (!acceptedFiles.length) return;
    
    setLoading(true);
    setError(null);
    setAnalysis(null);
    setProgress({
      step: 'upload',
      current: 0,
      total: 100,
      message: 'Processing document...'
    });

    try {
      const file = acceptedFiles[0];
      let content: string;

      if (file.type === 'application/pdf') {
        const arrayBuffer = await file.arrayBuffer();
        content = await extractTextFromPDF(arrayBuffer);
      } else {
        content = await new Promise<string>((resolve) => {
          const reader = new FileReader();
          reader.onload = (e) => resolve(e.target?.result as string || '');
          reader.readAsText(file);
        });
      }

      setProgress({
        step: 'analysis',
        current: 0,
        total: 100,
        message: 'Analyzing document content...'
      });

      const openai = getOpenAIClient();
      
      const response = await openai.chat.completions.create({
        model: "gpt-4",
        messages: [
          {
            role: "system",
            content: `Analyze this document to extract workforce demographic information.
            Look for:
            - Total employee/headcount numbers
            - Gender distribution
            - Age groups
            - Job levels/roles
            - Geographic distribution
            - Any other relevant demographic data

            Return a JSON object with:
            {
              "size": total headcount (number),
              "summary": brief description of the population,
              "demographics": {
                "gender": [{"value": "Female", "percentage": 45}, {"value": "Male", "percentage": 55}],
                "age_group": [{"value": "20-30", "percentage": 30}, ...],
                "job_level": [{"value": "Entry", "percentage": 20}, ...],
                etc.
              }
            }`
          },
          {
            role: "user",
            content: content.substring(0, 8000)
          }
        ],
        temperature: 0.1
      });

      const analysisResult = JSON.parse(response.choices[0].message.content || '{}');
      
      if (!analysisResult.size || !analysisResult.demographics || !analysisResult.summary) {
        throw new Error('Invalid analysis format');
      }

      setName(file.name.replace(/\.[^/.]+$/, ''));
      setAnalysis(analysisResult);

    } catch (err) {
      console.error('Error processing file:', err);
      setError(err instanceof Error ? err.message : 'Failed to process file');
    } finally {
      setLoading(false);
      setProgress({ step: '', current: 0, total: 0, message: '' });
    }
  }, []);

  const handleCreate = async () => {
    if (!analysis) return;

    try {
      setLoading(true);
      setProgress({
        step: 'generation',
        current: 0,
        total: 100,
        message: 'Generating synthetic profiles...'
      });

      // Generate synthetic profiles based on demographics
      const openai = getOpenAIClient();
      const response = await openai.chat.completions.create({
        model: "gpt-4",
        messages: [
          {
            role: "system",
            content: `Generate synthetic employee profiles based on these demographics:
${JSON.stringify(analysis.demographics, null, 2)}

Return a JSON array of ${analysis.size} profiles with:
1. Demographic attributes matching the given distributions
2. Expert reflections for each profile with these fields:
   - financial: analysis of financial situation
   - career: career trajectory analysis
   - lifestyle: lifestyle patterns analysis
   - mental_health: mental health considerations
   - relationship: relationship and social analysis

Each expert reflection should be a detailed string based on the profile's demographics.`
          }
        ],
        temperature: 0.7
      });

      let profiles;
      try {
        profiles = JSON.parse(response.choices[0].message.content || '[]');
        
        // Validate and ensure expert reflections exist
        profiles = profiles.map(profile => {
          if (!profile.expert_reflections) {
            profile.expert_reflections = {
              financial: '',
              career: '',
              lifestyle: '',
              mental_health: '',
              relationship: ''
            };
          }
          return profile;
        });
      } catch (err) {
        console.error('Failed to parse profiles:', err);
        throw new Error('Failed to generate valid profiles');
      }

      setProgress({
        step: 'saving',
        current: 100,
        total: 100,
        message: 'Saving population...'
      });

      const population: Population = {
        id: crypto.randomUUID(),
        name: name || 'Unstructured Population',
        size: analysis.size,
        source_dataset: 'unstructured-analysis',
        attributes: profiles.map(profile => ({
          ...profile,
          expert_reflections: profile.expert_reflections || {
            financial: '',
            career: '',
            lifestyle: '',
            mental_health: '',
            relationship: ''
          }
        })),
        metadata: {
          creationMethod: 'unstructured',
          analysis: analysis
        },
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };

      const { error: saveError } = await supabase
        .from('populations')
        .insert([population]);

      if (saveError) throw saveError;

      onPopulationCreated(population);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to create population');
    } finally {
      setLoading(false);
      setProgress({ step: '', current: 0, total: 0, message: '' });
    }
  };

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'text/plain': ['.txt'],
      'text/markdown': ['.md'],
      'application/pdf': ['.pdf']
    },
    maxSize: 10 * 1024 * 1024, // 10MB
    multiple: false
  });

  return (
    <div className="space-y-6">
      <div
        {...getRootProps()}
        className={`
          p-8 border-2 border-dashed rounded-lg text-center cursor-pointer transition-all
          ${isDragActive ? 'border-blue-500 bg-blue-50' : 'border-gray-300 hover:border-blue-400'}
        `}
      >
        <input {...getInputProps()} />
        <Upload className={`w-12 h-12 mx-auto mb-4 ${isDragActive ? 'text-blue-500' : 'text-gray-400'}`} />
        <p className="text-lg font-medium text-gray-700">
          {isDragActive ? 'Drop the document here' : 'Drag & drop a document here, or click to select'}
        </p>
        <p className="mt-2 text-sm text-gray-500">
          Supported formats: TXT, MD, PDF (max 10MB)
        </p>
      </div>

      {(loading || progress.step) && (
        <div className="bg-blue-50 p-4 rounded-lg">
          <div className="flex items-center mb-2">
            <Loader2 className="w-5 h-5 text-blue-500 animate-spin mr-3" />
            <p className="text-blue-600 font-medium">{progress.message}</p>
          </div>
          {progress.step && (
            <div className="w-full bg-blue-100 rounded-full h-2">
              <div 
                className="bg-blue-500 h-2 rounded-full transition-all duration-300"
                style={{ width: `${(progress.current / progress.total) * 100}%` }}
              ></div>
            </div>
          )}
        </div>
      )}

      {error && (
        <div className="bg-red-50 p-4 rounded-lg flex items-center">
          <AlertCircle className="w-5 h-5 text-red-500 mr-3" />
          <p className="text-red-600">{error}</p>
        </div>
      )}

      {analysis && (
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center mb-4">
            <CheckCircle className="w-6 h-6 text-green-500 mr-2" />
            <h2 className="text-xl font-semibold">Analysis Complete</h2>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Population Name
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md"
                placeholder="Enter a name for this population"
              />
            </div>

            <div>
              <h3 className="text-sm font-medium text-gray-700 mb-2">Summary</h3>
              <p className="text-gray-600">{analysis.summary}</p>
            </div>

            <div className="bg-gray-50 p-4 rounded-lg">
              <h3 className="text-sm font-medium text-gray-700 mb-2">Population Size</h3>
              <p className="text-lg font-semibold">{analysis.size.toLocaleString()} individuals</p>
            </div>

            <div>
              <h3 className="text-sm font-medium text-gray-700 mb-2">Demographics</h3>
              <div className="space-y-3">
                {Object.entries(analysis.demographics).map(([category, distribution]) => (
                  <div key={category} className="bg-gray-50 p-3 rounded-md">
                    <h4 className="font-medium capitalize mb-2">{category.replace(/_/g, ' ')}</h4>
                    <div className="grid grid-cols-2 gap-2">
                      {distribution.map((item: any, index: number) => (
                        <div key={index} className="text-sm">
                          <span className="text-gray-600">{item.value}:</span>
                          <span className="ml-1 font-medium">{item.percentage}%</span>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <button
              onClick={handleCreate}
              disabled={loading}
              className="w-full py-2 px-4 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50"
            >
              {loading ? 'Creating Population...' : 'Create Population'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}