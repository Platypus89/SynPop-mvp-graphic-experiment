import React from 'react';
import { ResultsViewer } from './ResultsViewer';
import type { Simulation, Population, Stimulus } from '../types';

interface SimulationDetailsProps {
  simulation: Simulation;
  population?: Population;
  stimulus?: Stimulus;
  onBack: () => void;
}

export function SimulationDetails({ simulation, population, stimulus, onBack }: SimulationDetailsProps) {
  return (
    <ResultsViewer 
      results={[{
        id: simulation.id,
        name: simulation.name,
        responses: simulation.results.responses,
        aggregates: simulation.results.aggregates,
        results: {
          title: simulation.results.title,
          summary: simulation.results.summary
        }
      }]} 
      stimulus={stimulus}
      onBack={onBack}
    />
  );
}