import React, { useState, useEffect } from 'react';
import { Settings as SettingsIcon, Brain, Database, Activity, Sliders, BarChart as ChartBar } from 'lucide-react';
import { AVAILABLE_MODELS, getOpenAIClient } from '../lib/openai';
import { supabase } from '../lib/supabase';

export function Settings() {
  const [selectedModel, setSelectedModel] = useState(localStorage.getItem('selected_model') || 'gpt-4o');
  const [temperatureRange, setTemperatureRange] = useState({
    min: parseFloat(localStorage.getItem('temperature_min') || '0.3'),
    max: parseFloat(localStorage.getItem('temperature_max') || '0.8')
  });
  const [temperatureDistribution, setTemperatureDistribution] = useState(
    localStorage.getItem('temperature_distribution') || 'normal'
  );
  const [userEmail, setUserEmail] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);
  const [apiStatus, setApiStatus] = useState<{
    openai: boolean;
    xai: boolean;
    database: boolean;
  }>({
    openai: false,
    xai: false,
    database: true
  });

  useEffect(() => {
    supabase.auth.getUser().then(({ data: { user } }) => {
      if (user) {
        setUserEmail(user.email);
      }
    });
    
    // Check API status
    checkApiStatus();
  }, []);

  const checkApiStatus = async () => {
    try {
      // Check OpenAI
      if (import.meta.env.VITE_OPENAI_API_KEY) {
        const openai = getOpenAIClient();
        try {
          await openai.chat.completions.create({
            model: 'gpt-3.5-turbo',
            messages: [{ role: 'user', content: 'test' }],
            max_tokens: 1
          });
          setApiStatus(prev => ({ ...prev, openai: true }));
        } catch (err) {
          console.error('OpenAI API check failed:', err);
          setApiStatus(prev => ({ ...prev, openai: false }));
        }
      }
    } catch (err) {
      console.error('OpenAI API check failed:', err);
      setApiStatus(prev => ({ ...prev, openai: false }));
    }

    try {
      // Check X.AI
      if (import.meta.env.VITE_XAI_API_KEY) {
        const { getXAIClient } = await import('../lib/xai');
        try {
          const xai = getXAIClient();
          await xai.chat({
            messages: [{ role: 'user', content: 'test' }]
          });
          setApiStatus(prev => ({ ...prev, xai: true }));
        } catch (err) {
          console.error('X.AI API check failed:', err);
          setApiStatus(prev => ({ ...prev, xai: false }));
        }
      }
    } catch (err) {
      console.error('X.AI API check failed:', err);
      setApiStatus(prev => ({ ...prev, xai: false }));
    }
  };

  const handleModelChange = (model: string) => {
    setSelectedModel(model);
    localStorage.setItem('selected_model', model);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const handleTemperatureChange = (type: 'min' | 'max', value: number) => {
    setTemperatureRange(prev => {
      const newRange = { ...prev, [type]: value };
      localStorage.setItem('temperature_min', newRange.min.toString());
      localStorage.setItem('temperature_max', newRange.max.toString());
      return newRange;
    });
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const handleDistributionChange = (distribution: string) => {
    setTemperatureDistribution(distribution);
    localStorage.setItem('temperature_distribution', distribution);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center">
        <SettingsIcon className="w-6 h-6 text-gray-900 mr-2" />
        <h1 className="text-2xl font-semibold text-gray-900">Settings</h1>
      </div>

      {/* Account Information */}
      <div className="bg-white shadow sm:rounded-lg">
        <div className="px-4 py-5 sm:p-6">
          <h3 className="text-lg leading-6 font-medium text-gray-900 mb-4">
            Account Information
          </h3>
          <div className="flex items-center space-x-4">
            <Database className="w-5 h-5 text-gray-400" />
            <div>
              <p className="text-sm font-medium text-gray-500">Connected Account</p>
              <p className="text-base text-gray-900">{userEmail}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Model Selection */}
      <div className="bg-white shadow sm:rounded-lg">
        <div className="px-4 py-5 sm:p-6">
          <div className="flex items-center mb-4">
            <Brain className="w-5 h-5 text-blue-500 mr-2" />
            <h3 className="text-lg leading-6 font-medium text-gray-900">
              Model Selection
            </h3>
          </div>
          
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-2">
            {Object.entries(AVAILABLE_MODELS).map(([modelId, model]) => (
              <div
                key={modelId}
                className={`relative rounded-lg border-2 p-6 cursor-pointer transition-all duration-300 hover:scale-[1.02] ${
                  selectedModel === modelId
                    ? 'border-blue-500 bg-blue-50 shadow-lg'
                    : 'border-gray-200 hover:border-blue-300 hover:shadow-md'
                }`}
                onClick={() => handleModelChange(modelId)}
              >
                <div className="flex flex-col h-full">
                  <h4 className="text-lg font-medium text-gray-900 mb-2">
                    {model.name}
                    {model.provider === 'xai' && (
                      <span className="ml-2 px-1.5 py-0.5 text-xs bg-yellow-100 text-yellow-800 rounded-full">
                        Beta
                      </span>
                    )}
                  </h4>
                  <p className="text-sm text-gray-500 mb-4">
                    {model.description}
                  </p>
                  
                  <div className="space-y-4 mt-auto">
                    <div>
                      <h5 className="text-sm font-medium text-gray-700 mb-1">Capabilities</h5>
                      <ul className="text-sm text-gray-600 list-disc list-inside">
                        {model.capabilities.map((capability, index) => (
                          <li key={index} className="animate-fadeIn">{capability}</li>
                        ))}
                      </ul>
                    </div>
                    
                    <div>
                      <h5 className="text-sm font-medium text-gray-700 mb-1">Best For</h5>
                      <ul className="text-sm text-gray-600 list-disc list-inside">
                        {model.bestFor.map((use, index) => (
                          <li key={index} className="animate-fadeIn">{use}</li>
                        ))}
                      </ul>
                    </div>

                    <p className="text-xs text-gray-400">
                      Max tokens: {model.maxTokens.toLocaleString()}
                    </p>
                    {model.provider === 'xai' && !apiStatus.xai && (
                      <p className="text-xs text-red-500">
                        X.AI API not available
                      </p>
                    )}
                  </div>

                  {selectedModel === modelId && (
                    <div className="absolute top-3 right-3">
                      <div className="h-3 w-3 rounded-full bg-blue-500 animate-pulse"></div>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Temperature Settings */}
      <div className="bg-white shadow sm:rounded-lg">
        <div className="px-4 py-5 sm:p-6">
          <div className="flex items-center mb-6">
            <Sliders className="w-5 h-5 text-blue-500 mr-2" />
            <h3 className="text-lg leading-6 font-medium text-gray-900">
              Temperature Distribution
            </h3>
          </div>

          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Distribution Type
              </label>
              <select
                value={temperatureDistribution}
                onChange={(e) => handleDistributionChange(e.target.value)}
                className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md bg-white text-gray-900 dark:bg-gray-800 dark:text-gray-100 dark:border-gray-700"
              >
                <option value="normal">Normal (Bell Curve)</option>
                <option value="uniform">Uniform (Random)</option>
                <option value="exponential">Exponential (More Low Values)</option>
                <option value="reverse-exponential">Reverse Exponential (More High Values)</option>
                <option value="bimodal">Bimodal (Two Peaks)</option>
                <option value="skewed-left">Left-Skewed (Peak Right)</option>
                <option value="skewed-right">Right-Skewed (Peak Left)</option>
                <option value="triangular">Triangular (Central Peak)</option>
                <option value="step">Step Function (Discrete)</option>
              </select>
              <p className="mt-2 text-sm text-gray-500">
                {temperatureDistribution === 'normal' && 'Most responses will have temperatures near the middle of the range'}
                {temperatureDistribution === 'uniform' && 'Temperatures will be randomly distributed across the range'}
                {temperatureDistribution === 'exponential' && 'More responses will have lower temperatures, favoring consistency'}
                {temperatureDistribution === 'reverse-exponential' && 'More responses will have higher temperatures, favoring variety'}
                {temperatureDistribution === 'bimodal' && 'Two distinct peaks of temperatures, useful for mixed response styles'}
                {temperatureDistribution === 'skewed-left' && 'More responses with higher temperatures, gradual decrease'}
                {temperatureDistribution === 'skewed-right' && 'More responses with lower temperatures, gradual increase'}
                {temperatureDistribution === 'triangular' && 'Linear increase to peak, then linear decrease'}
                {temperatureDistribution === 'step' && 'Discrete temperature levels, no gradual transitions'}
              </p>
            </div>

            <div className="space-y-4">
              <div>
                <div className="flex items-center justify-between">
                  <label className="block text-sm font-medium text-gray-700">
                    Minimum Temperature: {temperatureRange.min.toFixed(2)}
                  </label>
                  <span className="text-sm text-gray-500">More Consistent</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.1"
                  value={temperatureRange.min}
                  onChange={(e) => handleTemperatureChange('min', parseFloat(e.target.value))}
                  className="mt-2 w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-lg appearance-none cursor-pointer"
                />
              </div>

              <div>
                <div className="flex items-center justify-between">
                  <label className="block text-sm font-medium text-gray-700">
                    Maximum Temperature: {temperatureRange.max.toFixed(2)}
                  </label>
                  <span className="text-sm text-gray-500">More Variable</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.1"
                  value={temperatureRange.max}
                  onChange={(e) => handleTemperatureChange('max', parseFloat(e.target.value))}
                  className="mt-2 w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-lg appearance-none cursor-pointer"
                />
              </div>
            </div>

            <div className="bg-gray-50 p-4 rounded-lg">
              <div className="flex items-center mb-2">
                <ChartBar className="w-4 h-4 text-gray-500 mr-2" />
                <h4 className="text-sm font-medium text-gray-700">Distribution Preview</h4>
              </div>
              <div className="h-24 bg-white rounded-lg border border-gray-200 p-2">
                <div className="relative h-full">
                  {[...Array(20)].map((_, i) => (
                    <div
                      key={i}
                      className="absolute bottom-0 bg-blue-500 rounded-t-sm transition-all duration-300"
                      style={{
                        left: `${(i / 20) * 100}%`,
                        width: '4%',
                        height: temperatureDistribution === 'normal'
                          ? `${Math.exp(-(Math.pow((i - 10) / 5, 2)) * 100)}%`
                          : temperatureDistribution === 'uniform'
                          ? '50%'
                          : temperatureDistribution === 'exponential'
                          ? `${Math.exp(-i / 10) * 100}%`
                          : `${Math.exp((i - 20) / 10) * 100}%`,
                        opacity: 0.7
                      }}
                    />
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* System Status */}
      <div className="bg-white shadow sm:rounded-lg">
        <div className="px-4 py-5 sm:p-6">
          <div className="flex items-center mb-4">
            <Activity className="w-5 h-5 text-blue-500 mr-2" />
            <h3 className="text-lg leading-6 font-medium text-gray-900">
              System Status
            </h3>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 bg-green-50 rounded-lg">
              <p className="text-sm font-medium text-green-800">API Status</p>
              <div className="space-y-1 mt-1">
                <p className="text-sm">
                  <span className={`inline-block w-2 h-2 rounded-full mr-2 ${apiStatus.openai ? 'bg-green-500' : 'bg-red-500'}`}></span>
                  OpenAI: {apiStatus.openai ? 'Connected' : 'Not Connected'}
                </p>
                <p className="text-sm">
                  <span className={`inline-block w-2 h-2 rounded-full mr-2 ${apiStatus.xai ? 'bg-green-500' : 'bg-red-500'}`}></span>
                  X.AI: {apiStatus.xai ? 'Connected' : 'Not Connected'}
                </p>
              </div>
            </div>
            
            <div className="p-4 bg-blue-50 rounded-lg">
              <p className="text-sm font-medium text-blue-800">Model Status</p>
              <p className="text-lg font-semibold text-blue-600">Available</p>
            </div>
            
            <div className="p-4 bg-purple-50 rounded-lg">
              <p className="text-sm font-medium text-purple-800">Database Status</p>
              <p className="text-lg font-semibold text-purple-600">Connected</p>
            </div>
          </div>
        </div>
      </div>

      {/* Save Confirmation */}
      {saved && (
        <div className="fixed bottom-4 right-4 bg-green-500 text-white px-4 py-2 rounded-md shadow-lg animate-fadeInUp">
          Settings saved successfully!
        </div>
      )}
    </div>
  );
}