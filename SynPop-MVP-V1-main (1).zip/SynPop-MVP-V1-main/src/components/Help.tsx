import React from 'react';
import { HelpCircle, Book, FileText, Users, Zap, Map, Upload, MessageSquare, BarChart3, Database, ArrowRight } from 'lucide-react';

export function Help() {
  const quickStartSteps = [
    {
      title: 'Create Your First Population',
      icon: Users,
      description: 'Start by creating a synthetic population to work with.',
      steps: [
        'Click "Populations" in the main navigation',
        'Click "Create Population" button',
        'Choose one of three methods:',
        '• Upload structured data (CSV/Excel with employee data)',
        '• Upload unstructured documents (PDF/Text describing your population)',
        '• Use text prompts to describe your ideal population'
      ],
      example: {
        title: 'Example: Upload HR Data',
        text: 'Upload your HRIS export (e.g., Workday export) containing employee demographics like age, department, location, etc. SynPop will automatically map the columns and create synthetic profiles.'
      }
    },
    {
      title: 'Create a Stimulus',
      icon: Zap,
      description: 'Define what you want to test with your population.',
      steps: [
        'Navigate to "Stimuli" section',
        'Click "Create Stimulus" button',
        'Enter your question or content',
        'Choose response type (Likert scale, Yes/No, etc.)',
        'Add any relevant context documents'
      ],
      example: {
        title: 'Example: Employee Survey Question',
        text: '"Would you recommend our company as a great place to work?" with a 5-point Likert scale from Strongly Disagree to Strongly Agree'
      }
    },
    {
      title: 'Run Your First Simulation',
      icon: BarChart3,
      description: 'Simulate how your population would respond.',
      steps: [
        'Go to "Simulations" section',
        'Choose "Guided Creation" for a step-by-step process',
        'Select your population and stimulus',
        'Configure simulation settings',
        'Run the simulation and view results'
      ],
      example: {
        title: 'Example: Employee Engagement Survey',
        text: 'Run a simulation with 500 employees responding to engagement questions. View results broken down by department, age groups, and other demographics.'
      }
    }
  ];

  const features = [
    {
      title: 'Population Creation',
      icon: Database,
      items: [
        {
          name: 'Structured Data Upload',
          description: 'Upload CSV/Excel files with employee data',
          capabilities: [
            'Automatic column mapping',
            'Data quality validation',
            'Support for multiple file formats'
          ]
        },
        {
          name: 'Unstructured Documents',
          description: 'Extract population info from documents',
          capabilities: [
            'PDF document analysis',
            'Text content processing',
            'Automatic demographic extraction'
          ]
        },
        {
          name: 'AI-Powered Generation',
          description: 'Describe your population in plain text',
          capabilities: [
            'Natural language processing',
            'Demographic distribution control',
            'Realistic profile generation'
          ]
        }
      ]
    },
    {
      title: 'Simulation Types',
      icon: Map,
      items: [
        {
          name: 'Surveys',
          description: 'Detailed multi-question surveys',
          capabilities: [
            'Multiple question types',
            'Custom response scales',
            'Demographic analysis'
          ]
        },
        {
          name: 'Quick Polls',
          description: 'Simple single-question polls',
          capabilities: [
            'Yes/No questions',
            'Multiple choice',
            'Rapid results'
          ]
        },
        {
          name: 'Focus Groups',
          description: 'In-depth group discussions',
          capabilities: [
            'Group dynamics simulation',
            'Interactive discussions',
            'Detailed responses'
          ]
        }
      ]
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      <div className="flex items-center">
        <HelpCircle className="w-6 h-6 text-blue-500 mr-2" />
        <h1 className="text-2xl font-semibold text-gray-900">Help Center</h1>
      </div>

      {/* Quick Start Guide */}
      <div className="bg-white shadow rounded-lg overflow-hidden">
        <div className="px-6 py-5 border-b border-gray-200">
          <div className="flex items-center">
            <Book className="w-5 h-5 text-blue-500 mr-2" />
            <h2 className="text-lg font-medium text-gray-900">Quick Start Guide</h2>
          </div>
        </div>
        
        <div className="px-6 py-5">
          <div className="space-y-8">
            {quickStartSteps.map((step, index) => (
              <div key={index} className="relative">
                {index !== quickStartSteps.length - 1 && (
                  <div className="absolute left-6 top-20 bottom-0 w-px bg-gray-200" />
                )}
                <div className="flex items-start">
                  <div className="flex-shrink-0 bg-blue-50 rounded-lg p-3">
                    <step.icon className="w-6 h-6 text-blue-500" />
                  </div>
                  <div className="ml-4 flex-1">
                    <h3 className="text-lg font-medium text-gray-900">{step.title}</h3>
                    <p className="mt-1 text-sm text-gray-500">{step.description}</p>
                    
                    <div className="mt-4 bg-gray-50 rounded-lg p-4">
                      <ol className="space-y-2">
                        {step.steps.map((substep, idx) => (
                          <li key={idx} className="text-sm text-gray-600 flex items-start">
                            {!substep.startsWith('•') && (
                              <span className="flex-shrink-0 w-5 h-5 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center text-xs font-medium mr-2">
                                {idx + 1}
                              </span>
                            )}
                            <span className={substep.startsWith('•') ? 'ml-7' : ''}>
                              {substep}
                            </span>
                          </li>
                        ))}
                      </ol>
                    </div>

                    <div className="mt-4 border-l-4 border-blue-200 bg-blue-50 p-4 rounded-r-lg">
                      <h4 className="text-sm font-medium text-blue-900">{step.example.title}</h4>
                      <p className="mt-1 text-sm text-blue-700">{step.example.text}</p>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Features */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {features.map((feature, index) => (
          <div key={index} className="bg-white shadow rounded-lg overflow-hidden">
            <div className="px-6 py-5 border-b border-gray-200">
              <div className="flex items-center">
                <feature.icon className="w-5 h-5 text-blue-500 mr-2" />
                <h2 className="text-lg font-medium text-gray-900">{feature.title}</h2>
              </div>
            </div>
            <div className="px-6 py-5">
              <div className="space-y-6">
                {feature.items.map((item, idx) => (
                  <div key={idx} className="bg-gray-50 rounded-lg p-4">
                    <h3 className="text-sm font-medium text-gray-900">{item.name}</h3>
                    <p className="mt-1 text-sm text-gray-500">{item.description}</p>
                    <ul className="mt-3 space-y-1">
                      {item.capabilities.map((capability, capIdx) => (
                        <li key={capIdx} className="text-xs text-gray-600 flex items-center">
                          <ArrowRight className="w-3 h-3 text-blue-500 mr-1" />
                          {capability}
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}