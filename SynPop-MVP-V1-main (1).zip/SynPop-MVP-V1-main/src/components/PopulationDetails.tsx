import React, { useEffect, useRef, useState } from 'react';
import { ArrowLeft, Users, Map as MapIcon, BarChart as ChartBar, Filter, Download, FileText, Home, Building, Briefcase, DollarSign } from 'lucide-react';
import { analyzeDemographics } from '../lib/demographicAnalysis';
import * as d3 from 'd3';
import { ParentSize } from '@visx/responsive';
import { Group } from '@visx/group';
import { HeatmapRect } from '@visx/heatmap';
import { scaleLinear } from '@visx/scale';
import { feature } from 'topojson-client';
import type { Population } from '../types';
import * as XLSX from 'xlsx';

interface PopulationDetailsProps {
  population: Population;
  onBack: () => void;
}

interface DemographicBreakdown {
  category: string;
  values: Array<{
    label: string;
    count: number;
    percentage: number;
  }>;
}

interface GeographicData {
  region: string;
  count: number;
  density: number;
}

interface HouseholdData {
  size: number;
  count: number;
  percentage: number;
}

interface AgeGroupData {
  range: string;
  male: number;
  female: number;
  total: number;
}

export function PopulationDetails({ population, onBack }: PopulationDetailsProps) {
  const [selectedView, setSelectedView] = useState<'overview' | 'demographics'>('overview');
  const chartRef = useRef<SVGSVGElement>(null);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center">
          <button
            onClick={onBack}
            className="mr-4 text-gray-600 hover:text-gray-900"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-2xl font-semibold text-gray-900">{population.name}</h1>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-4">
        <div className="bg-white overflow-hidden shadow rounded-lg">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <Users className="h-6 w-6 text-blue-500" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">
                    Total Individuals
                  </dt>
                  <dd className="text-lg font-semibold text-gray-900">
                    {population.size.toLocaleString()}
                  </dd>
                </dl>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white overflow-hidden shadow rounded-lg">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <Building className="h-6 w-6 text-green-500" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">
                    Source Dataset
                  </dt>
                  <dd className="text-lg font-semibold text-gray-900">
                    {population.source_dataset || 'Generated'}
                  </dd>
                </dl>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white overflow-hidden shadow rounded-lg">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <Briefcase className="h-6 w-6 text-purple-500" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">
                    Creation Method
                  </dt>
                  <dd className="text-lg font-semibold text-gray-900">
                    {population.metadata?.creationMethod || 'Structured'}
                  </dd>
                </dl>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white overflow-hidden shadow rounded-lg">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <DollarSign className="h-6 w-6 text-yellow-500" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">
                    Created
                  </dt>
                  <dd className="text-lg font-semibold text-gray-900">
                    {new Date(population.created_at).toLocaleDateString()}
                  </dd>
                </dl>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* View Selection */}
      <div className="bg-white shadow rounded-lg p-6">
        <div className="flex space-x-4 mb-6">
          <button
            onClick={() => setSelectedView('overview')}
            className={`px-4 py-2 rounded-md ${
              selectedView === 'overview'
                ? 'bg-blue-600 text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Overview
          </button>
          <button
            onClick={() => setSelectedView('demographics')}
            className={`px-4 py-2 rounded-md ${
              selectedView === 'demographics'
                ? 'bg-blue-600 text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Demographics
          </button>
        </div>

        <div className="bg-gray-50 p-6 rounded-lg">
          {selectedView === 'overview' && (
            <div className="space-y-4">
              <h3 className="text-lg font-medium text-gray-900">Population Overview</h3>
              <p className="text-gray-600">
                This population contains {population.size.toLocaleString()} individuals
                {population.source_dataset && ` imported from ${population.source_dataset}`}.
                Created on {new Date(population.created_at).toLocaleDateString()}.
              </p>
              
              {population.metadata?.analysis && (
                <div className="mt-4">
                  <h4 className="text-md font-medium text-gray-900">Analysis Summary</h4>
                  <p className="text-gray-600 mt-2">{population.metadata.analysis.summary}</p>
                </div>
              )}
            </div>
          )}

          {selectedView === 'demographics' && (
            <div className="space-y-4">
              <h3 className="text-lg font-medium text-gray-900">Demographic Breakdown</h3>
              {population.attributes && population.attributes.length > 0 ? (
                <div className="grid grid-cols-2 gap-4">
                  {Object.entries(population.attributes[0]).map(([key, value]) => (
                    <div key={key} className="bg-white p-4 rounded-lg shadow-sm">
                      <h4 className="text-sm font-medium text-gray-700 capitalize">{key.replace(/_/g, ' ')}</h4>
                      <p className="mt-1 text-gray-900">
                        {typeof value === 'object' 
                          ? JSON.stringify(value, null, 2)
                            .split('\n')
                            .map((line, i) => (
                              <span key={i} className="block font-mono text-sm">
                                {line}
                              </span>
                            ))
                          : String(value)
                        }
                      </p>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-gray-500">No demographic data available</p>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}