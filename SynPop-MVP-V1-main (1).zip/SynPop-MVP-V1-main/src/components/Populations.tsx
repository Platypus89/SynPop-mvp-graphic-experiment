import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { Users, Upload, Trash2, Eye, Plus, AlertCircle, FileText, MessageSquare } from 'lucide-react';
import { FileUpload } from './FileUpload';
import { PopulationDetails } from './PopulationDetails';
import { UnstructuredDataUpload } from './UnstructuredDataUpload';
import { PromptPopulationCreator } from './PromptPopulationCreator';
import type { Population } from '../types';

type CreationMethod = 'structured' | 'unstructured' | 'prompt';

export function Populations() {
  const [populations, setPopulations] = useState<Population[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedPopulation, setSelectedPopulation] = useState<Population | null>(null);
  const [showCreator, setShowCreator] = useState(false);
  const [creationMethod, setCreationMethod] = useState<CreationMethod>('structured');
  const [page, setPage] = useState(0);
  const [hasMore, setHasMore] = useState(true);
  const PAGE_SIZE = 5;

  useEffect(() => {
    fetchPopulations();
  }, []);

  async function fetchPopulations() {
    try {
      setLoading(true);
      setError(null);
      
      // Fetch paginated data with count
      const { data, count, error } = await supabase
        .from('populations')
        .select('id, name, size, source_dataset, created_at, metadata')
        .order('created_at', { ascending: false })
        .range(page * PAGE_SIZE, (page + 1) * PAGE_SIZE - 1)
        .select('*', { count: 'exact' });

      if (error) throw error;
      
      if (data) {
        setPopulations(prev => page === 0 ? data : [...prev, ...data]);
        setHasMore(count ? (page + 1) * PAGE_SIZE < count : false);
      }

    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch populations');
    } finally {
      setLoading(false);
    }
  }

  const loadMore = () => {
    if (!loading && hasMore) {
      setPage(p => p + 1);
      fetchPopulations();
    }
  };

  async function handleDelete(id: string) {
    try {
      const { error } = await supabase
        .from('populations')
        .delete()
        .eq('id', id);

      if (error) throw error;
      setPopulations(populations.filter(p => p.id !== id));
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to delete population');
    }
  }

  if (loading) {
    return (
      <div className="animate-pulse space-y-8">
        <div className="h-12 bg-gray-200 rounded-lg w-1/4"></div>
        <div className="space-y-4">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="h-24 bg-gray-200 rounded-lg"></div>
          ))}
        </div>
      </div>
    );
  }

  if (selectedPopulation) {
    return (
      <PopulationDetails 
        population={selectedPopulation} 
        onBack={() => setSelectedPopulation(null)} 
      />
    );
  }

  if (showCreator) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-2xl font-semibold text-gray-900">Create New Population</h1>
            <p className="mt-2 text-gray-600">Choose how you want to create your synthetic population</p>
          </div>
          <button onClick={() => setShowCreator(false)} className="text-gray-600 hover:text-gray-900">
            ← Back to Populations
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <button
              onClick={() => setCreationMethod('structured')}
              className={`p-8 rounded-xl border-2 transition-all hover:scale-[1.02] ${
                creationMethod === 'structured' 
                  ? 'border-blue-500 bg-blue-50' 
                  : 'border-gray-200 hover:border-blue-300'
              }`}
            >
              <div className="flex flex-col items-center text-center">
                <Upload className="w-12 h-12 mb-4 text-blue-500" />
                <h3 className="text-xl font-semibold mb-3">Structured Data</h3>
                <p className="text-gray-600 max-w-sm">
                  Upload structured data from HRIS exports, spreadsheets, or databases. 
                  Perfect for existing employee data.
                </p>
              </div>
            </button>

            <button
              onClick={() => setCreationMethod('unstructured')}
              className={`p-8 rounded-xl border-2 transition-all hover:scale-[1.02] ${
                creationMethod === 'unstructured' 
                  ? 'border-blue-500 bg-blue-50' 
                  : 'border-gray-200 hover:border-blue-300'
              }`}
            >
              <div className="flex flex-col items-center text-center">
                <FileText className="w-12 h-12 mb-4 text-blue-500" />
                <h3 className="text-xl font-semibold mb-3">Unstructured Data</h3>
                <p className="text-gray-600 max-w-sm">
                  Upload documents, reports, or text files describing your population. 
                  Great for narrative descriptions.
                </p>
              </div>
            </button>
          </div>

        {creationMethod === 'structured' && (
          <FileUpload 
            onFileAccepted={() => {
              fetchPopulations();
              setShowCreator(false);
            }} 
          />
        )}

        {creationMethod === 'unstructured' && (
          <UnstructuredDataUpload
            onPopulationCreated={(population) => {
              setPopulations([population, ...populations]);
              setShowCreator(false);
            }}
          />
        )}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {error && (
        <div className="rounded-md bg-red-50 p-4">
          <div className="flex">
            <AlertCircle className="h-5 w-5 text-red-400 mr-2" />
            <div className="text-sm text-red-700">{error}</div>
          </div>
        </div>
      )}

      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-gray-900">Populations</h1>
        <button
          onClick={() => setShowCreator(true)}
          className="flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700"
        >
          <Plus className="w-4 h-4 mr-2" />
          Create Population
        </button>
      </div>

      {populations.length === 0 ? (
        <div className="text-center py-12">
          <Users className="mx-auto h-12 w-12 text-gray-400" />
          <h3 className="mt-2 text-sm font-medium text-gray-900">No populations</h3>
          <p className="mt-1 text-sm text-gray-500">
            Get started by creating a new population
          </p>
          <div className="mt-6">
            <button
              onClick={() => setShowCreator(true)}
              className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700"
            >
              <Plus className="w-4 h-4 mr-2" />
              Create Population
            </button>
          </div>
        </div>
      ) : (
        <div className="bg-white shadow overflow-hidden sm:rounded-md">
          <ul className="divide-y divide-gray-200">
            {populations.map((population) => (
              <li key={population.id}>
                <div className="px-4 py-4 flex items-center sm:px-6">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between">
                      <p className="text-sm font-medium text-blue-600 truncate">
                        {population.name}
                      </p>
                      <div className="ml-2 flex-shrink-0 flex">
                        <p className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                          {population.size.toLocaleString()} individuals
                        </p>
                        <p className="ml-2 px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 text-blue-800">
                          {population.metadata?.creationMethod || 'structured'}
                        </p>
                      </div>
                    </div>
                    <div className="mt-2 flex">
                      <div className="flex items-center text-sm text-gray-500">
                        <Upload className="flex-shrink-0 mr-1.5 h-4 w-4 text-gray-400" />
                        <p>
                          Created on{' '}
                          {new Date(population.created_at).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                  </div>
                  <div className="ml-5 flex-shrink-0 flex items-center space-x-2">
                    <button
                      onClick={() => setSelectedPopulation(population)}
                      className="text-gray-400 hover:text-gray-500 transition-colors duration-200"
                      title="View Details"
                    >
                      <Eye className="h-5 w-5" />
                    </button>
                    <button
                      onClick={() => handleDelete(population.id)}
                      className="text-red-400 hover:text-red-500 transition-colors duration-200"
                      title="Delete Population"
                    >
                      <Trash2 className="h-5 w-5" />
                    </button>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        </div>
      )}
      
      {/* Load More Button */}
      {hasMore && (
        <div className="mt-4 text-center">
          <button
            onClick={loadMore}
            disabled={loading}
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-blue-700 bg-blue-100 hover:bg-blue-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
          >
            {loading ? 'Loading...' : 'Load More'}
          </button>
        </div>
      )}
    </div>
  );
}