import React, { useCallback, useState } from 'react';
import { useDropzone } from 'react-dropzone';
import { supabase } from '../lib/supabase';
import { Upload, AlertCircle, FileCheck, FileX, CheckCircle } from 'lucide-react';
import { generateUserContext, analyzeIndividual } from '../lib/demographicAnalysis';
import * as XLSX from 'xlsx';

interface PreviewData {
  headers: string[];
  rows: any[];
}

interface FileUploadProps {
  onFileAccepted: (file: File) => void;
}

export function FileUpload({ onFileAccepted }: FileUploadProps) {
  const [error, setError] = useState<string | null>(null);
  const [fileStatus, setFileStatus] = useState<'idle' | 'validating' | 'valid' | 'invalid'>('idle');
  const [progress, setProgress] = useState(0);
  const [uploadSummary, setUploadSummary] = useState<{
    totalUsers: number;
    demographics: string[];
  } | null>(null);
  const [preview, setPreview] = useState<PreviewData | null>(null);

  const sanitizeValue = (value: any): string => {
    if (value === null || value === undefined) return '';
    return String(value).trim();
  };

  const processExcelFile = async (arrayBuffer: ArrayBuffer): Promise<{ headers: string[], data: any[] }> => {
    try {
      const workbook = XLSX.read(arrayBuffer);
      const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
      const jsonData = XLSX.utils.sheet_to_json(firstSheet, { header: 1 });

      if (jsonData.length < 2) {
        throw new Error('File must contain at least a header row and one data row');
      }

      const headers = (jsonData[0] as any[]).map(h => sanitizeValue(h));
      const data = [];

      for (let i = 1; i < jsonData.length; i++) {
        const row = jsonData[i] as any[];
        if (row && row.some(cell => cell !== null && cell !== undefined)) {
          const rowData = headers.reduce((obj, header, index) => {
            if (header) {
              obj[header] = sanitizeValue(row[index]);
            }
            return obj;
          }, {} as Record<string, any>);
          data.push(rowData);
        }
        setProgress(Math.min(100, Math.round((i / jsonData.length) * 100)));
      }

      return { headers: headers.filter(Boolean), data };
    } catch (err) {
      console.error('Error processing Excel file:', err);
      throw new Error('Failed to process Excel file. Please check the file format.');
    }
  };

  const validateFileContent = async (file: File): Promise<boolean> => {
    try {
      let headers: string[];
      let data: any[];

      if (file.name.toLowerCase().endsWith('.xlsx')) {
        const arrayBuffer = await file.arrayBuffer();
        const result = await processExcelFile(arrayBuffer);
        headers = result.headers;
        data = result.data;
      } else {
        const content = await new Promise<string>((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = e => resolve(e.target?.result as string || '');
          reader.onerror = () => reject(new Error('Failed to read file'));
          reader.readAsText(file);
        });

        if (!content) {
          throw new Error('File appears to be empty');
        }

        const lines = content.split(/\r\n|\n/).filter(line => line.trim());
        headers = lines[0].split(',').map(h => sanitizeValue(h));
        data = lines.slice(1).map(line => {
          const values = line.split(',').map(v => sanitizeValue(v));
          return headers.reduce((obj, header, index) => {
            if (header) {
              obj[header] = values[index] || null;
            }
            return obj;
          }, {} as Record<string, any>);
        });
      }

      if (headers.length === 0) {
        throw new Error('No valid columns found in the file');
      }

      if (data.length === 0) {
        throw new Error('No valid data rows found in the file');
      }

      // Set upload summary
      setUploadSummary({
        totalUsers: data.length,
        demographics: headers
      });

      // Save to Supabase
      const { error: saveError } = await supabase
        .from('populations')
        .insert([{
          name: sanitizeValue(file.name.replace(/\.[^/.]+$/, '')),
          size: data.length,
          source_dataset: sanitizeValue(file.name),
          expert_reflections: {
            financial: '',
            career: '',
            lifestyle: '',
            mental_health: '',
            relationship: ''
          },
          attributes: data.map(individual => {
            // Ensure individual is an object
            const safeIndividual = individual || {};
            let expertReflections = analyzeIndividual(safeIndividual);
            
            // Validate expert reflections
            if (!expertReflections || typeof expertReflections !== 'object') {
              console.error('Invalid expert reflections, using default:', expertReflections);
              expertReflections = Object.assign({}, {
                financial: '',
                career: '',
                lifestyle: '',
                mental_health: '',
                relationship: ''
              });
            }
            
            return {
              ...safeIndividual,
              user_context: generateUserContext(safeIndividual),
              expert_reflections: expertReflections
            };
          }),
          metadata: {
            creationMethod: 'structured',
            sourceFile: file.name
          }
        }]);

      if (saveError) {
        console.error('Save error:', saveError);
        throw new Error('Failed to save population: ' + (saveError.message || 'Unknown error'));
      }

      return true;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to process file';
      console.error('File processing error:', err);
      setError(errorMessage);
      return false;
    }
  };

  const handlePreview = async (file: File) => {
    try {
      if (file.name.endsWith('.xlsx')) {
        setProgress(0);
        const arrayBuffer = await file.arrayBuffer();
        const { headers, data } = await processExcelFile(arrayBuffer);
        setPreview({
          headers,
          rows: data.slice(0, 5) // Show first 5 rows
        });
      } else {
        setProgress(0);
        const content = await new Promise<string>((resolve) => {
          const reader = new FileReader();
          reader.onload = e => resolve(e.target?.result as string || '');
          reader.readAsText(file);
        });

        if (!content.trim()) {
          throw new Error('File appears to be empty');
        }

        const lines = content.split('\n').filter(line => line.trim());
        if (lines.length < 2) {
          throw new Error('File must contain at least a header row and one data row');
        }

        const headers = lines[0].split(',').map(h => h.trim());
        const rows = lines.slice(1, 6).map(line => {
          const values = line.split(',').map(v => v.trim());
          return headers.reduce((obj, header, index) => {
            if (header) {
              obj[header] = values[index] || '';
            }
            return obj;
          }, {} as Record<string, any>);
        });

        setPreview({ headers, rows });
      }
    } catch (err) {
      console.error('Preview error:', err);
      setError(err instanceof Error ? err.message : 'Failed to generate preview');
    }
  };

  const onDrop = useCallback(async (acceptedFiles: File[]) => {
    if (acceptedFiles.length > 0) {
      const file = acceptedFiles[0];
      setFileStatus('validating');
      setError(null);
      setProgress(0);
      setUploadSummary(null);
      
      if (file.size > 50 * 1024 * 1024) {
        setError('File size must be less than 50MB');
        setFileStatus('invalid');
        return;
      }

      try {
        await handlePreview(file);
        const isValid = await validateFileContent(file);
        setFileStatus(isValid ? 'valid' : 'invalid');
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to process file');
        setFileStatus('invalid');
      }
    }
  }, [onFileAccepted]);

  const handleConfirm = () => {
    onFileAccepted(null as any);
  };

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'text/csv': ['.csv'],
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': ['.xlsx'],
      'application/json': ['.json']
    },
    multiple: false,
    maxSize: 50 * 1024 * 1024 // 50MB
  });

  return (
    <div className="space-y-4">
      <div
        {...getRootProps()}
        className={`
          p-8 border-2 border-dashed rounded-lg text-center cursor-pointer transition-all
          ${isDragActive ? 'border-blue-500 bg-blue-50' : 'border-gray-300 hover:border-blue-400'}
          ${fileStatus === 'valid' ? 'border-green-500 bg-green-50' : ''}
          ${fileStatus === 'invalid' ? 'border-red-500 bg-red-50' : ''}
        `}
      >
        <input {...getInputProps()} />
        
        {fileStatus === 'valid' ? (
          <FileCheck className="w-12 h-12 mx-auto mb-4 text-green-500" />
        ) : fileStatus === 'invalid' ? (
          <FileX className="w-12 h-12 mx-auto mb-4 text-red-500" />
        ) : (
          <Upload className={`w-12 h-12 mx-auto mb-4 ${isDragActive ? 'text-blue-500' : 'text-gray-400'}`} />
        )}

        <p className="text-lg font-medium text-gray-700">
          {isDragActive ? 'Drop the file here' : 'Drag & drop a file here, or click to select'}
        </p>
        <p className="mt-2 text-sm text-gray-500">
          Supported formats: CSV, XLSX, JSON (max 50MB)
        </p>

        {fileStatus === 'validating' && (
          <div className="mt-4">
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div 
                className="bg-blue-500 h-2 rounded-full transition-all duration-300"
                style={{ width: `${progress}%` }}
              ></div>
            </div>
            <p className="mt-2 text-sm text-blue-600">
              Processing file... {progress}%
            </p>
          </div>
        )}
      </div>

      {error && (
        <div className="bg-red-50 p-4 rounded-lg flex items-center">
          <AlertCircle className="w-5 h-5 text-red-500 mr-3" />
          <p className="text-red-600">{error}</p>
        </div>
      )}

      {preview && (
        <div className="bg-white rounded-lg shadow-sm p-4 mt-4">
          <h3 className="text-sm font-medium text-gray-700 mb-3">Data Preview</h3>
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  {preview.headers.map((header, i) => (
                    <th
                      key={i}
                      className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                    >
                      {header}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {preview.rows.map((row, i) => (
                  <tr key={i}>
                    {preview.headers.map((header, j) => (
                      <td key={j} className="px-3 py-2 text-sm text-gray-500">
                        {row[header]}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {fileStatus === 'valid' && uploadSummary && (
        <div className="bg-white rounded-lg shadow-md p-6 animate-scale-in">
          <div className="flex items-center justify-center mb-6">
            <CheckCircle className="w-12 h-12 text-green-500 mr-3" />
            <h2 className="text-2xl font-semibold text-gray-900">Upload Successful!</h2>
          </div>

          <div className="space-y-4 mb-6">
            <div className="bg-gray-50 rounded-lg p-4">
              <h3 className="text-sm font-medium text-gray-700 mb-2">Population Summary</h3>
              <p className="text-lg font-semibold text-gray-900">
                {uploadSummary.totalUsers.toLocaleString()} individuals
              </p>
            </div>

            <div className="bg-gray-50 rounded-lg p-4">
              <h3 className="text-sm font-medium text-gray-700 mb-2">Available Demographics</h3>
              <div className="grid grid-cols-2 gap-2">
                {uploadSummary.demographics.map((demo, index) => (
                  <div key={index} className="text-sm text-gray-600 bg-white rounded px-2 py-1">
                    {demo}
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="flex justify-end space-x-4">
            <button
              onClick={handleConfirm}
              className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
            >
              Continue
            </button>
          </div>
        </div>
      )}
    </div>
  );
}