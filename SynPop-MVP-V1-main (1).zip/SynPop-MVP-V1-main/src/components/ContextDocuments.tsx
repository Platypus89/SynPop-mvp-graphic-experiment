import React, { useCallback, useState, useEffect } from 'react';
import { useDropzone } from 'react-dropzone';
import { FileText, X, Upload, AlertCircle, Loader2 } from 'lucide-react';
import { getOpenAIClient } from '../lib/openai';
import { extractTextFromPDF } from '../lib/pdfWorker';

interface ContextDocument {
  id: string;
  content: string;
  summary: string;
  type: 'file';
  filename: string;
}

interface ContextDocumentsProps {
  documents: ContextDocument[];
  onDocumentsChange: (documents: ContextDocument[]) => void;
}

export function ContextDocuments({ documents, onDocumentsChange }: ContextDocumentsProps) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [workerInitialized, setWorkerInitialized] = useState(false);

  const generateSummary = async (content: string): Promise<string> => {
    const openai = getOpenAIClient();
    
    const response = await openai.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [
        {
          role: "system",
          content: "You are a helpful assistant that creates concise summaries of documents. Keep summaries focused on key information that would be relevant for understanding and responding to survey questions."
        },
        {
          role: "user",
          content: `Please provide a concise summary of the following document, focusing on key information that would be relevant for understanding and responding to survey questions:\n\n${content.substring(0, 8000)}...`
        }
      ],
      temperature: 0.7,
      max_tokens: 500
    });

    return response.choices[0].message.content || 'No summary available';
  };

  const onDrop = useCallback(async (acceptedFiles: File[]) => {
    setLoading(true);
    setError(null);

    try {
      for (const file of acceptedFiles) {
        if (file.size > 10 * 1024 * 1024) {
          throw new Error(`File ${file.name} is too large. Maximum size is 10MB.`);
        }

        let content: string;
        
        if (file.type === 'application/pdf') {
          const arrayBuffer = await file.arrayBuffer();
          content = await extractTextFromPDF(arrayBuffer);
        } else {
          content = await new Promise<string>((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => resolve(reader.result as string);
            reader.onerror = () => reject(new Error('Failed to read file'));
            reader.readAsText(file);
          });
        }

        if (!content || content.trim().length === 0) {
          throw new Error('No text content found in file');
        }

        const summary = await generateSummary(content);

        const newDocument: ContextDocument = {
          id: crypto.randomUUID(),
          content,
          summary,
          type: 'file',
          filename: file.name
        };

        onDocumentsChange([...documents, newDocument]);
      }
    } catch (err) {
      console.error('Error processing file:', err);
      setError(err instanceof Error ? err.message : 'Failed to process file');
    } finally {
      setLoading(false);
    }
  }, [documents, onDocumentsChange]);

  const removeDocument = (id: string) => {
    onDocumentsChange(documents.filter(doc => doc.id !== id));
  };

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'text/plain': ['.txt'],
      'text/markdown': ['.md'],
      'application/json': ['.json'],
      'text/csv': ['.csv'],
      'application/pdf': ['.pdf']
    },
    maxSize: 10 * 1024 * 1024, // 10MB
    multiple: true
  });

  return (
    <div className="space-y-4">
      <div className="flex items-center mb-4">
        <FileText className="w-5 h-5 text-blue-500 mr-2" />
        <h3 className="text-lg font-medium">Context Documents</h3>
      </div>

      <div
        {...getRootProps()}
        className={`
          p-8 border-2 border-dashed rounded-lg text-center cursor-pointer transition-all duration-200 
          ${isDragActive 
            ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20' 
            : 'border-gray-300 hover:border-blue-400 dark:border-gray-700 dark:hover:border-blue-500'}
          dark:text-gray-300
        `}
      >
        <input {...getInputProps()} />
        <Upload className={`w-12 h-12 mx-auto mb-4 ${
          isDragActive ? 'text-blue-500' : 'text-gray-400 dark:text-gray-500'
        }`} />
        <p className="text-lg font-medium text-gray-700">
          {isDragActive ? 'Drop the files here' : 'Drag & drop files here, or click to select'}
        </p>
        <p className="mt-2 text-sm text-gray-500 dark:text-gray-400">
          Supported formats: TXT, MD, JSON, CSV, PDF (max 10MB per file)
        </p>
      </div>

      {loading && (
        <div className="flex items-center justify-center p-4 bg-blue-50 rounded-lg">
          <Loader2 className="w-5 h-5 text-blue-500 animate-spin mr-2" />
          <p className="text-blue-600">Processing documents...</p>
        </div>
      )}

      {error && (
        <div className="flex items-center p-4 bg-red-50 rounded-lg">
          <AlertCircle className="w-5 h-5 text-red-500 mr-2" />
          <p className="text-red-600">{error}</p>
        </div>
      )}

      {documents.length > 0 && (
        <div className="space-y-3">
          <h4 className="text-sm font-medium text-gray-700">Uploaded Documents</h4>
          {documents.map(doc => (
            <div
              key={doc.id}
              className="flex items-start justify-between p-4 bg-gray-50 rounded-lg border border-gray-200"
            >
              <div className="flex-1 mr-4">
                <div className="flex items-center">
                  <FileText className="w-4 h-4 text-gray-400 mr-2" />
                  <p className="font-medium text-gray-900">{doc.filename}</p>
                </div>
                <p className="mt-1 text-sm text-gray-500 line-clamp-2">{doc.summary}</p>
              </div>
              <button
                onClick={() => removeDocument(doc.id)}
                className="text-gray-400 hover:text-red-500 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}