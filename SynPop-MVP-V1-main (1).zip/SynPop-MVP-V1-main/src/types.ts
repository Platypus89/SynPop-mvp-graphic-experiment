// Update Population interface
export interface Population {
  id: string;
  name: string;
  size: number;
  source_dataset: string;
  attributes: any[];
  metadata?: {
    creationMethod?: 'structured' | 'unstructured' | 'prompt';
    analysis?: any;
    prompt?: string;
    expertAnalysis?: {
      economist: string;
      sociologist: string;
      psychologist: string;
    }[];
  };
  created_at: string;
  updated_at: string;
}

export interface ExpertReflection {
  economist: string;
  sociologist: string;
  psychologist: string;
}

export interface DemographicProfile {
  person_id: string;
  demographic_data: Record<string, any>;
  expert_reflections: ExpertReflection;
}

// Existing SimulationResults interface
export interface SimulationResults {
  responses: Array<{
    individualId: string;
    response: string;
    confidence: number;
    temperature: number;
    expertAnalysis?: ExpertReflection;
  }>;
  aggregates: {
    distribution: Record<string, number>;
    demographics: Record<string, Record<string, number>>;
    temperatureImpact?: {
      lowTemp: Record<string, number>;
      medTemp: Record<string, number>;
      highTemp: Record<string, number>;
    };
  };
  title: string;
  summary: string;
}

export interface Stimulus {
  id: string;
  type: 'text';
  content: string;
  metadata: {
    createdAt?: string;
    scale?: {
      type: 'likert' | 'binary' | 'custom';
      options?: string[];
    };
  };
}