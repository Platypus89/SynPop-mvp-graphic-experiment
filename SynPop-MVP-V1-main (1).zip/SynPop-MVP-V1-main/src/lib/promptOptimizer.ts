import { getOpenAIClient } from './openai';
import type { Population, Stimulus } from '../types';

interface OptimizedPrompt {
  systemPrompt: string;
  userPromptTemplate: string;
  reasoning: string;
}

interface DemographicField {
  name: string;
  type: string;
  values: Set<any>;
  distribution?: Record<string, number>;
}

function analyzeDemographics(population: any[]): Record<string, DemographicField> {
  const fields: Record<string, DemographicField> = {};
  
  // First pass: collect all fields and their values
  population.forEach(individual => {
    Object.entries(individual).forEach(([key, value]) => {
      if (!fields[key]) {
        fields[key] = {
          name: key,
          type: typeof value,
          values: new Set()
        };
      }
      fields[key].values.add(value);
    });
  });

  // Second pass: calculate distributions
  Object.values(fields).forEach(field => {
    const distribution: Record<string, number> = {};
    const total = population.length;

    population.forEach(individual => {
      const value = individual[field.name];
      distribution[value] = (distribution[value] || 0) + 1;
    });

    // Convert counts to percentages
    field.distribution = Object.fromEntries(
      Object.entries(distribution).map(([value, count]) => [
        value,
        (count / total) * 100
      ])
    );
  });

  return fields;
}

function detectCorrelations(population: any[], fields: Record<string, DemographicField>): Array<{
  field1: string;
  field2: string;
  strength: number;
}> {
  const correlations = [];
  const fieldNames = Object.keys(fields);

  for (let i = 0; i < fieldNames.length; i++) {
    for (let j = i + 1; j < fieldNames.length; j++) {
      const field1 = fieldNames[i];
      const field2 = fieldNames[j];

      // Calculate chi-square statistic for categorical variables
      const observed: Record<string, Record<string, number>> = {};
      let total = 0;

      population.forEach(individual => {
        const val1 = individual[field1];
        const val2 = individual[field2];
        
        if (!observed[val1]) observed[val1] = {};
        observed[val1][val2] = (observed[val1][val2] || 0) + 1;
        total++;
      });

      // Calculate Cramer's V as correlation strength
      const r = Object.keys(observed).length;
      const c = Object.keys(Object.values(observed)[0] || {}).length;
      const minDim = Math.min(r, c);
      
      if (minDim > 1) {
        let chiSquare = 0;
        Object.entries(observed).forEach(([val1, row]) => {
          Object.entries(row).forEach(([val2, count]) => {
            const expected = (Object.values(row).reduce((a, b) => a + b, 0) *
              Object.values(observed).reduce((a, b) => a + b[val2] || 0, 0)) / total;
            chiSquare += Math.pow(count - expected, 2) / expected;
          });
        });

        const cramersV = Math.sqrt(chiSquare / (total * (minDim - 1)));
        
        if (cramersV > 0.1) { // Only include meaningful correlations
          correlations.push({
            field1,
            field2,
            strength: cramersV
          });
        }
      }
    }
  }

  return correlations.sort((a, b) => b.strength - a.strength);
}

export async function optimizePrompts(
  stimulus: { type: string; content: string; metadata?: any },
  population: any[],
  contextDocuments: Array<{ content: string; summary: string }> = []
): Promise<OptimizedPrompt> {
  const openai = getOpenAIClient();
  
  if (!Array.isArray(population)) {
    console.error('Population is not an array:', population);
    throw new Error('Population must be an array');
  }

  // Analyze population demographics
  const demographics = analyzeDemographics(population);
  const correlations = detectCorrelations(population, demographics);

  // Prepare demographic insights
  const demographicInsights = Object.entries(demographics)
    .map(([field, data]) => ({
      field,
      type: data.type,
      uniqueValues: data.values.size,
      distribution: data.distribution
    }));

  // Prepare correlation insights
  const correlationInsights = correlations.map(c => ({
    fields: [c.field1, c.field2],
    strength: c.strength,
    description: `Strong correlation between ${c.field1} and ${c.field2}`
  }));

  const responseOptions = stimulus.metadata?.scale?.options || [
    "Strongly Disagree",
    "Disagree",
    "Neutral", 
    "Agree",
    "Strongly Agree"
  ];

  const analysisPrompt = `As an expert in survey design and demographic analysis, optimize the prompts for a simulation where synthetic individuals will respond to a stimulus.

TASK: Create prompts that will generate survey responses matching EXACTLY these options:
${responseOptions.map(opt => `"${opt}"`).join(', ')}

STIMULUS DETAILS:
- Type: ${stimulus.type}
- Content: ${stimulus.content}

DEMOGRAPHICS SUMMARY:
${Object.entries(demographics)
  .map(([field, data]) => `- ${field}: ${Array.from(data.values).slice(0, 5).join(', ')}${data.values.size > 5 ? '...' : ''}`)
  .join('\n')}

KEY CORRELATIONS:
${correlations.slice(0, 3).map(c => `- ${c.field1} correlates with ${c.field2} (${(c.strength * 100).toFixed(1)}%)`).join('\n')}

CONTEXT:
${contextDocuments.map(doc => `- ${doc.summary}`).join('\n')}

REQUIREMENTS:
1. System prompt must enforce EXACT response option matching
2. User prompt must include clear instructions about response format
3. Responses MUST be valid JSON: { "responses": [{ "response": string, "confidence": number }] }
4. NO additional text or explanations allowed in responses
5. Response options must match the provided list EXACTLY

Return this JSON structure:
{
  "systemPrompt": "The system prompt for the LLM",
  "userPromptTemplate": "Template with {{stimulus}}, {{options}}, and {{profile}} placeholders",
  "reasoning": "Explanation of prompt design choices"
}`;

  const response = await openai.chat.completions.create({
    model: "gpt-4",
    messages: [
      {
        role: "system",
        content: `You are an expert prompt engineer specializing in survey simulation and demographic analysis.
Your task is to create prompts that will generate consistent, well-structured JSON responses.
The response format MUST be: { "responses": [{ "response": string, "confidence": number }] }`
      },
      {
        role: "user",
        content: analysisPrompt
      }
    ],
    temperature: 0.3
  });

  const content = response.choices[0].message.content;
  if (!content) {
    throw new Error("Failed to generate optimized prompts");
  }

  try {
    return JSON.parse(content);
  } catch (error) {
    console.error('Failed to parse optimized prompts:', error);
    throw new Error('Invalid prompt optimization response format');
  }
}