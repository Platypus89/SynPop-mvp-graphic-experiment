import { Population, Simulation, Stimulus } from '../types';

// Cache configuration
const CACHE_DURATION = 5 * 60 * 1000; // 5 minutes
const POPULATION_CACHE_DURATION = 30 * 60 * 1000; // 30 minutes
const MAX_CACHE_SIZE = 100; // Maximum number of items per cache type
const CACHE_CLEANUP_INTERVAL = 5 * 60 * 1000; // Clean up every 5 minutes

interface CacheEntry<T> {
  data: T;
  timestamp: number;
}

interface Cache {
  populations: Map<string, CacheEntry<Population>>;
  simulations: Map<string, CacheEntry<Simulation>>;
  stimuli: Map<string, CacheEntry<Stimulus>>;
  responses: Map<string, CacheEntry<any>>;
}

class CacheManager {
  private static instance: CacheManager;
  private cache: Cache;
  private pendingRequests: Map<string, Promise<any>>;

  private constructor() {
    this.cache = {
      populations: new Map(),
      simulations: new Map(),
      stimuli: new Map(),
      responses: new Map()
    };
    this.pendingRequests = new Map();

    // Start periodic cleanup
    setInterval(() => this.cleanup(), CACHE_CLEANUP_INTERVAL);
  }

  static getInstance(): CacheManager {
    if (!CacheManager.instance) {
      CacheManager.instance = new CacheManager();
    }
    return CacheManager.instance;
  }

  private isExpired(entry: CacheEntry<any>, duration: number): boolean {
    return Date.now() - entry.timestamp > duration;
  }

  private cleanup() {
    Object.values(this.cache).forEach(cache => {
      if (!cache || !(cache instanceof Map)) {
        return;
      }

      // Remove expired entries
      Array.from(cache.entries()).forEach(([key, entry]) => {
        if (!entry || this.isExpired(entry, CACHE_DURATION)) {
          cache.delete(key);
        }
      });

      // Remove oldest entries if cache is too large
      if (cache.size > MAX_CACHE_SIZE) {
        const sortedEntries = Array.from(cache.entries())
          .sort((a, b) => a[1].timestamp - b[1].timestamp);
        
        const entriesToRemove = sortedEntries.slice(0, cache.size - MAX_CACHE_SIZE);
        entriesToRemove.forEach(([key]) => cache.delete(key));
      }
    });
  }

  set<T>(key: string, data: T, type: keyof Cache): void {
    if (!key || !type || !this.cache[type]) {
      return;
    }

    const cache = this.cache[type];
    cache.set(key, {
      data,
      timestamp: Date.now()
    });
  }

  get<T>(key: string, type: keyof Cache, duration: number = CACHE_DURATION): T | null {
    if (!key || !type || !this.cache[type]) {
      return null;
    }

    const cache = this.cache[type];
    const entry = cache.get(key);

    if (!entry || this.isExpired(entry, duration)) {
      cache.delete(key);
      return null;
    }

    return entry?.data as T || null;
  }

  async getOrFetch<T>(
    key: string,
    type: keyof Cache,
    fetchFn: () => Promise<T>,
    duration: number = CACHE_DURATION
  ): Promise<T> {
    // Check cache first
    const cached = this.get<T>(key, type, duration);
    if (cached) {
      return cached;
    }

    // Check if there's a pending request for this key
    const pendingKey = `${type}:${key}`;
    const pendingRequest = this.pendingRequests.get(pendingKey);
    if (pendingRequest) {
      return pendingRequest;
    }

    // Create new request
    const request = fetchFn().then(data => {
      this.set(key, data, type);
      this.pendingRequests.delete(pendingKey);
      return data;
    });

    this.pendingRequests.set(pendingKey, request);
    return request;
  }

  invalidate(type: keyof Cache): void {
    this.cache[type].clear();
  }

  invalidateKey(key: string, type: keyof Cache): void {
    this.cache[type].delete(key);
  }
}

export const cacheManager = CacheManager.getInstance();