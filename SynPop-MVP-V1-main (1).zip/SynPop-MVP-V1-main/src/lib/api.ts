import { supabase } from './supabase';
import { cacheManager } from './cache';
import type { Population, Simulation, Stimulus } from '../types';

// Batch processing configuration
const BATCH_SIZE = 50;
const BATCH_DELAY = 100; // ms
const PAGE_SIZE = 5;

export async function fetchPopulations(): Promise<Population[]> {
  return cacheManager.getOrFetch(
    'all',
    'populations',
    async () => {
      // Use range-based pagination for better performance
      const { data, error } = await supabase
        .from('populations')
        .select('*', { count: 'exact' })
        .order('created_at', { ascending: false })
        .range(0, PAGE_SIZE - 1);

      if (error) throw error;
      return data || [];
    },
    30 * 60 * 1000  // 30 minutes cache
  );
}

export async function fetchPopulation(id: string): Promise<Population> {
  return cacheManager.getOrFetch(
    id,
    'populations',
    async () => {
      const { data, error } = await supabase
        .from('populations')
        .select('*')
        .eq('id', id)
        .single();

      if (error) throw error;
      return data;
    }
  );
}

export async function fetchSimulations(): Promise<Simulation[]> {
  return cacheManager.getOrFetch(
    'all',
    'simulations',
    async () => {
      // Implement pagination
      const { data, error } = await supabase.from('simulations')
        .select('*', { count: 'exact' })
        .order('created_at', { ascending: false })
        .limit(BATCH_SIZE);

      if (error) throw error;
      return data || [];
    }
  );
}

export async function fetchStimuli(): Promise<Stimulus[]> {
  return cacheManager.getOrFetch(
    'all',
    'stimuli',
    async () => {
      // Implement pagination
      const { data, error } = await supabase.from('stimuli')
        .select('*', { count: 'exact' })
        .order('created_at', { ascending: false })
        .limit(BATCH_SIZE);

      if (error) throw error;
      return data || [];
    }
  );
}

// Batch process responses
export async function processBatchedResponses(
  responses: any[],
  batchSize: number = BATCH_SIZE
): Promise<any[]> {
  const results = [];
  
  for (let i = 0; i < responses.length; i += batchSize) {
    const batch = responses.slice(i, i + batchSize);
    
    // Process batch
    const batchResults = await Promise.all(
      batch.map(response => processResponse(response))
    );
    
    results.push(...batchResults);
    
    // Add delay between batches
    if (i + batchSize < responses.length) {
      await new Promise(resolve => setTimeout(resolve, BATCH_DELAY));
    }
  }
  
  return results;
}

async function processResponse(response: any): Promise<any> {
  const cacheKey = `response:${JSON.stringify(response)}`;
  
  return cacheManager.getOrFetch(
    cacheKey,
    'responses',
    async () => {
      // Process response here
      return response;
    }
  );
}

// Debounced fetch function
export function createDebouncedFetch(delay: number = 300) {
  let timeoutId: NodeJS.Timeout;
  
  return function<T>(
    fetchFn: () => Promise<T>,
    callback: (data: T) => void
  ) {
    clearTimeout(timeoutId);
    
    timeoutId = setTimeout(async () => {
      try {
        const data = await fetchFn();
        callback(data);
      } catch (error) {
        console.error('Debounced fetch error:', error);
      }
    }, delay);
  };
}