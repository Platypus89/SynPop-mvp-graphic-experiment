import type { Population } from '../types';

interface ExpertReflection {
  financial: string;
  career: string;
  lifestyle: string;
  mental_health: string;
  relationship: string;
}

function getAgeGroup(age: number | undefined): string {
  if (!age) return 'Unknown';
  if (age < 25) return 'Young Adult';
  if (age < 35) return 'Early Career';
  if (age < 50) return 'Mid Career';
  return 'Late Career';
}

function generateFinancialExpertReflection(demographic: Record<string, any>): string {
  const age = parseInt(demographic.age) || 0;
  const employment = demographic.employment_status || '';
  const education = demographic.education_level || '';
  const household = parseInt(demographic.household_size) || 1;
  const urbanization = demographic.urbanization || '';
  const income = demographic.income || 0;
  const occupation = demographic.occupation || '';

  let insights = [];

  // Employment status analysis
  if (employment.includes('employed')) {
    insights.push(`${occupation ? `Employed as ${occupation}` : 'Currently employed'}, providing income stability`);
  } else if (employment.includes('seeking')) {
    insights.push('Job search phase may impact short-term financial planning');
  } else if (employment.includes('retired')) {
    insights.push('Retirement status suggests focus on wealth preservation');
  }

  // Education impact
  if (education.includes('complete') && education.includes('Yes')) {
    const educationLevel = education.includes('college') ? 'college education' : 
                          education.includes('graduate') ? 'graduate degree' : 
                          'completed education';
    insights.push(`${educationLevel} enhances earning potential`);
  }

  // Living situation
  if (urbanization.includes('city')) {
    insights.push(`Urban lifestyle in ${demographic.location || 'city'} with corresponding cost of living`);
  } else if (urbanization.includes('rural')) {
    insights.push(`Rural setting in ${demographic.location || 'area'} balances lower costs with market access`);
  }

  // Household composition
  if (household > 1) {
    const householdType = demographic.household_type || 'multi-person';
    insights.push(`${householdType} household with ${household} members sharing resources`);
  } else {
    insights.push('Single-person household indicates sole financial responsibility');
  }

  // Income considerations
  if (income > 0) {
    const bracket = income < 50000 ? 'entry-level' :
                   income < 100000 ? 'mid-range' :
                   'high-earning';
    insights.push(`${bracket} income profile influences financial decisions`);
  }

  return insights.join('. ') + '.';
}

function generateCareerExpertReflection(demographic: Record<string, any>): string {
  const age = parseInt(demographic.age) || 0;
  const employment = demographic.employment_status || '';
  const education = demographic.education_level || '';
  const experience = demographic.years_experience || 0;
  const skills = demographic.skills || [];
  const ageGroup = getAgeGroup(age);

  let insights = [];

  // Career stage analysis
  const careerStage = experience < 3 ? 'Early-career' :
                      experience < 10 ? 'Mid-career' :
                      'Senior';
  insights.push(`${careerStage} ${demographic.industry || ''} professional in ${ageGroup} phase`);

  // Education impact
  if (education.includes('complete') && education.includes('Yes')) {
    const specialization = demographic.field_of_study || 'relevant field';
    insights.push(`Educational background in ${specialization} supports career growth`);
  } else {
    insights.push('May benefit from additional professional development');
  }

  // Employment trajectory
  if (employment.includes('seeking')) {
    const transitionType = demographic.career_change ? 'career change' : 'job search';
    insights.push(`Currently in ${transitionType} phase`);
  } else if (employment.includes('employed')) {
    insights.push(`${experience ? `${experience} years` : 'Established'} in current role`);
  }

  // Skills assessment
  if (skills.length > 0) {
    insights.push(`Skilled in ${skills.slice(0, 3).join(', ')}`);
  }

  return insights.join('. ') + '.';
}

function generateLifestyleExpertReflection(demographic: Record<string, any>): string {
  const age = parseInt(demographic.age) || 0;
  const urbanization = demographic.urbanization || '';
  const household = parseInt(demographic.household_size) || 1;
  const religion = demographic.religion || '';
  const interests = demographic.interests || [];
  const commute = demographic.commute_type || '';

  let insights = [];

  // Living environment
  if (urbanization.includes('city')) {
    const neighborhood = demographic.neighborhood_type || 'urban';
    insights.push(`${neighborhood} lifestyle with ${commute ? `${commute} commute and ` : ''}access to amenities`);
  } else if (urbanization.includes('rural')) {
    insights.push(`Rural lifestyle in ${demographic.location || 'area'} emphasizing space and nature`);
  }

  // Household dynamics
  if (household > 1) {
    const householdType = demographic.household_type || `${household}-person`;
    insights.push(`${householdType} household with shared living dynamics`);
  }

  // Cultural factors
  if (religion && !religion.includes('None')) {
    insights.push(`${religion} practices influence lifestyle choices`);
  }

  // Personal interests
  if (interests.length > 0) {
    insights.push(`Interests include ${interests.slice(0, 3).join(', ')}`);
  }

  return insights.join('. ') + '.';
}

function generateMentalHealthExpertReflection(demographic: Record<string, any>): string {
  const age = parseInt(demographic.age) || 0;
  const employment = demographic.employment_status || '';
  const household = parseInt(demographic.household_size) || 1;
  const urbanization = demographic.urbanization || '';
  const workLife = demographic.work_life_balance || '';
  const stressLevel = demographic.stress_level || '';

  let insights = [];

  // Life stage considerations
  const lifeEvents = demographic.life_events || [];
  insights.push(`${getAgeGroup(age)} phase with ${lifeEvents.length > 0 ? `ongoing ${lifeEvents[0]}` : 'typical life stage challenges'}`);

  // Employment impact
  if (employment.includes('seeking')) {
    const duration = demographic.job_search_duration || 'ongoing';
    insights.push(`${duration} job search period affecting stress levels`);
  } else if (employment.includes('employed')) {
    insights.push(`${workLife ? `${workLife} work-life balance` : 'Employment'} provides structure`);
  }

  // Social support
  if (household > 1) {
    const support = demographic.social_support || 'immediate';
    insights.push(`${support} social support system within household`);
  } else {
    const network = demographic.social_network || 'external';
    insights.push(`Independent living with ${network} social connections`);
  }

  // Stress management
  if (stressLevel) {
    insights.push(`Managing ${stressLevel} stress levels`);
  }

  return insights.join('. ') + '.';
}

function generateRelationshipExpertReflection(demographic: Record<string, any>): string {
  const age = parseInt(demographic.age) || 0;
  const household = parseInt(demographic.household_size) || 1;
  const marital = demographic.marital_status || '';
  const familyRole = demographic.family_role || '';
  const socialCircle = demographic.social_circle || '';

  let insights = [];

  // Relationship status
  if (marital.includes('married')) {
    const duration = demographic.marriage_duration || 'established';
    insights.push(`${duration} marriage with ${familyRole ? `${familyRole} role` : 'partnership dynamics'}`);
  } else if (marital.includes('single')) {
    insights.push(`Single status with focus on ${demographic.relationship_goals || 'personal growth'}`);
  }

  // Living situation impact
  if (household > 1) {
    insights.push(`${household}-person household with ${familyRole || 'regular'} interpersonal dynamics`);
  }

  // Social connections
  if (socialCircle) {
    insights.push(`Maintains ${socialCircle} social circle`);
  }

  return insights.join('. ') + '.';
}

function generateExpertReflections(demographic: Record<string, any>): ExpertReflection {
  try {
    // Generate reflections and ensure they are strings
    const reflections = {
      financial: String(generateFinancialExpertReflection(demographic) || ''),
      career: String(generateCareerExpertReflection(demographic) || ''),
      lifestyle: String(generateLifestyleExpertReflection(demographic) || ''),
      mental_health: String(generateMentalHealthExpertReflection(demographic) || ''),
      relationship: String(generateRelationshipExpertReflection(demographic) || '')
    };

    // Validate that all fields are strings and not undefined
    Object.entries(reflections).forEach(([key, value]) => {
      if (typeof value !== 'string') {
        reflections[key] = '';
      }
    });

    return reflections;
  } catch (error) {
    // Return default structure if analysis fails
    return {
      financial: '',
      career: '',
      lifestyle: '',
      mental_health: '',
      relationship: ''
    };
  }
}

function generateUserContext(demographic: Record<string, any>): string {
  const contexts: string[] = [];

  // Basic demographic information
  if (demographic.age) {
    const ageDesc = demographic.age < 25 ? 'young' : 
                    demographic.age < 40 ? 'mid-career' : 
                    demographic.age < 55 ? 'experienced' : 'senior';
    contexts.push(`${ageDesc} ${demographic.gender || 'individual'} in their ${demographic.age}s`);
  }

  // Location and environment
  if (demographic.location) {
    const urbanization = demographic.urbanization ? `${demographic.urbanization} area in ` : '';
    const lifestyle = demographic.urbanization === 'urban' ? 'city' :
                     demographic.urbanization === 'suburban' ? 'suburban' :
                     'rural';
    contexts.push(`Based in ${urbanization}${demographic.location}, enjoying a ${lifestyle} lifestyle`);
  }

  // Education and career
  if (demographic.education_level) {
    const educationDesc = `Completed ${demographic.education_level} education`;
    const field = demographic.field_of_study ? ` in ${demographic.field_of_study}` : '';
    contexts.push(educationDesc + field);
  }
  if (demographic.occupation) {
    const experience = demographic.years_experience 
      ? demographic.years_experience < 3 ? 'recently started' :
        demographic.years_experience < 7 ? 'established' :
        demographic.years_experience < 15 ? 'experienced' :
        'highly seasoned'
      : 'working';
    contexts.push(`${experience} ${demographic.occupation}`);
  }

  // Household composition
  const householdSize = parseInt(demographic.household_size);
  if (!isNaN(householdSize)) {
    const householdType = demographic.household_type || 
                         (householdSize === 1 ? 'single-person' : `${householdSize}-person`);
    contexts.push(householdSize === 1 
      ? 'Lives independently' 
      : `Part of a ${householdType} household`);
  }

  // Cultural background
  if (demographic.ethnicity) {
    contexts.push(`${demographic.ethnicity} background`);
  }
  if (demographic.religion && demographic.religion !== 'None') {
    const religiosity = demographic.religious_involvement || 'practices';
    contexts.push(`${religiosity} ${demographic.religion}`);
  }

  // Language
  if (demographic.language) {
    const fluency = demographic.language_fluency || 'speaks';
    contexts.push(`${fluency} ${demographic.language}`);
  }

  // Interests and lifestyle
  if (demographic.interests && Array.isArray(demographic.interests)) {
    const topInterests = demographic.interests.slice(0, 3);
    if (topInterests.length > 0) {
      contexts.push(`Passionate about ${topInterests.join(', ')}`);
    }
  }

  // Life events or current situation
  if (demographic.life_events && Array.isArray(demographic.life_events)) {
    const currentEvents = demographic.life_events.slice(0, 2);
    if (currentEvents.length > 0) {
      contexts.push(`Currently ${currentEvents.join(' and ')}`);
    }
  }

  // Randomize the order slightly to create variation
  const shuffledContexts = contexts.sort(() => Math.random() - 0.5);

  // Join with varied conjunctions
  return shuffledContexts.reduce((narrative, context, i) => {
    if (i === 0) return context;
    const connectors = ['. ', ', ', ' and ', ' while '];
    const connector = connectors[Math.floor(Math.random() * connectors.length)];
    return narrative + connector + context[0].toLowerCase() + context.slice(1);
  }, '') + '.';
}

function analyzeDemographics(population: { attributes: any[] }): Array<{ expert_reflections: ExpertReflection }> {
  return population.attributes.map(individual => ({
    expert_reflections: generateExpertReflections(individual)
  }));
}

function analyzeIndividual(individual: Record<string, any>): ExpertReflection {
  try {
    // Ensure individual is an object
    const safeIndividual = individual || {};
    console.log('Analyzing individual:', safeIndividual);
    
    // Generate reflections with guaranteed string values
    const reflections = generateExpertReflections(safeIndividual);
    
    // Validate reflections
    const isValid = Object.entries(reflections).every(([key, value]) => {
      const isValidValue = typeof value === 'string';
      if (!isValidValue) {
        console.warn(`Invalid ${key} reflection:`, value);
      }
      return isValidValue;
    });
    
    if (!isValid) {
      console.warn('Generated invalid reflections:', reflections);
      return {
        financial: '',
        career: '',
        lifestyle: '',
        mental_health: '',
        relationship: ''
      };
    }
    
    return reflections;
  } catch (error) {
    console.error('Error analyzing individual:', error);
    // Return default structure if analysis fails
    return {
      financial: '',
      career: '',
      lifestyle: '',
      mental_health: '',
      relationship: ''
    };
  }
}

export {
  generateUserContext,
  analyzeIndividual,
  analyzeDemographics,
  generateExpertReflections
};