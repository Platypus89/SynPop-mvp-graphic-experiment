import { getOpenAIClient } from './openai';

interface DemographicAnalysis {
  size: number;
  columns: string[];
  data: Record<string, any>[];
  summary: string;
  demographics?: Record<string, any[]>;
}

function generateSampleProfiles(demographics: Record<string, any[]>, count: number): Record<string, any>[] {
  const profiles: Record<string, any>[] = [];
  
  for (let i = 0; i < count; i++) {
    const profile: Record<string, any> = {};
    
    Object.entries(demographics).forEach(([category, distribution]) => {
      // Calculate cumulative probabilities
      let cumulative = 0;
      const ranges = distribution.map(item => {
        const range = {
          value: item.value,
          start: cumulative,
          end: cumulative + (item.percentage / 100)
        };
        cumulative += item.percentage / 100;
        return range;
      });

      // Select value based on probability
      const random = Math.random();
      const selected = ranges.find(range => random >= range.start && random < range.end);
      profile[category] = selected ? selected.value : distribution[0].value;
    });

    profiles.push(profile);
  }

  return profiles;
}

export async function analyzeDocument(content: string): Promise<DemographicAnalysis> {
  const openai = getOpenAIClient();
  
  if (!content || content.trim().length === 0) {
    throw new Error('Document content is empty');
  }

  // Clean up the content
  const cleanedContent = content
    .replace(/\s+/g, ' ')
    .replace(/[^\x20-\x7E\n]/g, '')
    .trim();

  const analysisPrompt = `Analyze this document to extract workforce demographic information.
  Look for:
  - Total employee/headcount numbers
  - Gender distribution (male/female percentages)
  - Age group breakdowns
  - Job levels or roles
  - Geographic distribution
  - Any other relevant demographic data

  Format as JSON with:
  - size: total headcount (number)
  - columns: demographic categories found
  - demographics: distribution percentages
  - summary: brief description
  
  Example:
  {
    "size": 5000,
    "columns": ["gender", "age_group", "job_level"],
    "demographics": {
      "gender": [
        {"value": "Female", "percentage": 45},
        {"value": "Male", "percentage": 55}
      ]
    },
    "summary": "5000 employees with 45% female representation"
  }`;

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [
        {
          role: "system",
          content: "You are a workforce analytics expert that extracts demographic information from documents."
        },
        {
          role: "user",
          content: `${analysisPrompt}\n\nDocument content:\n${cleanedContent.substring(0, 8000)}`
        }
      ],
      temperature: 0.1
    });

    const analysisText = response.choices[0].message.content;
    if (!analysisText) {
      throw new Error('Empty analysis response');
    }

    let analysis: DemographicAnalysis;
    try {
      analysis = JSON.parse(analysisText);
    } catch (parseError) {
      console.error('Failed to parse analysis:', parseError);
      throw new Error('Invalid analysis format');
    }

    // Extract size from text if not found in analysis
    if (!analysis.size || analysis.size < 1) {
      const sizeMatch = cleanedContent.match(/(?:total|approximately|about|over)?\s*(\d{1,3}(?:,\d{3})*|\d+)\s*(?:employees?|people|staff|workforce|headcount)/i);
      if (sizeMatch) {
        analysis.size = parseInt(sizeMatch[1].replace(/,/g, ''));
      } else {
        analysis.size = 1000; // Default size if none found
      }
    }

    // Ensure required fields exist
    analysis.columns = analysis.columns || ['gender', 'age_group'];
    analysis.demographics = analysis.demographics || {};
    analysis.summary = analysis.summary || `Workforce of ${analysis.size} employees`;

    // Generate sample data
    analysis.data = generateSampleProfiles(analysis.demographics, 5);

    return analysis;
  } catch (error) {
    console.error('Analysis error:', error);
    throw new Error('Failed to analyze document. Please check the format and try again.');
  }
}

export async function generateProfiles(
  analysis: DemographicAnalysis,
  onProgress?: (completed: number, total: number) => void
): Promise<Record<string, any>[]> {
  const batchSize = 100;
  const totalProfiles = analysis.size;
  const batches = Math.ceil(totalProfiles / batchSize);
  const profiles: Record<string, any>[] = [];

  for (let i = 0; i < batches; i++) {
    const remainingProfiles = totalProfiles - (i * batchSize);
    const currentBatchSize = Math.min(batchSize, remainingProfiles);
    
    const batchProfiles = generateSampleProfiles(analysis.demographics || {}, currentBatchSize);
    profiles.push(...batchProfiles);

    onProgress?.(Math.min((i + 1) * batchSize, totalProfiles), totalProfiles);

    // Add delay between batches to prevent UI freezing
    if (i < batches - 1) {
      await new Promise(resolve => setTimeout(resolve, 10));
    }
  }

  return profiles;
}