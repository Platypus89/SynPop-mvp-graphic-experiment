import OpenAI from 'openai';
import { StreamAnalyzer } from './streamAnalyzer.js';
import { levenshteinDistance } from './utils.js';

interface OptimizedPrompt {
  systemPrompt: string;
  userPromptTemplate: string;
  reasoning: string;
}

// Available models configuration
export const AVAILABLE_MODELS = {
  'grok-2': {
    name: 'Grok 2',
    description: 'X.AI\'s advanced model with real-time knowledge and witty responses',
    maxTokens: 128000,
    capabilities: [
      'Real-time knowledge access',
      'Witty and engaging responses',
      'Complex reasoning',
      'Contextual understanding'
    ],
    bestFor: [
      'Dynamic simulations',
      'Real-world scenarios',
      'Complex interactions'
    ],
    provider: 'xai'
  },
  'gpt-4o': {
    name: 'GPT-4o',
    description: 'Our most advanced model for complex simulations and nuanced population responses',
    maxTokens: 128000,
    capabilities: [
      'Complex demographic analysis',
      'Nuanced response generation',
      'Multi-step reasoning',
      'Context-aware responses'
    ],
    bestFor: [
      'Focus group simulations',
      'Complex survey responses',
      'Detailed demographic analysis'
    ]
  },
  'gpt-4o-mini': {
    name: 'GPT-4o Mini',
    description: 'Fast, affordable model optimized for focused survey tasks',
    maxTokens: 128000,
    capabilities: [
      'Fast response generation',
      'Efficient processing',
      'Good balance of speed and accuracy'
    ],
    bestFor: [
      'Large-scale simulations',
      'Quick polls',
      'Real-time response generation'
    ]
  },
  'gpt-3.5-turbo': {
    name: 'GPT-3.5 Turbo',
    description: 'Fast and efficient model for standard simulations',
    maxTokens: 16385,
    capabilities: [
      'Rapid response generation',
      'Basic demographic analysis',
      'High throughput processing'
    ],
    bestFor: [
      'Simple surveys',
      'Basic polls',
      'High-volume simulations'
    ]
  },
  'gpt-3.5': {
    name: 'GPT-3.5',
    description: 'Cost-effective model for straightforward tasks',
    maxTokens: 4096,
    capabilities: [
      'Basic text generation',
      'Simple analysis',
      'Standard processing'
    ],
    bestFor: [
      'Quick surveys',
      'Simple demographic analysis',
      'Basic simulations'
    ]
  }
} as const;

// Retry configuration
const MAX_RETRIES = 3;
const INITIAL_RETRY_DELAY = 1000;

export const getOpenAIClient = () => {
  const apiKey = import.meta.env.VITE_OPENAI_API_KEY;
  
  if (!apiKey) {
    throw new Error('OpenAI API key not found in environment variables.');
  }

  return new OpenAI({
    apiKey,
    dangerouslyAllowBrowser: true
  });
};

// Exponential backoff retry logic
async function retryWithBackoff<T>(
  operation: () => Promise<T>,
  retries = MAX_RETRIES,
  delay = INITIAL_RETRY_DELAY
): Promise<T> {
  try {
    return await operation();
  } catch (error: any) {
    if (error?.error?.type === 'invalid_request_error') {
      throw new Error('Invalid request to OpenAI API. Please check your input.');
    }
    if (error?.error?.type === 'invalid_api_key') {
      throw new Error('Invalid OpenAI API key. Please check your settings.');
    }
    if (error?.error?.type === 'insufficient_quota') {
      throw new Error('OpenAI API quota exceeded. Please check your usage limits.');
    }

    if (retries === 0 || !error?.error?.code?.includes('rate_limit')) {
      throw error;
    }

    await new Promise(resolve => setTimeout(resolve, delay));
    return retryWithBackoff(operation, retries - 1, delay * 2);
  }
}

// Calculate temperature based on confidence
function calculateTemperature(confidence: number): number {
  const minTemp = parseFloat(localStorage.getItem('temperature_min') || '0.3');
  const maxTemp = parseFloat(localStorage.getItem('temperature_max') || '0.8');
  const distribution = localStorage.getItem('temperature_distribution') || 'normal';

  // Get a random value between 0 and 1 based on the selected distribution
  let rand;
  switch (distribution) {
    case 'normal': {
      // Box-Muller transform for normal distribution
      const u1 = Math.random();
      const u2 = Math.random();
      const z = Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2);
      rand = (z + 3) / 6; // Transform to roughly 0-1 range
      break;
    }
    case 'exponential': {
      // Exponential distribution favoring lower values
      rand = 1 - Math.exp(-Math.random() * 3);
      break;
    }
    case 'reverse-exponential': {
      // Improved reverse exponential distribution
      const lambda = 3; // Adjusted for better high-value distribution
      rand = Math.exp(-lambda * (1 - Math.random()));
      break;
    }
    case 'bimodal': {
      // Two peaks at 0.3 and 0.7
      const peak = Math.random() < 0.5 ? 0.3 : 0.7;
      const variance = 0.1;
      const u1 = Math.random();
      const u2 = Math.random();
      rand = peak + Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2) * variance;
      break;
    }
    case 'skewed-left': {
      // Beta distribution with alpha=2, beta=5
      const u = Math.random();
      const v = Math.random();
      const x = Math.pow(u, 1/2);
      const y = Math.pow(v, 1/5);
      rand = x / (x + y);
      break;
    }
    case 'skewed-right': {
      // Beta distribution with alpha=5, beta=2
      const u = Math.random();
      const v = Math.random();
      const x = Math.pow(u, 1/5);
      const y = Math.pow(v, 1/2);
      rand = x / (x + y);
      break;
    }
    case 'triangular': {
      // Triangular distribution
      const u = Math.random();
      const peak = 0.5;
      rand = u < peak 
        ? Math.sqrt(u * peak)
        : 1 - Math.sqrt((1 - u) * (1 - peak));
      break;
    }
    case 'step': {
      // Step function with 5 discrete levels
      rand = Math.floor(Math.random() * 5) / 4;
      break;
    }
    default: // uniform
      rand = Math.random();
  }

  // Clamp to 0-1 range
  rand = Math.max(0, Math.min(1, rand));

  // Scale based on confidence and temperature range
  const confidenceInfluence = 0.3; // How much confidence affects the temperature
  const baseTemp = minTemp + (rand * (maxTemp - minTemp));
  
  // Adjust temperature based on distribution and confidence
  let adjustedTemp;
  if (distribution === 'reverse-exponential') {
    // For reverse exponential, weight towards higher temperatures
    adjustedTemp = maxTemp - ((maxTemp - baseTemp) * (1 - rand) * 0.5);
  } else {
    // For other distributions, apply confidence influence
    adjustedTemp = baseTemp * (1 - (confidence * confidenceInfluence));
  }

  return Math.max(minTemp, Math.min(maxTemp, adjustedTemp));
}

// Check for response anomalies
function detectAnomalies(responses: any[]): {
  hasAnomalies: boolean;
  anomalies: string[];
} {
  const anomalies: string[] = [];
  const responseCount = responses.length;
  
  if (responseCount === 0) {
    return { hasAnomalies: false, anomalies: [] };
  }

  // Count response frequencies
  const frequencies: Record<string, number> = {};
  responses.forEach(r => {
    frequencies[r.response] = (frequencies[r.response] || 0) + 1;
  });

  // Check for unusually high agreement (>80% same response)
  Object.entries(frequencies).forEach(([response, count]) => {
    const percentage = (count / responseCount) * 100;
    if (percentage > 80) {
      anomalies.push(`Unusually high agreement: ${percentage.toFixed(1)}% responded "${response}"`);
    }
  });

  // Check for low response variation (less than 3 different responses used)
  if (Object.keys(frequencies).length < 3 && responseCount > 10) {
    anomalies.push('Low response variation detected');
  }

  // Check for confidence patterns
  const confidences = responses.map(r => r.confidence);
  const avgConfidence = confidences.reduce((sum, c) => sum + c, 0) / responseCount;
  const allHighConfidence = confidences.every(c => c > 0.8);
  
  if (allHighConfidence && responseCount > 10) {
    anomalies.push('Unusually high confidence across all responses');
  }

  return {
    hasAnomalies: anomalies.length > 0,
    anomalies
  };
}

async function optimizePrompts(
  stimulus: { type: string; content: string; metadata?: any },
  population: any[],
  contextDocuments: Array<{ content: string; summary: string }> = []
): Promise<OptimizedPrompt> {
  const openai = getOpenAIClient();
  
  // Sample population attributes to understand structure
  const sampleSize = Math.min(5, population.length);
  const populationSample = population.slice(0, sampleSize);
  
  // Extract unique demographic fields
  const demographicFields = new Set<string>();
  populationSample.forEach(individual => {
    Object.keys(individual).forEach(key => demographicFields.add(key));
  });

  const analysisPrompt = `As an expert in survey design and demographic analysis, optimize the prompts for a simulation where synthetic individuals will respond to a stimulus.

STIMULUS:
${stimulus.content}

DEMOGRAPHIC FIELDS AVAILABLE:
${Array.from(demographicFields).join(', ')}

POPULATION SAMPLE:
${JSON.stringify(populationSample, null, 2)}

CONTEXT DOCUMENTS:
${contextDocuments.map(doc => doc.summary).join('\n\n')}

RESPONSE OPTIONS:
${JSON.stringify(stimulus.metadata?.scale?.options || [
  "Strongly Disagree",
  "Disagree",
  "Neutral",
  "Agree",
  "Strongly Agree"
], null, 2)}

Design optimal system and user prompts that will:
1. Consider demographic influences on responses
2. Account for cultural and social factors
3. Maintain response consistency
4. Generate realistic response patterns
5. Consider context documents

Return a JSON object with:
{
  "systemPrompt": "The system prompt for the LLM",
  "userPromptTemplate": "Template for individual prompts",
  "reasoning": "Explanation of prompt design choices"
}`;

  const response = await openai.chat.completions.create({
    model: "gpt-4",
    messages: [
      {
        role: "system",
        content: "You are an expert prompt engineer specializing in survey simulation and demographic analysis."
      },
      {
        role: "user",
        content: analysisPrompt
      }
    ],
    temperature: 0.7
  });

  const content = response.choices[0].message.content;
  if (!content) {
    throw new Error("Failed to generate optimized prompts");
  }

  try {
    return JSON.parse(content);
  } catch (error) {
    console.error('Failed to parse optimized prompts:', error);
    throw new Error('Invalid prompt optimization response format');
  }
}

export async function simulateResponses(
  population: any[],
  stimulus: { type: string; content: string; metadata?: any },
  contextDocuments: Array<{ content: string; summary: string }> = [],
  onProgress?: (completed: number, total: number, message: string) => void
): Promise<Array<{ response: string; individualId: any; temperature: number }>> {
  try {
    const selectedModel = localStorage.getItem('selected_model') || 'gpt-4o';
    const isGrok = selectedModel === 'grok-2';
    let analyzer = new StreamAnalyzer();
    
    const client = isGrok ? (await import('./xai')).getXAIClient() : getOpenAIClient();
    
    if (!population || !Array.isArray(population) || population.length === 0) {
      throw new Error('Invalid population data');
    }

    if (!stimulus?.content) {
      throw new Error('Invalid stimulus data');
    }

    // Get response options from stimulus metadata
    const responseOptions = stimulus.metadata?.scale?.options || [
      "Strongly Disagree",
      "Disagree", 
      "Neutral",
      "Agree",
      "Strongly Agree"
    ];

    const responseFormat = `Valid responses: ${responseOptions.map(opt => `"${opt}"`).join(', ')}`;

    // Define base prompts with explicit response options
    const systemPrompt = `You are a team of experts analyzing synthetic individuals and predicting their survey responses.
Each expert provides insights from their domain:

- Financial Analyst: Evaluates economic factors and financial decision-making
- Career Coach: Assesses professional trajectory and work-related perspectives  
- Lifestyle Consultant: Analyzes living situation and daily habits
- Mental Health Specialist: Considers psychological and emotional factors
- Relationship Advisor: Examines interpersonal dynamics and social context

Based on the expert reflections and demographic data, predict how this individual would respond to the stimulus.`;

    const fullSystemPrompt = `${systemPrompt}\n\n${responseFormat}`;

    // Create context from documents
    const context = contextDocuments.length > 0
      ? `\n\nContext Information:\n${contextDocuments.map(doc => doc.summary).join('\n\n')}`
      : '';

    const responses: Array<{ response: string; individualId: any; temperature: number }> = [];
    const BATCH_SIZE = 50;
    const totalBatches = Math.ceil(population.length / BATCH_SIZE);
    const { analyzeIndividual, generateExpertReflections } = await import('./demographicAnalysis');
    let consecutiveErrors = 0;
    const MAX_CONSECUTIVE_ERRORS = 3;
    let completedBatches = 0;

    const entertainingMessages = [
      "Analyzing demographic patterns...",
      "Calculating response probabilities...",
      "Processing individual profiles...",
      "Synthesizing population insights...",
      "Generating realistic responses...",
      "Applying demographic weightings...",
      "Evaluating response patterns...",
      "Simulating human behavior...",
      "Crunching the numbers...",
      "Almost there, just a few more responses..."
    ];

    for (let i = 0; i < population.length; i += BATCH_SIZE) {
      const batch = population.slice(i, Math.min(i + BATCH_SIZE, population.length));
      
      const batchPromises = batch.map(async (individual) => {
        // Generate expert reflections for the individual
        const expertReflections = generateExpertReflections(individual);

        try {
          const userPrompt = `
Demographic Profile:
${Object.entries(individual)
  .map(([key, value]) => `${key}: ${value}`)
  .join('\n')}

Expert Reflections:
- Financial Analyst: ${expertReflections.financial}
- Career Coach: ${expertReflections.career}
- Lifestyle Consultant: ${expertReflections.lifestyle}
- Mental Health Specialist: ${expertReflections.mental_health}
- Relationship Advisor: ${expertReflections.relationship}

Based on this analysis, how would this person respond to:
"${stimulus.content}"

Choose ONLY from these options: ${responseOptions.map(opt => `"${opt}"`).join(', ')}`;

          const response = await retryWithBackoff(async () => {
            const messages = [
              { 
                role: "system",
                content: `${fullSystemPrompt}\n\nIMPORTANT: You MUST respond with ONLY a JSON object in this exact format:
{
  "responses": [{
    "response": "one of: ${responseOptions.join(', ')}",
    "confidence": number between 0 and 1
  }]
}`
              },
              {
                role: "user",
                content: `Choose EXACTLY ONE response from: ${responseOptions.join(', ')}\n\n${userPrompt}`
              }
            ];

            const completion = isGrok ? await client.chat({
              messages,
              temperature: 0.7
            }) : await (client as any).chat.completions.create({
              model: selectedModel,
              messages,
              temperature: 0.7
            });

            return completion;
          });

          const content = response.choices?.[0]?.message?.content;
          if (!content) {
            throw new Error('Empty response content');
          }
          
          // Analyze response quality
          analyzer.analyzeResponse(content);
          if (analyzer.hasAnomalies()) {
            console.warn('Response anomalies:', analyzer.getAnomalies());
          }

          let parsed;
          try {
            // Enhanced content cleaning and parsing
            const cleanedContent = content
              .replace(/```[a-z]*\s*|\s*```/g, '') // Remove code blocks
              .replace(/^[^{]*({[\s\S]*})[^}]*$/, '$1') // Extract JSON
              .replace(/\\"/g, '"') // Fix escaped quotes
              .replace(/[\u0000-\u001F\u007F-\u009F]/g, '') // Remove control characters
              .trim();
            
            parsed = JSON.parse(cleanedContent);
          } catch (parseError: any) {
            console.error('Failed to parse response:', parseError);
            throw new Error('Invalid response format');
          }

          // Validate response structure
          if (!parsed.responses || !Array.isArray(parsed.responses) || parsed.responses.length === 0) {
            throw new Error('Invalid response structure');
          }

          // Normalize response by trimming and exact matching
          const normalizedResponse = parsed.responses[0].response.trim();
          const availableOptions = stimulus.metadata?.scale?.options || responseOptions;
          const exactMatch = availableOptions.find(opt => 
            opt.toLowerCase() === normalizedResponse.toLowerCase()
          );

          if (!exactMatch) {
            const closest = availableOptions.reduce((prev, curr) => {
              const prevDist = levenshteinDistance(normalizedResponse, prev);
              const currDist = levenshteinDistance(normalizedResponse, curr);
              return currDist < prevDist ? curr : prev;
            });
            throw new Error(`Invalid response option: "${normalizedResponse}". Did you mean "${closest}"?`);
          }

          // Use the exact match with original casing
          parsed.responses[0].response = exactMatch;

          if (typeof parsed.responses[0].confidence !== 'number' || parsed.responses[0].confidence < 0 || parsed.responses[0].confidence > 1) {
            throw new Error('Invalid confidence value');
          }

          // Calculate dynamic temperature based on confidence
          const temperature = calculateTemperature(parsed.responses[0].confidence);

          return {
            response: parsed.responses[0].response,
            individualId: individual,
            temperature,
            expertReflections,
            confidence: parsed.responses[0].confidence
          };

        } catch (error: any) {
          console.error('Error simulating individual response:', error.message || error);
          // Return fallback response with reduced confidence
          const fallback = {
            response: responseOptions[Math.floor(Math.random() * responseOptions.length)],
            individualId: individual || {},
            temperature: 1.0, // High temperature for fallback responses
            expertReflections,
            confidence: 0.5
          };
          return fallback;
        }
      });
      
      const batchResults = await Promise.all(batchPromises);

      // Reset error count if successful batch
      if (consecutiveErrors > 0) {
        consecutiveErrors = 0;
      }

      const progressMessage = entertainingMessages[completedBatches % entertainingMessages.length];
      onProgress?.(completedBatches, totalBatches, progressMessage);

     responses.push(...batchResults);

      // Validate batch results
      if (batchResults.some(r => !r || !r.response)) {
        throw new Error('Invalid batch results detected');
      }

      completedBatches++;
      
      // Check for anomalies after each batch
      if (completedBatches % 5 === 0) {
        const { hasAnomalies, anomalies } = detectAnomalies(responses);
        if (hasAnomalies) {
          console.warn('Response anomalies detected:', anomalies);
        }
      }

      const remainingBatches = totalBatches - completedBatches;
      // Adjust delay based on remaining batches to prevent rate limiting
      const delay = Math.max(500, 1000 * (remainingBatches / totalBatches));
      await new Promise(resolve => setTimeout(resolve, delay));
    }

    // Final anomaly check
    const { hasAnomalies, anomalies } = detectAnomalies(responses);
    if (hasAnomalies) {
      console.warn('Final response anomalies detected:', anomalies);
    }

    onProgress?.(totalBatches, totalBatches, "Simulation completed successfully!");

    return responses;
  } catch (error) {
    console.error('Error in simulateResponses:', error);
    throw new Error(`Simulation failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}