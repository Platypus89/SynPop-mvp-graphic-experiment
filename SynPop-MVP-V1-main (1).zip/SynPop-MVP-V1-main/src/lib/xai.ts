import type { ChatCompletionCreateParams } from 'openai/resources/chat';

const API_URL = 'https://api.x.ai/v1';

interface XAIResponse {
  id: string;
  choices: Array<{
    message: {
      role: string;
      content: string;
    };
  }>;
}

class XAIClient {
  private apiKey: string;

  constructor(apiKey: string) {
    this.apiKey = apiKey;
  }

  async chat(params: ChatCompletionCreateParams): Promise<XAIResponse> {
    try {
      if (!params.messages || !Array.isArray(params.messages) || params.messages.length === 0) {
        throw new Error('Invalid chat parameters');
      }

      const response = await fetch(`${API_URL}/chat/completions`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.apiKey}`
        },
        body: JSON.stringify({
          ...params,
          model: 'grok-2-latest',
          temperature: params.temperature || 0.7,
          max_tokens: params.max_tokens || 1000
        })
      });

      if (!response.ok) {
        let errorMessage = `Failed to communicate with X.AI API: ${response.status}`;
        try {
          const error = await response.json();
          errorMessage = error.message || errorMessage;
        } catch {
          // Keep default error message if JSON parsing fails
        }
        throw new Error(errorMessage);
      }

      const result = await response.json();
      
      // Validate response structure
      if (!result || !Array.isArray(result.choices) || !result.choices[0]?.message?.content) {
        throw new Error('Invalid or empty response from X.AI API');
      }
      
      return result;
    } catch (error) {
      console.error('X.AI API error:', error);
      throw error;
    }
  }
}

export const getXAIClient = () => {
  const apiKey = import.meta.env.VITE_XAI_API_KEY;
  
  if (!apiKey) {
    throw new Error('X.AI API key not found in environment variables.');
  }

  return new XAIClient(apiKey);
};