import type { ChatCompletionCreateParams } from 'openai/resources/chat';
import { getOpenAIClient } from './openai';
import { getXAIClient } from './xai';

interface ModelCapability {
  name: string;
  provider: 'openai' | 'xai' | 'anthropic';
  strengths: string[];
  demographics: string[];
  responseTypes: string[];
  contextTypes: string[];
  temperatureRange: {
    min: number;
    max: number;
  };
  maxTokens: number;
  costPerToken: number;
}

// Model capabilities database
const MODEL_CAPABILITIES: Record<string, ModelCapability> = {
  'gpt-4': {
    name: 'GPT-4',
    provider: 'openai',
    strengths: [
      'Complex reasoning',
      'Nuanced responses',
      'Professional tone',
      'Technical accuracy'
    ],
    demographics: [
      'Knowledge workers',
      'Technical professionals',
      'Academic researchers'
    ],
    responseTypes: ['analytical', 'technical', 'formal'],
    contextTypes: ['technical', 'academic', 'business'],
    temperatureRange: { min: 0.1, max: 0.9 },
    maxTokens: 8192,
    costPerToken: 0.00003
  },
  'gpt-3.5-turbo': {
    name: 'GPT-3.5 Turbo',
    provider: 'openai',
    strengths: [
      'Fast responses',
      'General knowledge',
      'Casual conversation',
      'High throughput'
    ],
    demographics: [
      'General population',
      'Social media users',
      'Customer service'
    ],
    responseTypes: ['casual', 'conversational', 'general'],
    contextTypes: ['social', 'customer-service', 'general'],
    temperatureRange: { min: 0.2, max: 1.0 },
    maxTokens: 4096,
    costPerToken: 0.000002
  },
  'grok-2': {
    name: 'Grok-2',
    provider: 'xai',
    strengths: [
      'Witty responses',
      'Creative thinking',
      'Informal tone',
      'Real-time knowledge'
    ],
    demographics: [
      'Tech enthusiasts',
      'Early adopters',
      'Social media power users'
    ],
    responseTypes: ['witty', 'informal', 'creative'],
    contextTypes: ['social-media', 'tech', 'current-events'],
    temperatureRange: { min: 0.3, max: 1.0 },
    maxTokens: 4096,
    costPerToken: 0.000005
  }
};

interface RoutingContext {
  demographic: Record<string, any>;
  responseType: string;
  contextType: string;
  priority: 'speed' | 'quality' | 'cost';
  temperature: number;
}

interface ModelScore {
  modelId: string;
  score: number;
  reasons: string[];
}

class ModelRouter {
  private static instance: ModelRouter;
  private routingHistory: Map<string, { success: boolean; latency: number }>;
  private modelUsage: Map<string, number>;

  private constructor() {
    this.routingHistory = new Map();
    this.modelUsage = new Map();
  }

  static getInstance(): ModelRouter {
    if (!ModelRouter.instance) {
      ModelRouter.instance = new ModelRouter();
    }
    return ModelRouter.instance;
  }

  private scoreModel(model: ModelCapability, context: RoutingContext): ModelScore {
    let score = 0;
    const reasons: string[] = [];

    // Demographic match
    const demographicMatch = model.demographics.some(demo => 
      Object.values(context.demographic).some(value => 
        String(value).toLowerCase().includes(demo.toLowerCase())
      )
    );
    if (demographicMatch) {
      score += 2;
      reasons.push('Strong demographic match');
    }

    // Response type match
    if (model.responseTypes.includes(context.responseType)) {
      score += 2;
      reasons.push('Matches required response type');
    }

    // Context type match
    if (model.contextTypes.includes(context.contextType)) {
      score += 2;
      reasons.push('Suitable for context type');
    }

    // Temperature compatibility
    if (context.temperature >= model.temperatureRange.min && 
        context.temperature <= model.temperatureRange.max) {
      score += 1;
      reasons.push('Temperature within optimal range');
    }

    // Priority adjustments
    switch (context.priority) {
      case 'speed':
        if (model.provider === 'openai' && model.name.includes('3.5')) {
          score += 2;
          reasons.push('Optimized for speed');
        }
        break;
      case 'quality':
        if (model.name.includes('4')) {
          score += 2;
          reasons.push('Optimized for quality');
        }
        break;
      case 'cost':
        if (model.costPerToken < 0.00001) {
          score += 2;
          reasons.push('Cost-effective option');
        }
        break;
    }

    // Historical performance adjustment
    const history = this.routingHistory.get(model.name);
    if (history && history.success) {
      score += 0.5;
      reasons.push('Good historical performance');
    }

    // Load balancing adjustment
    const usage = this.modelUsage.get(model.name) || 0;
    if (usage < 100) {
      score += 0.5;
      reasons.push('Low current usage');
    }

    return {
      modelId: model.name,
      score,
      reasons
    };
  }

  async routeRequest(
    context: RoutingContext,
    messages: ChatCompletionCreateParams['messages']
  ): Promise<any> {
    // Score all models
    const scores: ModelScore[] = Object.entries(MODEL_CAPABILITIES)
      .map(([_, model]) => this.scoreModel(model, context))
      .sort((a, b) => b.score - a.score);

    // Select top model
    const selectedModel = scores[0];
    console.log('Selected model:', selectedModel.modelId, 'Reasons:', selectedModel.reasons);

    // Update usage counter
    this.modelUsage.set(
      selectedModel.modelId,
      (this.modelUsage.get(selectedModel.modelId) || 0) + 1
    );

    const startTime = Date.now();
    try {
      // Route to appropriate provider
      const modelConfig = MODEL_CAPABILITIES[selectedModel.modelId];
      let response;

      switch (modelConfig.provider) {
        case 'openai':
          const openai = getOpenAIClient();
          response = await openai.chat.completions.create({
            model: selectedModel.modelId,
            messages,
            temperature: context.temperature
          });
          break;

        case 'xai':
          const xai = getXAIClient();
          response = await xai.chat({
            messages,
            temperature: context.temperature
          });
          break;

        default:
          throw new Error(`Unsupported provider: ${modelConfig.provider}`);
      }

      // Record successful routing
      this.routingHistory.set(selectedModel.modelId, {
        success: true,
        latency: Date.now() - startTime
      });

      return response;
    } catch (error) {
      // Record failed routing
      this.routingHistory.set(selectedModel.modelId, {
        success: false,
        latency: Date.now() - startTime
      });
      throw error;
    }
  }

  // Get routing statistics
  getStats() {
    return {
      modelUsage: Object.fromEntries(this.modelUsage),
      routingHistory: Object.fromEntries(this.routingHistory),
      availableModels: Object.keys(MODEL_CAPABILITIES)
    };
  }
}

export const modelRouter = ModelRouter.getInstance();