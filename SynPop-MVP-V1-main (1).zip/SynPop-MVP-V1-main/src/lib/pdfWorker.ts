import * as pdfjsLib from 'pdfjs-dist';

let initialized = false;

export async function initPdfWorker() {
  if (initialized) return;

  try {
    // Set worker source path
    pdfjsLib.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjsLib.version}/pdf.worker.min.js`;
    initialized = true;
  } catch (error) {
    console.error('Failed to initialize PDF worker:', error);
    throw error;
  }
}

export async function extractTextFromPDF(arrayBuffer: ArrayBuffer): Promise<string> {
  if (!initialized) {
    await initPdfWorker();
  }

  try {
    const loadingTask = pdfjsLib.getDocument({ data: arrayBuffer });
    const pdf = await loadingTask.promise;
    let fullText = '';
    
    for (let i = 1; i <= pdf.numPages; i++) {
      const page = await pdf.getPage(i);
      const textContent = await page.getTextContent();
      const pageText = textContent.items
        .map((item: any) => item.str)
        .join(' ');
      fullText += pageText + '\n';
    }
    
    return fullText;
  } catch (error) {
    console.error('Error extracting text from PDF:', error);
    throw new Error('Failed to extract text from PDF. Please check the file format.');
  }
}