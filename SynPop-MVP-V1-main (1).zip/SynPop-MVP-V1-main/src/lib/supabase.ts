import { createClient } from '@supabase/supabase-js';
import type { Database } from './database.types';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string;
const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

// Check if the environment variables are defined and not empty strings
if (!supabaseUrl || supabaseUrl.trim() === '') {
  throw new Error('Missing VITE_SUPABASE_URL environment variable');
}

if (!supabaseKey || supabaseKey.trim() === '') {
  throw new Error('Missing VITE_SUPABASE_ANON_KEY environment variable');
}

export const supabase = createClient<Database>(supabaseUrl, supabaseKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
    storageKey: 'synpop_auth'
  },
  global: {
    headers: {
      'X-Client-Info': 'synpop-web'
    },
    fetch: async (url, options = {}) => {
      // Add query timeout
      const signal = AbortSignal.timeout(30000); // 30 second timeout

      const headers = new Headers(options.headers);
      headers.set('Cache-Control', 'no-cache');
      headers.set('Pragma', 'no-cache');

      let responseText: string | null = null;
      
      try {
        const response = await fetch(url, { 
          ...options, 
          headers,
          signal 
        });

        if (!response.ok) {
          // Clone response before reading the body
          const clonedResponse = response.clone();
          responseText = await clonedResponse.text();
          console.error('Supabase request failed:', {
            url,
            status: response.status,
            body: responseText
          });
          throw new Error(`Request failed with status ${response.status}`);
        }

        return response;
      } catch (error) {
        if (error.name === 'TimeoutError') {
          throw new Error('Request timed out. Please try again.');
        } else if (responseText) {
          // If we have the error response text, include it in the error
          throw new Error(`Supabase request failed: ${responseText}`);
        }
        throw error;
      }
    }
  }
});