import { levenshteinDistance } from './utils.js';

interface Anomaly {
  type: 'format' | 'content' | 'confidence' | 'distribution';
  severity: 'low' | 'medium' | 'high';
  message: string;
  details?: any;
}

export class StreamAnalyzer {
  private anomalies: Anomaly[] = [];
  private responseHistory: any[] = [];
  private confidenceHistory: number[] = [];
  private responseDistribution: Map<string, number> = new Map();
  
  analyzeResponse(content: string) {
    this.anomalies = [];
    
    // Format validation
    try {
      const parsed = JSON.parse(content);
      if (!this.validateResponseFormat(parsed)) {
        this.addAnomaly('format', 'high', 'Invalid response format');
      }
      
      // Content analysis
      if (parsed.responses?.[0]) {
        const response = parsed.responses[0];
        
        // Check confidence trends
        this.analyzeConfidence(response.confidence);
        
        // Check response distribution
        this.analyzeDistribution(response.response);
        
        // Check for response consistency
        this.analyzeConsistency(response);
        
        // Store for historical analysis
        this.responseHistory.push(response);
      }
    } catch (error) {
      this.addAnomaly('format', 'high', 'Failed to parse response', { error });
    }
  }
  
  private validateResponseFormat(parsed: any): boolean {
    return (
      parsed &&
      typeof parsed === 'object' &&
      Array.isArray(parsed.responses) &&
      parsed.responses.length > 0 &&
      parsed.responses[0] &&
      typeof parsed.responses[0] === 'object' &&
      typeof parsed.responses[0].response === 'string' &&
      typeof parsed.responses[0].confidence === 'number' &&
      parsed.responses[0].confidence >= 0 &&
      parsed.responses[0].confidence <= 1
    );
  }
  
  private analyzeConfidence(confidence: number) {
    if (typeof confidence !== 'number' || isNaN(confidence)) {
      this.addAnomaly('confidence', 'high', 'Invalid confidence value');
      return;
    }

    this.confidenceHistory.push(confidence);
    
    if (this.confidenceHistory.length >= 5) {
      const recentConfidences = this.confidenceHistory.slice(-5);
      const avgConfidence = recentConfidences.reduce((a, b) => a + b, 0) / recentConfidences.length;
      
      if (avgConfidence < 0.3) {
        this.addAnomaly('confidence', 'high', 'Consistently low confidence scores');
      }
      
      const stdDev = this.calculateStdDev(recentConfidences);
      if (stdDev < 0.05) {
        this.addAnomaly('confidence', 'medium', 'Suspiciously consistent confidence scores');
      }
    }
  }
  
  private analyzeDistribution(response: string) {
    if (!response || typeof response !== 'string') {
      this.addAnomaly('content', 'high', 'Invalid response value');
      return;
    }

    this.responseDistribution.set(
      response,
      (this.responseDistribution.get(response) || 0) + 1
    );
    
    if (this.responseHistory.length >= 10) {
      const total = this.responseHistory.length;
      let maxPercentage = 0;
      
      this.responseDistribution.forEach(count => {
        const percentage = (count / total) * 100;
        maxPercentage = Math.max(maxPercentage, percentage);
      });
      
      if (maxPercentage > 80) {
        this.addAnomaly('distribution', 'high', 'Response distribution heavily skewed');
      }
    }
  }
  
  private analyzeConsistency(response: any) {
    if (this.responseHistory.length >= 2) {
      const previousResponse = this.responseHistory[this.responseHistory.length - 1];
      
      // Check for exact duplicates
      if (JSON.stringify(response) === JSON.stringify(previousResponse)) {
        this.addAnomaly('content', 'medium', 'Duplicate response detected');
      }
      
      // Check for similar responses with different confidences
      if (
        response.response === previousResponse.response &&
        Math.abs(response.confidence - previousResponse.confidence) > 0.5
      ) {
        this.addAnomaly('confidence', 'low', 'Inconsistent confidence for same response');
      }
    }
  }
  
  private calculateStdDev(values: number[]): number {
    const avg = values.reduce((a, b) => a + b, 0) / values.length;
    const squareDiffs = values.map(value => Math.pow(value - avg, 2));
    return Math.sqrt(squareDiffs.reduce((a, b) => a + b, 0) / values.length);
  }
  
  private addAnomaly(
    type: Anomaly['type'],
    severity: Anomaly['severity'],
    message: string,
    details?: any
  ) {
    this.anomalies.push({ type, severity, message, details });
  }
  
  hasAnomalies(): boolean {
    return this.anomalies.length > 0;
  }
  
  getAnomalies(): Anomaly[] {
    return this.anomalies;
  }
  
  getStats() {
    return {
      totalResponses: this.responseHistory.length,
      averageConfidence: this.confidenceHistory.length > 0
        ? this.confidenceHistory.reduce((a, b) => a + b, 0) / this.confidenceHistory.length
        : 0,
      distribution: Object.fromEntries(this.responseDistribution),
      anomalyCount: this.anomalies.length
    };
  }
  
  reset() {
    this.anomalies = [];
    this.responseHistory = [];
    this.confidenceHistory = [];
    this.responseDistribution.clear();
  }
}