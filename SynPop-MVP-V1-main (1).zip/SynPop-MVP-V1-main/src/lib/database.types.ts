export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      users: {
        Row: {
          id: string
          email: string
          user_role: string
          created_at: string
        }
        Insert: {
          id: string
          email: string
          user_role?: string
          created_at?: string
        }
        Update: {
          id?: string
          email?: string
          user_role?: string
          created_at?: string
        }
      }
      populations: {
        Row: {
          id: string
          name: string
          size: number
          source_dataset: string | null
          attributes: Json
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          name: string
          size: number
          source_dataset?: string | null
          attributes: Json
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          name?: string
          size?: number
          source_dataset?: string | null
          attributes?: Json
          created_at?: string
          updated_at?: string
        }
      }
      stimuli: {
        Row: {
          id: string
          type: string
          content: string
          metadata: Json
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          type: string
          content: string
          metadata?: Json
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          type?: string
          content?: string
          metadata?: Json
          created_at?: string
          updated_at?: string
        }
      }
      simulations: {
        Row: {
          id: string
          population_id: string
          stimulus_id: string
          name: string
          description: string | null
          status: string
          temperature: number
          results: Json
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          population_id: string
          stimulus_id: string
          name: string
          description?: string | null
          status: string
          temperature?: number
          results?: Json
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          population_id?: string
          stimulus_id?: string
          name?: string
          description?: string | null
          status?: string
          temperature?: number
          results?: Json
          created_at?: string
          updated_at?: string
        }
      }
    }
    Functions: {
      is_admin: {
        Args: Record<PropertyKey, never>
        Returns: boolean
      }
    }
  }
}