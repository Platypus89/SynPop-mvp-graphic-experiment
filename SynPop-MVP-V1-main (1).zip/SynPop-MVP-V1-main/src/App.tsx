import React from 'react';
import { HashRouter as Router, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { Navigation } from './components/Navigation';
import { Dashboard } from './components/Dashboard';
import { Populations } from './components/Populations';
import { Stimuli } from './components/Stimuli';
import { Simulations } from './components/Simulations';
import { Settings } from './components/Settings';
import { Help } from './components/Help';

function AppContent() {
  const location = useLocation();

  return (
    <div className="min-h-screen bg-background gradient-bg">
      <Navigation />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Routes location={location}>
          <Route path="/" element={<Dashboard />} />
          <Route path="/populations" element={<Populations />} />
          <Route path="/stimuli" element={<Stimuli />} />
          <Route path="/simulations" element={<Simulations />} />
          <Route path="/settings" element={<Settings />} />
          <Route path="/help" element={<Help />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>
    </div>
  );
}

function App() {
  return (
    <Router>
      <AppContent />
    </Router>
  );
}

export default App;