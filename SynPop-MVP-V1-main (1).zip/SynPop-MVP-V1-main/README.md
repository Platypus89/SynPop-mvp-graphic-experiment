# SynPop-MVP-V1

[Edit in StackBlitz next generation editor ⚡️](https://stackblitz.com/~/github.com/Platypus89/SynPop-MVP-V1)